# ═══════════════════════════════════════════════════════════════
#  57cap08_emi_kazuki.rpy — Capítulo 8: El reflejo
#  -----------------------------------------------------------------
#  Pareja: Emi & Kazuki
#  Posición: Emi (izq) + Kazuki (der)
#  Finales: bueno / bueno_especial / emi_muere / kazuki_muere / ambos_quedan / secreto
#  Minijuego: MEMORY CON POEMAS (emparejar versos)
#  Exploración: menú con flechas (3 zonas)
#  Diccionario: poema_emi, favor_kazuki, seis_meses, presidencia_comprada
#  Fichas: emi, kazuki
#  Bestiario: hospital, poemas
#  Pistas tablón: 6
#  Deducciones: 2
#  Flashbacks: 2
#  Eco El·yon: 3 apariciones
#
#  ⚠️ NOTA: Los labels cap08_nota_*, cap08_flashback_*,
#     cap08_deduccion_*, cap08_eco_*, cap08_pulsar_* están
#     definidos en sus respectivos archivos auxiliares
#     (57cap08_notas.rpy, 57cap08_flashbacks.rpy,
#      57cap08_deducciones.rpy, 57cap08_eco.rpy,
#      57cap08_objetos.rpy). NO se duplican aquí.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES
# ─────────────────────────────────────────────────────────────
# Emi y Kazuki YA están definidos en 03imagenes_personajes.rpy
# como `em` y `kz`. Usamos esos para aprovechar el callback
# automático de imagen.
#
# elyon_voz ya está definido en 55cap06_ayame_hiro.rpy.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  IMÁGENES (placeholders temporales)
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Despertar en el hospital
# Archivo: images/fondos/cap08/piso8_despertar.png
# Prompt: Anime dark psychological horror scene: the inside of an
#         abandoned hospital corridor at night. Peeling greenish
#         walls, flickering fluorescent lights, broken wheelchairs
#         against the walls. A single door at the end, slightly
#         ajar, revealing pale blue light. The floor is covered in
#         old medical papers and dried leaves. Atmosphere: clinical,
#         silent, waiting. Muted palette: sickly greens, faded
#         whites, cold shadows. Anime style, 16:9, no text.
image bg_piso8_despertar = Solid("#1a221c")

# 🎨 PROMPT IMAGEN — Sala de las habitaciones (poemas)
# Archivo: images/fondos/cap08/piso8_habitaciones.png
# Prompt: Anime dark psychological horror scene: a long hospital
#         ward with rows of empty beds, curtains half-drawn.
#         On the walls, between the beds, hundreds of handwritten
#         poems in faded ink. Some are legible, some are not. A
#         single window at the end shows only darkness. The sheets
#         on the beds are slightly disturbed, as if someone just
#         left. Atmosphere: haunted, intimate, wrong. 16:9.
image bg_piso8_habitaciones = Solid("#1e1a22")

# 🎨 PROMPT IMAGEN — Quirófano
# Archivo: images/fondos/cap08/piso8_quirofano.png
# Prompt: Anime dark psychological horror scene: an abandoned
#         operating room. A metal operating table in the center,
#         covered in a thin layer of dust. Surgical instruments
#         still arranged on a tray. Above, a broken surgical
#         light, one bulb still flickering weakly. On the wall,
#         a single poem written in what looks like dried blood.
#         Atmosphere: surgical, cold, wrong. 16:9, no text.
image bg_piso8_quirofano = Solid("#1a1e20")

# 🎨 PROMPT IMAGEN — Espejo del pasillo
# Archivo: images/fondos/cap08/piso8_espejo.png
# Prompt: Anime dark psychological horror scene: the end of a
#         hospital corridor, where a tall mirror stands against
#         the wall. The mirror is cracked but still intact. In
#         its reflection, the corridor is different — brighter,
#         cleaner, and there is a silhouette standing where no
#         one is. Atmosphere: reflection, threshold, duality.
#         16:9, no text.
image bg_piso8_espejo = Solid("#1c1c24")

# 🎨 PROMPT IMAGEN — Puerta al fondo
# Archivo: images/fondos/cap08/piso8_salida.png
# Prompt: Anime dark psychological horror scene: at the end of
#         the hospital corridor, a heavy metal door with a faded
#         red cross painted on it. The door is slightly ajar,
#         revealing warm golden light from the other side. The
#         walls around it are covered in poems. Atmosphere:
#         final threshold, release. 16:9, no text.
image bg_piso8_salida = Solid("#2e2418")

# ── OBJETOS ──

# 🎨 PROMPT IMAGEN — Poema en la pared
# Archivo: images/objetos/cap08_poema.png
# Prompt: Anime dark psychological horror close-up: a single
#         handwritten poem on a peeling hospital wall, written
#         in faded blue ink. The handwriting is delicate and
#         shaky. Some words are crossed out. At the bottom, a
#         signature: "Emi". 16:9, no text.
image cap08_poema = Solid("#1e1a22")

# 🎨 PROMPT IMAGEN — Espejo roto
# Archivo: images/objetos/cap08_espejo.png
# Prompt: Anime dark psychological horror close-up: a small
#         handheld mirror, cracked in several places, lying on
#         a hospital bed. In the reflection, a face that doesn't
#         belong to anyone. The face is smiling. The mirror
#         itself is dusty. 16:9, no text.
image cap08_espejo = Solid("#1c1c24")

# ── IMÁGENES DE FINAL ──

# 🎨 PROMPT IMAGEN — Final bueno
# Archivo: images/finales/cap8_final_bueno.png
# Prompt: Anime dark psychological horror scene: an 18-year-old
#         girl with ash-blonde hair (Emi) and a 19-year-old boy
#         with brown hair (Kazuki) walking side by side toward
#         the metal door at the end of the hospital corridor,
#         seen from behind. The poems on the walls are fading.
#         Soft warm light ahead. 16:9, no text.
image cap8_final_bueno = Solid("#e8d0a8")

# 🎨 PROMPT IMAGEN — Final especial (Sin reflejo)
# Archivo: images/finales/cap8_final_especial.png
# Prompt: Anime dark psychological horror scene: close-up of
#         Emi's face, looking into a cracked mirror. Her
#         reflection is smiling — but she is not. Behind her,
#         blurred, Kazuki's hand reaching toward her shoulder.
#         Warm light. 16:9, no text.
image cap8_final_especial = Solid("#f0d8b0")

# 🎨 PROMPT IMAGEN — Final Emi muere
# Archivo: images/finales/cap8_final_emi_muere.png
# Prompt: Anime dark psychological horror scene: Kazuki alone
#         at the metal door of the hospital, looking back. In
#         the corridor, a single poem on the wall is still
#         glowing softly. No one there. 16:9, no text.
image cap8_final_emi_muere = Solid("#1a181c")

# 🎨 PROMPT IMAGEN — Final Kazuki muere
# Archivo: images/finales/cap8_final_kazuki_muere.png
# Prompt: Anime dark psychological horror scene: Emi alone in
#         front of the open metal door, looking back over her
#         shoulder at the empty corridor. On the floor, a single
#         object remains: a small broken mirror. 16:9, no text.
image cap8_final_kazuki_muere = Solid("#1a1818")

# 🎨 PROMPT IMAGEN — Final ambos quedan
# Archivo: images/finales/cap8_final_ambos.png
# Prompt: Anime dark psychological horror scene: two silhouettes
#         (a girl and a boy) sitting on the floor of the hospital
#         corridor, back to back, surrounded by poems on the
#         walls. The metal door in the distance is closed. The
#         fluorescent light flickers. 16:9, no text.
image cap8_final_ambos = Solid("#141418")

# 🎨 PROMPT IMAGEN — Final secreto (El reflejo)
# Archivo: images/finales/cap8_final_secreto.png
# Prompt: Anime dark psychological horror scene: the tall mirror
#         at the end of the corridor, but now its surface is
#         full of pale reflections of Emi, all writing poems on
#         the walls. Among them, faintly, one Emi is looking
#         directly at the viewer. She is smiling. She is not
#         dead. She is reflecting. 16:9, no text.
image cap8_final_secreto = Solid("#0f0f14")


# ═══════════════════════════════════════════════════════════════
#  CAPÍTULO 8
# ═══════════════════════════════════════════════════════════════
label capitulo_8:

    # ── Pantalla de carga ──
    $ _cap_data = capitulos.historias["torre"]["actos"].get(8, {})
    $ _nombre_cap = _cap_data.get("nombre", "El reflejo")
    $ _sub_cap = _cap_data.get("sub", "Emi & Kazuki")
    $ _icono_cap = _cap_data.get("icono", "🪞")
    call mostrar_pantalla_carga("torre", 8, _nombre_cap, _sub_cap, _icono_cap)

    $ gtn_reiniciar_metricas()
    $ gtn_capitulo_actual = 8
    $ capitulos.desbloquear_capitulo("torre", 8)
    $ registrar_capitulo_jugado(8)

    scene black
    with fade

    show screen gtn_notif_screen
    $ musica("torre_ambiente", fade=2.0)

    $ add_achievement_with_popup(achievement_octavo_despertar)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 1 — EL DESPERTAR
    # ═══════════════════════════════════════════════════════════

    n "Lo primero que notas es el olor."
    n "Desinfectante. Papel viejo. Algo metálico."
    n "Lo segundo, el zumbido."
    n "Un fluorescente que parpadea."
    n "Y luego, el silencio."
    n "Un silencio clínico. Limpio. Falso."
    n "Abres los ojos."

    scene bg_piso8_despertar
    with fade

    n "Estás tumbada en el suelo de un pasillo."
    n "Verde. Desconchado."
    n "Con sillas de ruedas oxidadas."
    n "Y al fondo, una puerta entreabierta."

    show emi_img at left
    with dissolve

    em "..."
    em "¿Dónde están los médicos?"

    n "Te incorporas despacio. El suelo está frío."
    n "El fluorescente parpadea. Pero no se apaga."

    em_p "(Un hospital.)"
    em_p "(Pero no hay nadie.)"
    em_p "(Y las paredes tienen poemas.)"

    $ desbloquear_ficha("torre", "emi")
    $ add_achievement_with_popup(achievement_conoce_emi)

    em "¿Hola?"
    n "Tu voz no hace eco."
    n "El pasillo se la traga."
    n "Y entonces, muy bajo, muy lejano..."
    n "Alguien recita un poema."
    n "Una sola estrofa."

    $ desbloquear_pista("torre", "p8_poema_emi")

    # ── Decisión 1 ──
    menu:
        "¿Qué haces?"

        "Leer el poema más cercano.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("emi_lee", True)
            $ registrar_decision()

            em "Vale. Voy a leer."
            n "Te acercas a la pared."
            n "El poema está escrito con letra temblorosa."
            n "Y habla de una niña que escribe poemas."
            n "Y de un hospital que nunca la deja salir."
            em "..."
            em_p "(Este poema lo he escrito yo.)"
            em_p "(¿Cuándo?)"

        "Quedarte quieta. Escuchar el pasillo.":
            $ modificar_metrica("miedo", +8)
            $ modificar_metrica("angustia", +10)
            $ gtn_flag("emi_escucha", True)
            $ registrar_decision()

            em "..."
            n "Cierras los ojos. Escuchas."
            n "El fluorescente zumba. El aire se mueve."
            n "Y entonces, muy bajo, muy lejos, alguien recita."
            em "Hay alguien."
            em "Y está recitando uno de mis poemas."
            em_p "(Pero yo no he escrito eso.)"

        "Llamar. Preguntar si hay alguien.":
            $ modificar_metrica("miedo", +10)
            $ modificar_metrica("angustia", +5)
            $ gtn_flag("emi_llama", True)
            $ registrar_decision()
            $ gtn_flag("grito_alguna_vez", True)

            em "¿Hola? ¿Hay alguien?"
            n "Tu voz rebota en las paredes."
            n "Y vuelve. Pero distinta."
            n "Como si varias voces la recitaran a la vez."
            em "Eso no ha sido mi voz."
            em_p "(Han sido varias.)"
            em_p "(Y todas han recitado lo mismo.)"

    if estado_minimo("miedo", 40):
        em_p "(Me tiemblan las manos.)"
        em_p "(No debería. Solo es un hospital.)"
        em_p "(Pero los poemas están escritos por mí.)"

    if estado_extremo("angustia"):
        n "Sientes que te falta el aire. Y no hay ninguna razón para ello."
        em_p "(Respira. Respira.)"
        em_p "(No estás en peligro. Todavía.)"

    call cap08_eco_1
    $ add_achievement_with_popup(achievement_primera_decision)

    # ── Nota: el hospital ──
    call cap08_nota_hospital

    # ═══════════════════════════════════════════════════════════
    #  ACTO 2 — EL ENCUENTRO
    # ═══════════════════════════════════════════════════════════

    n "Entonces lo oyes."

    $ sonido("pasos_lentos")

    n "Pasos. Lentos. Alguien se acerca."
    n "Pero no viene de la puerta."
    n "Viene de detrás de ti."

    show kazuki_img at right
    with dissolve

    kz "..."
    kz "Hola."
    em "Hola."
    kz "No pasa nada, ¿vale?"
    em "¿Qué?"
    kz "Que no pasa nada."
    kz "Es un hospital. Un poco raro. Pero es un hospital."
    kz "Vamos a salir de aquí."

    n "El chico es alto. Pelo castaño con reflejos."
    n "Y sonríe."
    n "Sonríe como un líder."

    em "Emi."
    kz "Kazuki."
    em "Vale, Kazuki."
    kz "Vale, Emi."

    $ desbloquear_ficha("torre", "kazuki")
    $ add_achievement_with_popup(achievement_conoce_kazuki)

    n "No sabes por qué, pero no le crees."
    n "O sí. Pero no del todo."

    if gtn_flag("emi_escucha"):
        kz "Te he visto escuchar."
        kz "¿Has oído algo?"
        em "Poemas."
        kz "..."
        kz "Ya."
        kz "Yo no he oído nada."
        em "Ya."
        em "Yo tampoco los oiría si no supiera leer."
        kz "..."
        kz "Vale."
        em_p "(Ha dejado de sonreír.)"
        em_p "(Solo un momento.)"
        em_p "(Pero ha dejado de sonreír.)"

    elif gtn_flag("emi_lee"):
        kz "Te he visto leer."
        kz "¿Has encontrado algo?"
        em "Un poema."
        kz "..."
        kz "¿Un poema?"
        em "Sí. En la pared."
        kz "¿Y qué decía?"
        em "..."
        em "Hablaba de mí."
        kz "Eso no me gusta."
        em "A mí tampoco."

    elif gtn_flag("emi_llama"):
        kz "Te he oído llamar."
        kz "Pero no ha sido tu voz."
        em "¿Qué?"
        kz "Tu voz ha rebotado. Pero han sido varias."
        kz "Y todas recitaban lo mismo."
        em "..."
        em "Ya lo he oído yo también."
        kz "Entonces no estoy loco."
        em "O estamos los dos."
        kz "Peor."

    if estado_minimo("angustia", 50):
        n "Kazuki te mira. Y por un momento, ves algo en sus ojos."
        n "Cansancio. Cansancio de verdad."
        em_p "(No es solo el hospital.)"
        em_p "(Lleva esto dentro desde antes.)"

    if estado_minimo("amor", 30):
        n "Y sin embargo, sonríe. Como si todo estuviera bajo control."
        em_p "(¿Por qué sonríe?)"
        em_p "(No hay nada que sonreír.)"

    if estado_minimo("miedo", 60):
        n "Tú no sonríes. No puedes."
        em_p "(Me tiembla la voz.)"
        em_p "(No puedo dejar que lo note.)"

    if peso_tomado("cap7_cogio_mano"):
        em_p "(En el piso 7, Nao y Souta se cogieron de la mano.)"
        em_p "(Y salió bien.)"

    elif peso_tomado("cap7_confio_souta"):
        em_p "(En el piso 7, Nao confió en Souta.)"
        em_p "(Quizá debería confiar yo también.)"

    # ── Decisión 2 ──
    menu:
        "¿Cómo reaccionas?"

        "Preguntarle por qué sonríe.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("emi_pregunta", True)
            $ registrar_decision()

            em "¿Por qué sonríes?"
            kz "..."
            kz "¿Qué?"
            em "Sonríes. Desde que te he visto."
            kz "Es... una costumbre."
            em "¿Una costumbre?"
            kz "Sí."
            kz "Sonreír ayuda."
            em "¿A quién?"
            kz "..."
            kz "A mí."
            em_p "(No me lo cree ni él.)"
            em_p "(Pero no insisto.)"

        "Contarle que has oído poemas.":
            $ modificar_metrica("amor", +10)
            $ modificar_metrica("miedo", +5)
            $ gtn_flag("emi_cuenta", True)
            $ registrar_decision()

            em "He oído poemas."
            kz "¿El qué?"
            em "Poemas. Muchos. Recitados."
            kz "..."
            kz "Yo no he oído nada."
            em "Ya lo sé."
            em "No los oirías aunque quisieras."
            kz "¿Y por qué tú sí?"
            em "..."
            em "No quiero hablar de eso."
            kz "Vale. No hablamos."
            em_p "(Y por primera vez, no ha sonreído al decirlo.)"

        "Confiar en él directamente.":
            $ modificar_metrica("amor", +15)
            $ modificar_metrica("miedo", -5)
            $ gtn_flag("emi_confia", True)
            $ registrar_decision()

            em "Vale. Confío en ti."
            kz "..."
            kz "¿Así, sin más?"
            em "No tengo mucho donde elegir."
            n "Kazuki sonríe de lado. Pero la sonrisa no le llega a los ojos."
            em_p "(Sonríe como si supiera algo.)"
            em_p "(Pero no lo dice.)"

    if gtn_flag("emi_confia"):
        kz "Me alegra que confíes en mí."
        kz "Aunque no deberías."
        em "¿Qué?"
        kz "Nada. Olvídalo."
        em_p "(Ha dicho algo importante.)"
        em_p "(Pero no lo ha dicho.)"

    if estado_minimo("amor", 40) and estado_minimo("miedo", 40):
        em_p "(Le he dicho que confío en él.)"
        em_p "(Y es verdad. Pero también me da miedo.)"
        em_p "(Me da miedo que confiar en alguien salga mal.)"
        em_p "(Como siempre.)"

    if estado_extremo("odio"):
        em_p "(No debería odiarlo.)"
        em_p "(Ni siquiera lo conozco.)"
        em_p "(Pero hay algo en él que me irrita.)"
        em_p "(Como si todo le diera igual.)"

    if estado_minimo("angustia", 60):
        em_p "(Me pesa la cabeza.)"
        em_p "(Como si los poemas del hospital me estuvieran llamando.)"
        em_p "(Y no puedo dejar de leerlos.)"

    call cap08_flashback_emi_hospital
    call cap08_nota_kazuki_sonrisa

    # ═══════════════════════════════════════════════════════════
    #  OBJETO 1 — El poema en la pared
    # ═══════════════════════════════════════════════════════════

    n "En la pared, entre dos habitaciones, hay un poema."
    n "Escrito con letra temblorosa."
    n "Y firmado con un nombre."

    call screen cap08_poema_interactivo
    call cap08_pulsar_poema

    # ═══════════════════════════════════════════════════════════
    #  ACTO 3 — LA EXPLORACIÓN
    # ═══════════════════════════════════════════════════════════

    n "El hospital es más grande de lo que parecía."
    n "Hay tres zonas."
    n "Y en cada una, algo os espera."

    $ musica("tension_baja", fade=2.0)

    $ zonas_exploradas = []
    call cap08_exploracion
    jump cap08_tras_exploracion


# ═══════════════════════════════════════════════════════════════
#  TRAS LA EXPLORACIÓN
# ═══════════════════════════════════════════════════════════════
label cap08_tras_exploracion:
    scene bg_piso8_espejo
    with fade

    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "Volvéis al final del pasillo."
    n "Pero algo ha cambiado."
    n "Al fondo, hay un espejo."
    n "Que no estaba antes."
    n "Y en el espejo, hay alguien."
    n "Que no sois vosotros."

    if peso_tomado("cap7_cogio_mano"):
        n "Y por un momento, recuerdas algo."
        n "Dos figuras cruzaron por aquí. Una chica y un chico."
        n "Juntos. Cogidos de la mano."
        em_p "(¿Quiénes eran?)"
        em_p "(No los conozco.)"
        em_p "(Pero creo que los he visto en algún sitio.)"

    elif peso_tomado("cap7_confio_souta"):
        n "Y por un momento, recuerdas algo."
        n "Alguien dijo algo importante aquí. Antes."
        n "Y no llegó a terminar la frase."
        em_p "(¿Qué dijo?)"
        em_p "(¿Por qué lo recuerdo?)"

    kz "Eso no estaba antes."
    em "Ya lo veo."
    kz "¿Y ahora qué?"
    em "..."
    em "Ahora leo."

    n "Te acercas al espejo."
    n "Y en el espejo, hay un poema."
    n "Escrito con tu letra."
    n "Pero no lo has escrito tú."

    $ aprender_palabra("torre", "poema_emi")
    $ desbloquear_pista("torre", "p8_espejo")
    call cap08_nota_espejo

    call cap08_flashback_kazuki_favor
    call cap08_nota_favor
    call cap08_deduccion_1

    # ── Quirófano ──
    scene bg_piso8_quirofano
    with fade

    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "Al fondo del pasillo, una puerta entreabierta."
    n "Un quirófano."
    n "Con una mesa en el centro."
    n "Y un poema escrito en la pared."
    n "Con lo que parece sangre seca."

    kz "No me gusta esto."
    em "A mí tampoco."
    kz "¿Y si no entramos?"
    em "..."
    em "Si no entramos, no salimos."

    n "Y entonces, la mesa se mueve."
    n "Sola."
    n "Y el poema de la pared se reescribe."
    n "Solo."

    $ aprender_palabra("torre", "seis_meses")
    $ desbloquear_pista("torre", "p8_seis_meses")
    call cap08_nota_quirofano

    if estado_extremo("terror"):
        em_p "(Son muchos. Demasiados.)"
        em_p "(Y todos hablan de mí.)"
        n "Te llevas las manos a la cabeza."
        kz "Emi. Emi, mírame."
        em "Estoy bien."
        kz "No. No lo estás."
        n "Y por primera vez, no sabes qué contestar."

    if estado_minimo("amor", 50):
        kz "Sea lo que sea que leas..."
        kz "No estás sola."
        em "..."
        em_p "(No estoy sola.)"
        em_p "(Pero tampoco sé qué hacer con eso.)"

    if estado_minimo("odio", 50):
        em_p "(No quiero que me vea así.)"
        em_p "(No quiero que nadie me vea así.)"
        n "Te apartas un poco de Kazuki. Sin darte cuenta."
        kz "..."
        n "Kazuki no dice nada. Pero lo nota."

    em "Kazuki. ¿Estás leyendo eso?"
    kz "..."
    kz "No."
    em "Mentira."
    kz "..."
    kz "Sí."
    kz "Pero no quiero leerlo."

    call cap08_eco_2

    # ═══════════════════════════════════════════════════════════
    #  ACTO 4 — LA VOZ DEL ESPEJO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso8_espejo
    with fade

    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "Y entonces, el espejo habla."
    n "No susurra. Habla."
    n "Con una voz que no es de nadie."
    n "Pero que suena como alguien."

    $ sonido("espejo_habla")

    n "Y dice:"
    n "«Kazuki.»"

    kz "..."
    em "Kazuki. ¿Qué pasa?"
    kz "Nada."
    em "El espejo ha dicho tu nombre."
    kz "Ya. Pero no pasa nada, ¿vale?"
    em "Kazuki. No pasa nada."
    kz "..."
    kz "¿Qué?"
    em "Que no pasa nada."
    em "El espejo también te ha llamado a ti."
    kz "..."
    kz "¿Y qué quiere?"
    em "..."
    em "Quiere que le cuentes lo del favor."

    n "Kazuki se queda en silencio."
    n "Y por primera vez, no sonríe."
    n "No sonríe nada."

    call cap08_deduccion_2

    # ── OBJETO 2 — El espejo roto ──
    n "En una de las habitaciones, sobre la cama, hay un espejo."
    n "Pequeño. Roto."
    n "Y con un nombre grabado."

    call screen cap08_espejo_interactivo
    call cap08_pulsar_espejo

    # ── LOGROS ACUMULATIVOS ──
    if gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido") and gtn_flag("eco_3_oido"):
        $ add_achievement_with_popup(achievement_eco_completo_cap8)

    if gtn_flag("fb_emi_visto") and gtn_flag("fb_kazuki_visto"):
        $ add_achievement_with_popup(achievement_recuerdos_cap8)

    if notas_descubiertas_cap("torre", 8) >= 5:
        $ add_achievement_with_popup(achievement_notas_completas_cap8)

    if objeto_visto("poema_pared") and objeto_visto("espejo_roto"):
        $ add_achievement_with_popup(achievement_objetos_cap8)

    if deduccion_jugador_acertada("cap08_ded1") and deduccion_jugador_acertada("cap08_ded2"):
        $ add_achievement_with_popup(achievement_deducciones_cap8)

    if not gtn_flag("grito_alguna_vez"):
        $ add_achievement_with_popup(achievement_oculto_no_grito)

    if gtn_ecos_oidos >= 24:
        $ add_achievement_with_popup(achievement_oculto_oyo_todo)

    if gtn_puertas_pulsadas >= 10:
        $ add_achievement_with_popup(achievement_oculto_puertas)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 5 — LA PUERTA AL FONDO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso8_salida
    with fade

    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "Al fondo del pasillo, hay una puerta."
    n "De metal. Vieja."
    n "Con una cruz roja pintada. Descolorida."
    n "Y una luz cálida al otro lado."

    em "Es la salida."
    kz "¿Y si no lo es?"
    em "Entonces volvemos. Pero contigo."

    n "Kazuki se queda quieto un momento."
    n "Mira el espejo. Que sigue hablando."
    n "Y luego te mira a ti."

    kz "Emi."
    em "¿Sí?"
    kz "He mentido."
    em "Ya lo sé."
    kz "¿Y no me preguntas por qué?"
    em "No hace falta."
    em "Cuando quieras contarlo, lo contarás."

    n "Kazuki no dice nada."
    n "Pero por primera vez, sonríe de verdad."

    $ desbloquear_pista("torre", "p8_puerta_al_fondo")
    call cap08_nota_puerta
    call cap08_eco_3

    # ═══════════════════════════════════════════════════════════
    #  MINIJUEGO — MEMORY CON POEMAS
    # ═══════════════════════════════════════════════════════════

    $ musica("tension_alta", fade=0.5)

    n "La puerta no se abre sola."
    n "Necesita que alguien recuerde."
    n "Los poemas. En orden."
    n "Emparejar los versos."

    kz "Emi."
    kz "Tú puedes. Yo confío en ti."

    if estado_extremo("miedo"):
        em_p "(No puedo. No puedo hacerlo.)"
        em_p "(Voy a fallar. Voy a fallar.)"
        n "Te tiemblan las manos."
        kz "Emi. Mírame."
        em "..."
        kz "Vas a emparejar los versos. Y yo voy a salir contigo. ¿Vale?"
        em_p "(¿Por qué confía en mí?)"
        em_p "(No debería.)"

    if estado_minimo("terror", 60):
        em_p "(Los versos son demasiados.)"
        em_p "(No voy a recordarlos todos.)"
        em_p "(Lo sé.)"

    # Memory con poemas — elige el verso que no es de Emi
    call lanzar_elige_verso(
        versos=[
            "La niña que escribe no sabe callar.",
            "El hospital que nunca duerme me llama.",
            "Los espejos no mienten nunca.",
        ],
        correcto=2
    )

    if gtn_minijuego_resultado:
        $ registrar_minijuego(True)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Emparejas los versos en orden."
        n "Los poemas de la pared se apagan uno a uno."
        n "Y la puerta se abre."
        n "Al otro lado, la luz."
        n "Pero la puerta empieza a cerrarse."

        $ modificar_metrica("amor", +20)
        $ modificar_metrica("miedo", -5)

        em "¡Vamos!"

        menu:
            "¿Qué haces?"

            "Salir juntos, corriendo.":
                $ registrar_decision()
                $ registrar_peso("cap8_cogio_mano")
                jump cap8_final_bueno

            "Sacrificarte tú, para que él salga.":
                $ registrar_decision()
                jump cap8_final_kazuki_muere

            "Dejar que él se sacrifique, para que salgas tú.":
                $ registrar_decision()
                jump cap8_final_emi_muere

            "Cogerle la mano antes de cruzar." if estado_minimo("amor", 70) and estado_maximo("miedo", 40):
                $ modificar_metrica("amor", +15)
                $ gtn_flag("emi_cogio_mano", True)
                $ registrar_decision()
                $ registrar_peso("cap8_cogio_mano")

                em "Kazuki."
                kz "¿Sí?"
                n "No dices nada. Solo le coges la mano."
                n "Kazuki no se aparta."
                n "Y los dos cruzáis la puerta juntos."
                jump cap8_final_bueno_especial
    else:
        $ registrar_minijuego(False)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Los versos no se emparejan."
        n "La puerta tiembla."
        n "Y el espejo se rompe. Del todo."

        $ musica("final_malo", fade=1.0)
        jump cap8_final_ambos_quedan


# ═══════════════════════════════════════════════════════════════
#  FINALES DEL CAPÍTULO 8
# ═══════════════════════════════════════════════════════════════

label cap8_final_bueno:
    scene bg_piso8_salida
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    em "¡Juntos!"
    kz "¡Juntos!"
    n "Corréis los dos hacia la puerta."
    n "La cruzéis al mismo tiempo."

    $ musica("final_bueno", fade=2.0)
    scene cap8_final_bueno
    with Dissolve(1.5)

    n "La luz os traga."
    n "Y luego, silencio."
    n "Detrás de vosotros, los poemas se borran."
    n "Y el espejo, por fin, se apaga."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 8 superado."

    $ registrar_final_bueno()
    $ registrar_ruta(8, "bueno")
    $ guardar_estados_capitulo(8, "torre")
    $ unlock_final("torre", 8, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap8)
    $ add_achievement_with_popup(achievement_cap8_completado)
    $ desbloquear_imagen_galeria("cap8_bueno")
    $ capitulos.completar_capitulo("torre", 8)
    call marcar_final_bueno_cap(8, "torre")
    $ desbloquear_invocaciones_hasta(8)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("emi_confia"):
        $ registrar_peso("cap8_confio_kazuki")
    if gtn_flag("emi_pregunta"):
        $ registrar_peso("cap8_pregunto_kazuki")

    "Capítulo 8 completado."
    jump volver_al_hub


label cap8_final_bueno_especial:
    scene bg_piso8_salida
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "Cruzasteis juntos. Con las manos cogidas."
    n "Y al otro lado, por primera vez, no había silencio."
    n "Había una puerta abierta. Y detrás, luz."

    $ musica("final_bueno", fade=2.0)
    scene cap8_final_especial
    with Dissolve(1.5)

    n "Pero no era la salida."
    n "Era otra cosa."
    n "Era el inicio de algo que ninguno de los dos había previsto."
    n "Y Emi, por primera vez, se vio en un espejo."
    n "Y su reflejo sonreía."
    n "Pero ella no."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 8 superado. Pero no del todo."

    $ registrar_final_bueno()
    $ registrar_ruta(8, "bueno_especial")
    $ registrar_peso("cap8_cogio_mano")
    $ guardar_estados_capitulo(8, "torre")
    $ unlock_final("torre", 8, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap8)
    $ add_achievement_with_popup(achievement_cap8_completado)
    $ add_achievement_with_popup(achievement_final_especial_cap8)
    $ desbloquear_imagen_galeria("cap8_bueno")
    $ capitulos.completar_capitulo("torre", 8)
    call marcar_final_bueno_cap(8, "torre")
    $ desbloquear_invocaciones_hasta(8)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("emi_confia"):
        $ registrar_peso("cap8_confio_kazuki")
    if gtn_flag("emi_pregunta"):
        $ registrar_peso("cap8_pregunto_kazuki")

    "Capítulo 8 completado (ruta especial)."
    jump volver_al_hub


label cap8_final_emi_muere:
    scene bg_piso8_salida
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    kz "Emi, espera—"
    em "Es mi turno."
    n "Kazuki cruza."
    n "Tú te quedas. Mirando el espejo."
    n "Que ya no habla."
    n "Solo espera."
    em "..."
    em "Vale. Ya voy."
    n "Y la puerta se cierra."

    $ musica("final_malo", fade=1.5)
    scene cap8_final_emi_muere
    with Dissolve(1.0)

    n "Al otro lado, Kazuki se queda solo."
    n "Al fondo del pasillo."
    n "Con un poema en la mano."
    n "Que no es suyo."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El espejo se llena."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(8, "emi_muere")
    $ guardar_estados_capitulo(8, "torre")
    $ unlock_final("torre", 8, "emi_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap8_completado)
    $ desbloquear_imagen_galeria("cap8_emi_muere")
    $ capitulos.completar_capitulo("torre", 8)
    $ desbloquear_invocaciones_hasta(8)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("emi_confia"):
        $ registrar_peso("cap8_confio_kazuki")
    if gtn_flag("emi_pregunta"):
        $ registrar_peso("cap8_pregunto_kazuki")

    "Capítulo 8 completado (final malo)."
    jump volver_al_hub


label cap8_final_kazuki_muere:
    scene bg_piso8_salida
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    em "Ve tú. Yo me quedo."
    kz "Ni hablar."
    em "Es una orden."
    kz "..."
    kz "No eres mi jefa."
    em "Pero soy la que escribe."
    n "Y te sacrificas. Y Kazuki cruza."

    $ musica("final_malo", fade=1.5)
    scene cap8_final_kazuki_muere
    with fade

    n "Al otro lado, Emi se queda sola."
    n "Sin sonrisa."
    n "Con un espejo roto en la mano."
    n "Que no es suyo."
    n "Y con la voz de Kazuki, muy baja."
    n "Que dice: «No pasa nada, ¿vale?»."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El espejo se llena. Pero no del todo."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(8, "kazuki_muere")
    $ guardar_estados_capitulo(8, "torre")
    $ unlock_final("torre", 8, "kazuki_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap8_completado)
    $ desbloquear_imagen_galeria("cap8_kazuki_muere")
    $ capitulos.completar_capitulo("torre", 8)
    $ desbloquear_invocaciones_hasta(8)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("emi_confia"):
        $ registrar_peso("cap8_confio_kazuki")
    if gtn_flag("emi_pregunta"):
        $ registrar_peso("cap8_pregunto_kazuki")

    "Capítulo 8 completado (final malo)."
    jump volver_al_hub


label cap8_final_ambos_quedan:
    scene bg_piso8_espejo
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "El espejo se rompe."
    n "Y vosotros os quedáis."
    n "Sentados en el pasillo."
    n "Sin hablar."
    n "Solo leyendo."
    n "Y los poemas, por fin, se borran."

    $ musica("final_malo", fade=1.0)
    scene cap8_final_ambos
    with fade

    n "Con los versos. Con los espejos."
    n "Con las paredes."
    n "Y con vosotros."
    n "Que ya no sois vosotros."
    n "Sois reflejos. En un espejo."
    n "Que alguien mirará."
    n "Algún día."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El reflejo se llena."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(8, "ambos_quedan")
    $ guardar_estados_capitulo(8, "torre")
    $ unlock_final("torre", 8, "ambos_quedan")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap8_completado)
    $ desbloquear_imagen_galeria("cap8_ambos")
    $ capitulos.completar_capitulo("torre", 8)
    $ desbloquear_invocaciones_hasta(8)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("emi_confia"):
        $ registrar_peso("cap8_confio_kazuki")
    if gtn_flag("emi_pregunta"):
        $ registrar_peso("cap8_pregunto_kazuki")

    "Capítulo 8 completado (final malo)."
    jump volver_al_hub


label cap8_final_secreto:
    scene bg_piso8_espejo
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    em "Ve tú. Yo me quedo."
    kz "¡No!"
    em "Confía en mí."
    n "Empujas a Kazuki hacia la puerta."
    n "Pero no te quedas atrás."
    n "Te acercas al espejo."
    n "Y te asomas."

    $ musica("final_malo", fade=1.5)
    scene cap8_final_secreto
    with fade

    n "La puerta se cierra detrás de Kazuki."
    n "Y tú te quedas."
    n "Pero no muerta."
    n "Te quedas... reflejada."
    n "Y el espejo, por primera vez, te responde."
    n "Con una voz que no es de nadie."
    n "Pero que suena como alguien."
    n "Y dice: «Bienvenida»."

    $ sonido("espejo_habla")
    elyon_voz "{i}Bienvenida, Emi.{/i}"

    n "Y el espejo, en el fondo, tiene una cara."
    n "Y la cara es tuya."
    n "Pero no eres tú."
    n "Todavía."

    scene black
    with fade
    $ parar_todo(fade=2.0)

    $ registrar_final_malo()
    $ registrar_ruta(8, "secreto")
    $ guardar_estados_capitulo(8, "torre")
    $ unlock_final("torre", 8, "secreto")
    $ add_achievement_with_popup(achievement_cap8_completado)
    $ add_achievement_with_popup(achievement_primera_ruta)
    $ desbloquear_imagen_galeria("cap8_secreto")
    $ capitulos.completar_capitulo("torre", 8)
    $ desbloquear_invocaciones_hasta(8)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("emi_confia"):
        $ registrar_peso("cap8_confio_kazuki")
    if gtn_flag("emi_pregunta"):
        $ registrar_peso("cap8_pregunto_kazuki")

    "Capítulo 8 completado (ruta secreta)."
    jump volver_al_hub


# ═══════════════════════════════════════════════════════════════
#  EXPLORACIÓN CON FLECHAS
# ═══════════════════════════════════════════════════════════════
label cap08_exploracion:

    call screen cap08_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap08_zona1

    call screen cap08_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap08_zona2

    call screen cap08_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap08_zona3

    return


screen cap08_exploracion_screen(zonas):
    modal True
    add "bg_piso8_despertar"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20

        text "EXPLORA EL HOSPITAL" size 30 color "#FFFFFF" xalign 0.5
        text "Zonas exploradas: [len(zonas)] / 3" size 18 color "#AAAAAA" xalign 0.5
        null height 20

        vbox:
            spacing 30
            xalign 0.5

            if 1 not in zonas:
                textbutton "→ Explorar las HABITACIONES" action Return(1) style "menu_button" xalign 0.5
            else:
                text "✔ Habitaciones (explorado)" size 16 color "#666" xalign 0.5

            if 2 not in zonas:
                textbutton "↑ Explorar el QUIRÓFANO" action Return(2) style "menu_button" xalign 0.5
            else:
                text "✔ Quirófano (explorado)" size 16 color "#666" xalign 0.5

            if 3 not in zonas:
                textbutton "↓ Bajar al ESPEJO DEL PASILLO" action Return(3) style "menu_button" xalign 0.5
            else:
                text "✔ Espejo (explorado)" size 16 color "#666" xalign 0.5


label cap08_zona1:
    scene bg_piso8_habitaciones
    with fade
    show emi_img at left
    with dissolve

    n "La sala de las habitaciones es interminable."
    n "Cada cama tiene un poema."
    n "Y todos están escritos por ti."

    em "..."
    em "Son muchos."

    show kazuki_img at right
    with dissolve

    kz "¿Qué son?"
    em "Poemas. Uno por persona."
    kz "¿Y por qué hay tantos?"
    em "Porque mucha gente ha pasado por aquí."
    kz "..."
    kz "¿Y todos están... muertos?"
    em "..."
    em "Algunos sí."
    em "Otros no."

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    return


label cap08_zona2:
    scene bg_piso8_quirofano
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "El quirófano está en silencio."
    n "Una mesa en el centro."
    n "Instrumentos quirúrgicos."
    n "Y un poema en la pared."
    n "Con sangre seca."

    kz "¿Y ese?"
    em "Está escrito en sangre."
    kz "¿Y eso qué significa?"
    em "..."
    em "Que alguien ha dejado de escribir."
    kz "..."
    kz "No me gusta eso."

    $ desbloquear_pista("torre", "p8_seis_meses")
    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("terror", +5)

    return


label cap08_zona3:
    scene bg_piso8_espejo
    with fade
    show emi_img at left
    show kazuki_img at right
    with dissolve

    n "El espejo está en el centro del pasillo."
    n "Es grande. Antiguo."
    n "Y desde el fondo, suben reflejos."

    kz "¿Los ves?"
    em "Sí."
    kz "¿Qué son?"
    em "..."
    em "Reflejos."
    kz "¿Y qué esperan?"
    em "Que los miremos."
    kz "..."
    kz "¿Y cuándo los miramos?"
    em "..."
    em "Cuando yo parpadee."
    kz "..."
    kz "Entonces no parpadees."
    em "..."
    em "No puedo evitarlo."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)

    return