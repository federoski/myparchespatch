# ═══════════════════════════════════════════════════════════════
#  57cap08_deducciones.rpy — Deducciones del Capítulo 8
#  -----------------------------------------------------------------
#  2 momentos donde el jugador debe deducir algo.
#  Acertar → recompensa (pista al tablón + marca deducción).
#  Fallar → nada.
#
#  ⚠️ Reutilizamos el screen `deduccion_screen` (definido en
#     50cap01_deducciones.rpy).
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 1 — ¿Por qué el espejo refleja a otra persona?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 3, después del flashback de Kazuki.
#  Pregunta: ¿Por qué crees que el espejo refleja a otra persona?
#  Respuesta correcta: "Porque refleja lo que debería haber sido."
# ═══════════════════════════════════════════════════════════════
label cap08_deduccion_1:

    n "..."

    n "Emi se queda callada un momento."

    n "Y el espejo, en el pasillo, sigue esperando."

    em_p "(Refleja a alguien.)"
    em_p "(Pero no es nadie.)"
    em_p "(O sí.)"
    em_p "(¿Por qué refleja a otra persona?)"

    # ── Deducción interactiva ──
    call screen deduccion_screen(
        pregunta="¿Por qué crees que el espejo refleja a otra persona?",
        opciones=[
            "Porque está encantado. Como el hospital.",
            "Porque refleja lo que debería haber sido.",
            "Porque quiere avisarnos de algo."
        ],
        correcta=1,
        pista_ok="El espejo no está encantado. Ni avisa de nada. Refleja lo que debería haber sido. La versión de ti que salió del hospital. La versión de ti que nunca volvió. Y esa versión te mira. Y espera.",
        pista_fallo="No está encantado. Ni avisa. Refleja lo que debería haber sido. La versión de ti que no volvió. La que se quedó dentro.",
        pista_key="p8_espejo",
        clave_ded="cap08_ded1"
    )

    if deduccion_jugador_acertada("cap08_ded1"):
        $ add_achievement_with_popup(achievement_primera_deduccion)

    return


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 2 — ¿Qué pasó realmente con el favor de Kazuki?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 4, después del eco 2.
#  Pregunta: ¿Qué crees que pasó realmente con el favor de Kazuki?
#  Respuesta correcta: "No fue culpa suya. Pero él cree que sí."
# ═══════════════════════════════════════════════════════════════
label cap08_deduccion_2:

    n "Kazuki se queda en silencio."

    n "Y el espejo, por primera vez, no dice su nombre."

    n "Dice otra cosa."

    n "Dice: «No fue culpa tuya»."

    kz_p "(No.)"
    kz_p "(Sí que lo fue.)"
    kz_p "(Yo conté los votos.)"
    kz_p "(Yo.)"

    em_p "(Dice que no fue su culpa.)"
    em_p "(Pero él no lo cree.)"
    em_p "(¿Y si el espejo tiene razón?)"

    # ── Deducción interactiva ──
    call screen deduccion_screen(
        pregunta="¿Qué crees que pasó realmente con el favor de Kazuki?",
        opciones=[
            "Kazuki cambió los votos. Y su rival perdió. Es culpable.",
            "No fue culpa suya. Pero él cree que sí.",
            "No fue un favor. Alguien le obligó."
        ],
        correcta=1,
        pista_ok="El espejo no miente. Y el espejo dice que no fue culpa suya. Kazuki cambió un voto, sí. Pero su rival no perdió por eso. Perdió por otra cosa. Y Kazuki, desde hace dos años, no se lo cree. Y el espejo se alimenta de esa culpa.",
        pista_fallo="Kazuki no es culpable. Pero él cree que sí. Cambió un voto. Pero su rival no perdió por eso. Perdió por otra cosa. Y esa creencia es lo que el espejo está comiendo.",
        pista_key="p8_favor_kazuki",
        clave_ded="cap08_ded2"
    )

    if deduccion_jugador_acertada("cap08_ded2"):
        $ add_achievement_with_popup(achievement_segunda_deduccion)

    return