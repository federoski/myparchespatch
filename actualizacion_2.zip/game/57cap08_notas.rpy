# ═══════════════════════════════════════════════════════════════
#  57cap08_notas.rpy — Notas de Emi (Capítulo 8)
#  -----------------------------------------------------------------
#  Apuntes que Emi escribe durante el capítulo.
#  Se añaden al sistema de notas existente (50cap01_notas.rpy).
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Añadir las notas del Cap 8 al catálogo existente ──
    if "torre" not in NOTAS:
        NOTAS["torre"] = {}

    NOTAS["torre"].update({
        "nota8_hospital": {
            "titulo": "El hospital",
            "icono": "🏥",
            "capitulo": 8,
            "texto": (
                "Es un hospital. Con pasillos. Con habitaciones. Con un quirófano. "
                "Las paredes están cubiertas de poemas. Todos escritos con mi letra. "
                "Pero yo no los he escrito. O eso creo. "
                "Porque a veces, cuando los leo, recuerdo haberlos escrito. "
                "Y otras veces, no recuerdo nada. "
                "Y el espejo del pasillo... el espejo me mira. "
                "Como si supiera algo que yo no sé."
            ),
        },
        "nota8_espejo": {
            "titulo": "El espejo del pasillo",
            "icono": "🪞",
            "capitulo": 8,
            "texto": (
                "Hay un espejo al final del pasillo. Es grande. Antiguo. "
                "Y en su reflejo, el hospital es distinto. Más limpio. Más brillante. "
                "Y hay alguien. Que no soy yo. Que no es Kazuki. "
                "Que a veces se parece a mí. Pero no. "
                "El espejo refleja lo que debería haber sido. "
                "Y lo que debería haber sido no es lo que es."
            ),
        },
        "nota8_kazuki_sonrisa": {
            "titulo": "La sonrisa de Kazuki",
            "icono": "🙂",
            "capitulo": 8,
            "texto": (
                "Kazuki sonríe. Siempre. Desde que lo he conocido. "
                "Sonríe cuando habla. Sonríe cuando escucha. "
                "Sonríe cuando no hay nada que sonreír. "
                "Pero la sonrisa no le llega a los ojos. "
                "Y cuando cree que no lo miro, se le cae. "
                "Y se le queda la cara seria. Muy seria. "
                "Como si estuviera aguantando algo. Algo que no puede decir."
            ),
        },
        "nota8_favor": {
            "titulo": "El favor",
            "icono": "🤝",
            "capitulo": 8,
            "texto": (
                "Kazuki me ha contado lo del favor. "
                "Que fingió su presidencia. Que la compró. "
                "Que hay favores que aún paga. "
                "Pero hay algo que no me cuadra. "
                "El espejo dice que no fue culpa suya. Y el espejo no miente. "
                "Pero Kazuki no se lo cree. Y por eso el espejo se alimenta."
            ),
        },
        "nota8_puerta_al_fondo": {
            "titulo": "La puerta al fondo",
            "icono": "🚪",
            "capitulo": 8,
            "texto": (
                "Al fondo del pasillo, detrás del espejo, hay una puerta. "
                "De metal. Con una cruz roja. Descolorida. "
                "Y al otro lado, luz cálida. "
                "Pero no se abre sola. Necesita que alguien recuerde. "
                "Los poemas. En orden. Pulsar en el momento justo. "
                "Como si el hospital quisiera comprobar que todavía sé leer."
            ),
        },
    })


# ═══════════════════════════════════════════════════════════════
#  LABELS DE LLAMADA — Notas del Cap 8
# ═══════════════════════════════════════════════════════════════

# ── Nota: el hospital ──
label cap08_nota_hospital:
    n "..."

    em_p "(Debería apuntar esto.)"
    em_p "(Antes de que se me olvide.)"

    $ desbloquear_nota("torre", "nota8_hospital")

    n "Sacas un bolígrafo del bolsillo. No recuerdas tenerlo."

    n "Pero lo tienes. Y escribes en la palma de la mano."

    return


# ── Nota: el espejo del pasillo ──
label cap08_nota_espejo:
    $ desbloquear_nota("torre", "nota8_espejo")
    return


# ── Nota: la sonrisa de Kazuki ──
label cap08_nota_kazuki_sonrisa:
    $ desbloquear_nota("torre", "nota8_kazuki_sonrisa")
    return


# ── Nota: el favor ──
label cap08_nota_favor:
    $ desbloquear_nota("torre", "nota8_favor")
    return


# ── Nota: la puerta al fondo ──
label cap08_nota_puerta:
    $ desbloquear_nota("torre", "nota8_puerta_al_fondo")
    return


# ── Nota: el quirófano (extra, llamada desde zona2) ──
label cap08_nota_quirofano:
    $ desbloquear_nota("torre", "nota8_hospital")
    return