# ═══════════════════════════════════════════════════════════════
#  56cap07_notas.rpy — Notas de Nao (Capítulo 7)
#  -----------------------------------------------------------------
#  Apuntes que Nao escribe durante el capítulo.
#  Se añaden al sistema de notas existente (50cap01_notas.rpy).
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Añadir las notas del Cap 7 al catálogo existente ──
    if "torre" not in NOTAS:
        NOTAS["torre"] = {}

    NOTAS["torre"].update({
        "nota7_carpa": {
            "titulo": "La carpa",
            "icono": "🎪",
            "capitulo": 7,
            "texto": (
                "Es una carpa. Roja y blanca. Rasgada. "
                "Con un foco encendido. Uno solo. "
                "Y al fondo, un círculo iluminado. El centro del espectáculo. "
                "Vacío. O eso creía. "
                "Porque el serrín se mueve. Y hay una máscara. "
                "Rota. Con mi nombre dentro."
            ),
        },
        "nota7_publico": {
            "titulo": "El público",
            "icono": "👥",
            "capitulo": 7,
            "texto": (
                "El público no tiene cara. "
                "Pero está ahí. En las gradas. Sentado. Quieto. "
                "Y no respira. "
                "Y cuando sonrío, aplauden. Una sola vez. "
                "Y cuando dejo de sonreír, esperan. "
                "Como si mi sonrisa fuera la función. "
                "Y yo no puedo dejar de sonreír. "
                "Aunque quiera."
            ),
        },
        "nota7_souta_silencio": {
            "titulo": "El silencio de Souta",
            "icono": "🤫",
            "capitulo": 7,
            "texto": (
                "Souta no sonríe. Nunca. "
                "Ni cuando habla. Ni cuando escucha. "
                "Ni cuando no hay nada que sonreír. "
                "Y dice que no sonreír le ayuda. "
                "Pero yo no le creo. "
                "Porque cuando cree que no lo miro, se tapa los oídos. "
                "Como si oyera algo. "
                "Algo que yo no oigo. "
                "Y que no puede decir."
            ),
        },
        "nota7_huida": {
            "titulo": "La huida",
            "icono": "🚪",
            "capitulo": 7,
            "texto": (
                "Souta se fue de casa. "
                "A los 18. Sin decir nada. "
                "Sin dejar nota. Sin llamar. "
                "Y desde entonces, no soporta el silencio. "
                "Porque el silencio es lo que dejó atrás. "
                "Y por eso no sonríe. "
                "Porque sonreír sería volver. "
                "Y no puede volver."
            ),
        },
        "nota7_puerta_al_fondo": {
            "titulo": "La puerta al fondo",
            "icono": "🚪",
            "capitulo": 7,
            "texto": (
                "Al fondo de la carpa, detrás del círculo, hay una puerta. "
                "De madera. Con una estrella pintada. Descolorida. "
                "Y al otro lado, luz cálida. "
                "Pero no se abre sola. Necesita que alguien escuche. "
                "Los aplausos. En orden. Pulsar en el momento justo. "
                "Como si la carpa quisiera comprobar que todavía sé sonreír. "
                "Y yo no sé hacer otra cosa."
            ),
        },
    })


# ═══════════════════════════════════════════════════════════════
#  LABELS DE LLAMADA — Notas del Cap 7
# ═══════════════════════════════════════════════════════════════

# ── Nota: la carpa ──
label cap07_nota_carpa:
    n "..."

    naop "(Debería apuntar esto.)"
    naop "(Antes de que se me olvide.)"

    $ desbloquear_nota("torre", "nota7_carpa")

    n "Sacas un bolígrafo del bolsillo. No recuerdas tenerlo."

    n "Pero lo tienes. Y escribes en la palma de la mano."

    return


# ── Nota: el público ──
label cap07_nota_publico:
    $ desbloquear_nota("torre", "nota7_publico")
    return


# ── Nota: el silencio de Souta ──
label cap07_nota_souta_silencio:
    $ desbloquear_nota("torre", "nota7_souta_silencio")
    return


# ── Nota: la huida ──
label cap07_nota_huida:
    $ desbloquear_nota("torre", "nota7_huida")
    return


# ── Nota: la puerta al fondo ──
label cap07_nota_puerta:
    $ desbloquear_nota("torre", "nota7_puerta_al_fondo")
    return


# ── Nota: los espejos (extra, llamada desde zona1) ──
label cap07_nota_espejos:
    $ desbloquear_nota("torre", "nota7_carpa")
    return


# ── Nota: la caja (extra, llamada desde objeto caja) ──
label cap07_nota_caja:
    $ desbloquear_nota("torre", "nota7_souta_silencio")
    return