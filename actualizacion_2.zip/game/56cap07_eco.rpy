# ═══════════════════════════════════════════════════════════════
#  56cap07_eco.rpy — Apariciones de El·yon en el Capítulo 7
# ═══════════════════════════════════════════════════════════════

# ⚠️ Los transforms y screens (eco_elyon_visual, eco_lateral_visual)
#    ya están definidos en 55cap06_eco.rpy — NO se redefinen.


# ═══════════════════════════════════════════════════════════════
#  ECO 1 — Muy sutil (Acto 1)
# ═══════════════════════════════════════════════════════════════
label cap07_eco_1:

    n "Y entonces, muy lejos..."

    n "Algo."

    show screen eco_lateral_visual("Nao...", pos="der")

    $ sonido("elyon")

    n "Un susurro. Una sola palabra."

    n "Tan baja que casi no la oyes."

    pause 1.5

    naop "(¿Qué ha sido eso?)"
    naop "(Nada. Habrá sido el foco.)"
    naop "(...Pero el foco no habla.)"

    $ modificar_metrica("miedo", +3)

    $ desbloquear_relacion_elyon("torre", "nao")

    $ gtn_flag("eco_1_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 2 — Más notoria (Acto 3)
# ═══════════════════════════════════════════════════════════════
label cap07_eco_2:

    pause 1.0

    n "..."

    n "El silencio se estira."

    n "Y entonces..."

    show screen eco_elyon_visual("No sonrías")

    $ sonido("elyon")

    n "La voz vuelve."

    n "Pero esta vez dice algo distinto."

    n "Repite lo que tú has pensado antes."

    if gtn_flag("nao_escucha"):
        elyon_voz "{i}Hay alguien.{/i}"
        naop "(Eso he dicho.)"
        naop "(Cuando he cerrado los ojos.)"
        naop "(Lo ha copiado. Palabra por palabra.)"
    elif gtn_flag("nao_sube"):
        elyon_voz "{i}¿Y por qué está rota?{/i}"
        naop "(Eso pensé.)"
        naop "(Al ver la máscara.)"
        naop "(Pero no lo dije.)"
    elif gtn_flag("nao_llama"):
        elyon_voz "{i}Han sido varias.{/i}"
        naop "(Eso es lo que pensé.)"
        naop "(Cuando oí mi voz repetida.)"
        naop "(Con otro tono.)"

    so "¿Nao? ¿Estás bien?"

    nao "Sí. Sí, estoy bien."

    so "Te has quedado quieta."

    nao "Estaba... pensando."

    so "Ya."

    n "Souta no insiste. Pero te mira un segundo más de lo necesario."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)
    $ modificar_metrica("terror", +5)

    $ desbloquear_pista("torre", "p7_espejo_nao")
    $ desbloquear_relacion_elyon("torre", "nao")

    $ gtn_flag("eco_2_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 3 — Clímax (Acto 5)
# ═══════════════════════════════════════════════════════════════
label cap07_eco_3:

    if not (gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido")):
        return

    pause 1.5

    n "Antes de que puedas decidir..."

    n "La voz vuelve."

    n "Pero esta vez, no susurra."

    n "Habla."

    show screen eco_elyon_visual("El público no es público")

    pause 2.0

    show screen eco_elyon_visual("Es un espejo")

    pause 1.5

    $ sonido("elyon")

    elyon_voz "{i}Y tú vas a reflejarte.{/i}"

    pause 1.0

    n "Y el silencio."

    nao "..."
    so "¿Nao?"
    nao "Nada. Vamos."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +10)

    $ desbloquear_relacion_elyon("torre", "nao")
    $ desbloquear_relacion_elyon("torre", "souta")

    $ gtn_flag("eco_3_oido", True)
    $ gtn_ecos_oidos += 1

    return