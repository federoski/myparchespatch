# ═══════════════════════════════════════════════════════════════
#  08persistencia.rpy — Persistencia avanzada por historia
# ═══════════════════════════════════════════════════════════════

default persistent.gtn_stats = {
    "por_historia": {
        # "torre": {
        #     "decisiones_tomadas": 0,
        #     "muertes": 0,
        #     "finales_buenos": 0,
        #     "finales_malos": 0,
        #     "minijuegos_superados": 0,
        #     "minijuegos_fallados": 0,
        #     "capitulos_jugados": [],
        #     "rutas_completadas": [],
        # }
    },
    "partidas_totales": 0,
}

default persistent.gtn_galeria = {}
default persistent.gtn_flags_globales = {}
default persistent.gtn_estados_por_cap = {}   # { "torre": { 1: {...}, 2: {...} } }


init python:
    def _stats_historia(historia):
        """Devuelve (y crea si no existe) el dict de stats de una historia."""
        if "por_historia" not in persistent.gtn_stats:
            persistent.gtn_stats["por_historia"] = {}
        if historia not in persistent.gtn_stats["por_historia"]:
            persistent.gtn_stats["por_historia"][historia] = {
                "decisiones_tomadas": 0,
                "muertes": 0,
                "finales_buenos": 0,
                "finales_malos": 0,
                "minijuegos_superados": 0,
                "minijuegos_fallados": 0,
                "capitulos_jugados": [],
                "rutas_completadas": [],
            }
        return persistent.gtn_stats["por_historia"][historia]

    def stats(historia):
        """Atajo para leer stats de una historia."""
        return _stats_historia(historia)


    # -----------------------------------------------------------------
    # FUNCIONES DE REGISTRO
    # -----------------------------------------------------------------
    def registrar_decision(historia="torre"):
        _stats_historia(historia)["decisiones_tomadas"] += 1

    def registrar_muerte(historia="torre"):
        _stats_historia(historia)["muertes"] += 1

    def registrar_final_bueno(historia="torre"):
        _stats_historia(historia)["finales_buenos"] += 1

    def registrar_final_malo(historia="torre"):
        _stats_historia(historia)["finales_malos"] += 1

    def registrar_capitulo_jugado(cap, historia="torre"):
        caps = _stats_historia(historia)["capitulos_jugados"]
        if cap not in caps:
            caps.append(cap)

    def registrar_ruta(cap, ruta_id, historia="torre"):
        clave = "cap:{}:{}".format(cap, ruta_id)
        rutas = _stats_historia(historia)["rutas_completadas"]
        if clave not in rutas:
            rutas.append(clave)

    def registrar_minijuego(exito, historia="torre"):
        if exito:
            _stats_historia(historia)["minijuegos_superados"] += 1
        else:
            _stats_historia(historia)["minijuegos_fallados"] += 1

    def registrar_partida_nueva():
        persistent.gtn_stats["partidas_totales"] = persistent.gtn_stats.get("partidas_totales", 0) + 1


    # -----------------------------------------------------------------
    # ESTADOS MENTALES POR CAPÍTULO (POR HISTORIA)
    # -----------------------------------------------------------------
    def guardar_estados_capitulo(cap, historia="torre"):
        if "gtn_estados_por_cap" not in persistent.__dict__ or persistent.gtn_estados_por_cap is None:
            persistent.gtn_estados_por_cap = {}
        if historia not in persistent.gtn_estados_por_cap:
            persistent.gtn_estados_por_cap[historia] = {}
        persistent.gtn_estados_por_cap[historia][cap] = {
            "amor": store.amor,
            "odio": store.odio,
            "terror": store.terror,
            "miedo": store.miedo,
            "angustia": store.angustia,
        }

    def get_estados_capitulo(cap, historia="torre"):
        if "gtn_estados_por_cap" not in persistent.__dict__ or persistent.gtn_estados_por_cap is None:
            return None
        return persistent.gtn_estados_por_cap.get(historia, {}).get(cap, None)

    def get_estados_actuales():
        return {
            "amor": store.amor,
            "odio": store.odio,
            "terror": store.terror,
            "miedo": store.miedo,
            "angustia": store.angustia,
        }

    def promedio_estados_historia(historia="torre"):
        if "gtn_estados_por_cap" not in persistent.__dict__ or not persistent.gtn_estados_por_cap:
            return {"amor": 0, "odio": 0, "terror": 0, "miedo": 0, "angustia": 0}
        caps = list(persistent.gtn_estados_por_cap.get(historia, {}).values())
        if not caps:
            return {"amor": 0, "odio": 0, "terror": 0, "miedo": 0, "angustia": 0}
        total = {"amor": 0, "odio": 0, "terror": 0, "miedo": 0, "angustia": 0}
        for c in caps:
            for k in total:
                total[k] += c.get(k, 0)
        for k in total:
            total[k] = int(total[k] / len(caps))
        return total


    # -----------------------------------------------------------------
    # GALERÍA
    # -----------------------------------------------------------------
    def desbloquear_imagen_galeria(clave):
        if "gtn_galeria" not in persistent.__dict__ or persistent.gtn_galeria is None:
            persistent.gtn_galeria = {}
        persistent.gtn_galeria[clave] = True

    def imagen_galeria_desbloqueada(clave):
        if "gtn_galeria" not in persistent.__dict__ or persistent.gtn_galeria is None:
            return False
        return persistent.gtn_galeria.get(clave, False)

    def total_imagenes_galeria():
        if "gtn_galeria" not in persistent.__dict__ or persistent.gtn_galeria is None:
            return 0
        return len(persistent.gtn_galeria)


    # -----------------------------------------------------------------
    # RESET
    # -----------------------------------------------------------------
    def reset_stats():
        persistent.gtn_stats = {"por_historia": {}, "partidas_totales": 0}
        persistent.gtn_galeria = {}
        persistent.gtn_flags_globales = {}
        persistent.gtn_estados_por_cap = {}


    # -----------------------------------------------------------------
    # PESOS / FLAGS DE CAPÍTULO (para decisiones que afectan a capítulos siguientes)
    # -----------------------------------------------------------------
    def registrar_peso(clave, historia="torre"):
        """Registra una decisión con peso narrativo para capítulos futuros."""
        if not hasattr(persistent, "gtn_pesos") or persistent.gtn_pesos is None:
            persistent.gtn_pesos = {}
        if historia not in persistent.gtn_pesos:
            persistent.gtn_pesos[historia] = {}
        persistent.gtn_pesos[historia][clave] = True

    def peso_tomado(clave, historia="torre"):
        """Comprueba si una decisión con peso fue tomada."""
        if not hasattr(persistent, "gtn_pesos") or persistent.gtn_pesos is None:
            return False
        return persistent.gtn_pesos.get(historia, {}).get(clave, False)

    def reset_pesos():
        """Limpia todos los pesos (para nueva partida)."""
        persistent.gtn_pesos = {}