# ═══════════════════════════════════════════════════════════════
#  56cap07_flashbacks.rpy — Flashbacks del Capítulo 7
#  -----------------------------------------------------------------
#  2 escenas del pasado de Nao y Souta.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES PARA FLASHBACKS
# ─────────────────────────────────────────────────────────────

# Nao en flashback (voz más joven, más frágil)
define na_old = Character(
    "Nao",
    color="#f48fb1",
    what_color="#f8d0e0",
    what_italic=True,
    what_size=28
)

# Souta en flashback (voz más joven, antes de la huida)
define su_old = Character(
    "Souta",
    color="#9575cd",
    what_color="#d0c8e8",
    what_italic=True,
    what_size=28
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE FLASHBACK
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Circo de la infancia de Nao (flashback)
# Archivo: images/fondos/cap07/flash_nao_circo.png
# Prompt: Anime dark psychological horror scene, soft melancholic
#         tone with a hint of nostalgia. The interior of a small
#         traveling circus at night, seen from backstage. Warm
#         lights, red velvet curtains, wooden crates. In the
#         foreground, a small girl (Nao, 7 years old, pale pink
#         hair) sits on a crate, painting her own face with a
#         tiny mirror. She is smiling — but the smile doesn't
#         reach her eyes. An older clown (silhouette) watches
#         from the shadows. Atmosphere: the moment a mask is
#         chosen. Warm muted palette, soft golden light. 16:9.
image bg_flash_nao_circo = Solid("#3a2f24")

# 🎨 PROMPT IMAGEN — Casa de Souta de noche (flashback)
# Archivo: images/fondos/cap07/flash_souta_huida.png
# Prompt: Anime dark psychological horror scene, melancholic tone.
#         A suburban Japanese house at 3 AM, seen from the street.
#         All lights off except one window on the second floor.
#         A teenage boy (Souta, 17 years old, dark violet hair)
#         stands at the front gate with a backpack, looking back
#         at the house one last time. Rain has just stopped. The
#         asphalt shines. No one is watching him leave. Atmosphere:
#         the second before a decision that cannot be undone.
#         Cold palette: deep blues, wet blacks, one warm window.
#         16:9, no text.
image bg_flash_souta_huida = Solid("#1a1e28")


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 1 — Nao en el circo de su infancia
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Nao recuerda el día que aprendió a sonreír.
# ═══════════════════════════════════════════════════════════════
label cap07_flashback_nao_mascara:

    # ── Transición ──
    n "..."

    n "Y por un momento, dejas de estar aquí."

    scene bg_flash_nao_circo
    with Dissolve(1.0)

    # ── Indicador visual de flashback ──
    show screen flashback_overlay

    # ── Música de flashback ──
    $ musica("flashback_suave", fade=2.0)

    # ── Ambientación ──
    n "El circo de tu infancia."

    n "Tenías siete años."

    n "Y no entendías por qué los payasos sonreían."

    naop_old "(¿Por qué sonríen?)"
    naop_old "(Si están tristes.)"

    # ── Detalle clave ──
    n "El payaso viejo te dijo que se lo preguntaras a la máscara."

    n "Y tú le preguntaste cómo."

    n "Y él te dijo:"

    n "«Póntela. Y ya no podrás quitártela.»"

    naop_old "(Póntela.)"
    naop_old "(¿Y eso cómo se hace?)"

    n "No te lo explicó."

    n "Te dijo que lo descubrieras tú."

    n "Y que algún día lo entenderías."

    # ── Conexión con el presente ──
    n "Ese día no tardó en llegar."

    n "A los ocho años, ya sonreías siempre."

    n "A los nueve, ya no podías dejar de sonreír."

    n "Y desde entonces, sonríes."

    n "A todos."

    naop_old "(La máscara no se quita.)"
    naop_old "(Se queda.)"
    naop_old "(Pero solo si alguien la recuerda.)"
    naop_old "(Y yo la recuerdo.)"
    naop_old "(A todas.)"

    # ── Métrica ──
    $ modificar_metrica("angustia", +4)
    $ modificar_metrica("miedo", +3)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "nao")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso7_despertar
    with Dissolve(1.0)

    show nao_img at left
    show souta_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves a la carpa. A Souta."

    n "Souta te está mirando."

    so "¿Estás bien?"

    nao "Sí."

    so "No lo parece."

    nao "..."

    nao "Es solo que..."

    nao "Este sitio me recuerda a algo."

    so "..."

    so "A mí también."

    n "Y por un momento, los dos os quedáis en silencio."

    n "Pero es un silencio distinto. Un silencio compartido."

    # ── Flag ──
    $ gtn_flag("fb_nao_visto", True)

    return


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 2 — Souta y la huida
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Souta recuerda la noche que se fue de casa.
# ═══════════════════════════════════════════════════════════════
label cap07_flashback_souta_huida:

    # ── Transición ──
    n "..."

    n "Souta se ha quedado en silencio."

    n "Y por un momento, ves algo distinto en él."

    # ── Flashback ──
    scene bg_flash_souta_huida
    with Dissolve(1.0)

    show screen flashback_overlay

    $ musica("flashback_tension", fade=2.0)

    # ── Ambientación ──
    n "Una casa. De noche."

    n "Lluvia hacía poco."

    n "El asfalto brillaba."

    n "Y Souta tenía una mochila."

    sop_old "(Me voy.)"
    sop_old "(No puedo más.)"

    n "Eso se dijo."

    n "Y se fue."

    # ── Detalle clave ──
    n "En la ventana de arriba, una luz."

    n "Su madre. Despierta."

    n "Pero no bajó."

    n "Y él no subió."

    sop_old "(No ha bajado.)"
    sop_old "(No ha bajado, no ha bajado.)"

    n "Su madre no bajó."

    n "O eso creyó él."

    n "Porque cuando volvió la vista, estaba solo."

    n "Sin nadie."

    n "Y desde entonces, el silencio."

    # ── Conexión con el presente ──
    n "Desde esa noche, Souta no sonríe."

    n "No sonríe nunca."

    n "Porque si sonríe, se acuerda."

    sop_old "(No pasa nada.)"
    sop_old "(No pasa nada, ¿vale?)"
    sop_old "(No pasa nada.)"
    sop_old "(No pasa nada.)"

    n "Pero sí pasa."

    n "Y él lo sabe."

    n "Pero no lo dice."

    # ── Métrica ──
    $ modificar_metrica("angustia", +5)
    $ modificar_metrica("miedo", +3)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "souta")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso7_carpa
    with Dissolve(1.0)

    show nao_img at left
    show souta_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al presente. A la carpa."

    n "Souta está mirando su propio reflejo en uno de los espejos."

    n "Pero el espejo no refleja."

    n "Traga."

    nao "Souta."

    so "¿Sí?"

    nao "Te has quedado en blanco."

    so "Solo estaba... pensando."

    n "Las mismas palabras que le has dicho tú antes."

    naop "(Ha usado mi frase.)"
    naop "(Como el eco.)"

    # ── Flag ──
    $ gtn_flag("fb_souta_visto", True)

    return