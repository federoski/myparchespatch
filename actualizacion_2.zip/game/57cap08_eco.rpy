# ═══════════════════════════════════════════════════════════════
#  57cap08_eco.rpy — Apariciones de El·yon en el Capítulo 8
# ═══════════════════════════════════════════════════════════════

# ⚠️ Los transforms y screens (eco_elyon_visual, eco_lateral_visual)
#    ya están definidos en 55cap06_eco.rpy — NO se redefinen.


# ═══════════════════════════════════════════════════════════════
#  ECO 1 — Muy sutil (Acto 1)
# ═══════════════════════════════════════════════════════════════
label cap08_eco_1:

    n "Y entonces, muy lejos..."

    n "Algo."

    show screen eco_lateral_visual("Emi...", pos="der")

    $ sonido("elyon")

    n "Un susurro. Una sola palabra."

    n "Tan baja que casi no la oyes."

    pause 1.5

    em_p "(¿Qué ha sido eso?)"
    em_p "(Nada. Habrá sido el fluorescente.)"
    em_p "(...Pero el fluorescente no habla.)"

    $ modificar_metrica("miedo", +3)

    $ desbloquear_relacion_elyon("torre", "emi")

    $ gtn_flag("eco_1_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 2 — Más notoria (Acto 3)
# ═══════════════════════════════════════════════════════════════
label cap08_eco_2:

    pause 1.0

    n "..."

    n "El silencio se estira."

    n "Y entonces..."

    show screen eco_elyon_visual("No escribas")

    $ sonido("elyon")

    n "La voz vuelve."

    n "Pero esta vez dice algo distinto."

    n "Repite lo que tú has pensado antes."

    if gtn_flag("emi_escucha"):
        elyon_voz "{i}Hay alguien.{/i}"
        em_p "(Eso he dicho.)"
        em_p "(Cuando he cerrado los ojos.)"
        em_p "(Lo ha copiado. Palabra por palabra.)"
    elif gtn_flag("emi_lee"):
        elyon_voz "{i}¿Cuándo?{/i}"
        em_p "(Eso pensé.)"
        em_p "(Al ver el poema.)"
        em_p "(Pero no lo dije.)"
    elif gtn_flag("emi_llama"):
        elyon_voz "{i}Han sido varias.{/i}"
        em_p "(Eso es lo que pensé.)"
        em_p "(Cuando oí mi voz repetida.)"
        em_p "(Con otro tono.)"

    kz "¿Emi? ¿Estás bien?"

    em "Sí. Sí, estoy bien."

    kz "Te has quedado quieta."

    em "Estaba... pensando."

    kz "Ya."

    n "Kazuki no insiste. Pero te mira un segundo más de lo necesario."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)
    $ modificar_metrica("terror", +5)

    $ desbloquear_pista("torre", "p8_espejo")
    $ desbloquear_relacion_elyon("torre", "emi")

    $ gtn_flag("eco_2_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 3 — Clímax (Acto 5)
# ═══════════════════════════════════════════════════════════════
label cap08_eco_3:

    if not (gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido")):
        return

    pause 1.5

    n "Antes de que puedas decidir..."

    n "La voz vuelve."

    n "Pero esta vez, no susurra."

    n "Habla."

    show screen eco_elyon_visual("El espejo no es un espejo")

    pause 2.0

    show screen eco_elyon_visual("Es una boca")

    pause 1.5

    $ sonido("elyon")

    elyon_voz "{i}Y tú vas a alimentarla.{/i}"

    pause 1.0

    n "Y el silencio."

    em "..."
    kz "¿Emi?"
    em "Nada. Vamos."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +10)

    $ desbloquear_relacion_elyon("torre", "emi")
    $ desbloquear_relacion_elyon("torre", "kazuki")

    $ gtn_flag("eco_3_oido", True)
    $ gtn_ecos_oidos += 1

    return