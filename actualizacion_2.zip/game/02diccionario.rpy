# ═══════════════════════════════════════════════════════════════
#  02diccionario.rpy — Diccionario estilo Homicipher
#  -----------------------------------------------------------------
#  Estructura: DICCIONARIO_ENTRADAS[historia][clave] = { ... }
# ═══════════════════════════════════════════════════════════════

init python:
    if not hasattr(persistent, "diccionario_aprendido") or persistent.diccionario_aprendido is None or isinstance(persistent.diccionario_aprendido, bool):
        persistent.diccionario_aprendido = {}

    # -----------------------------------------------------------------
    # ESTRUCTURA POR HISTORIA
    # -----------------------------------------------------------------
    DICCIONARIO_ENTRADAS = {
        "torre": {
            "ayudame": {
                "termino": "«Ayúdame»",
                "significado": "Marca tallada con uñas en la pared del piso.",
                "tipo": "encontrar",
                "capitulo": 1,
                "descripcion": "Alguien dejó este mensaje antes. No era un mensaje para ellos. Los puntos suspensivos indican que no acabó de escribirlo."
            },
            "elyon": {
                "termino": "«El·yon»",
                "significado": "Nombre que susurra la torre. ¿Un lugar? ¿Alguien?",
                "tipo": "oir",
                "capitulo": 1,
                "audio": "audio/voces/elyon.ogg",
                "descripcion": "Se escucha por primera vez en el Capítulo 1, en una voz que no es de ninguno de los dos."
            },
            "reflejo_no_miente": {
                "termino": "«El reflejo no miente»",
                "significado": "Inscripción grabada en un marco de espejo del piso 2.",
                "tipo": "encontrar",
                "capitulo": 2,
                "descripcion": "Alguien la dejó ahí antes. O algo. No se sabe."
            },
            "eco_verdadero": {
                "termino": "«No confíes en el eco»",
                "significado": "Frase que susurra la torre con la voz de uno mismo.",
                "tipo": "oir",
                "capitulo": 2,
                "audio": "audio/voces/eco_verdadero.ogg",
                "descripcion": "El eco no repite lo que dices. Dice lo que piensas."
            },
            "telon_no_abre": {
                "termino": "«El telón no se abre»",
                "significado": "Frase repetida en todos los programas y carteles del teatro del piso 3.",
                "tipo": "encontrar",
                "capitulo": 3,
                "descripcion": "Todos los que estuvieron aquí antes lo leyeron. Y ninguno lo entendió a tiempo."
            },
            "aplauso_vacio": {
                "termino": "«Aplauso vacío»",
                "significado": "El sonido de un público que no existe. O que sí existe, pero no tiene cuerpo.",
                "tipo": "oir",
                "capitulo": 3,
                "audio": "audio/sfx/aplauso_vacio.ogg",
                "descripcion": "Se escucha cuando el teatro recuerda la última función."
            },
            "simbolo_suelo": {
                "termino": "«Símbolo del suelo»",
                "significado": "Marca geométrica tallada en el suelo del pasillo.",
                "tipo": "encontrar",
                "capitulo": 1,
                "descripcion": "El mismo trazo que la marca de la pared. La misma desesperación."
            },
            "puerta_cerrada": {
                "termino": "«Puerta cerrada»",
                "significado": "La puerta de salida del piso 1. Sin cerradura, sin manilla, con símbolos grabados.",
                "tipo": "encontrar",
                "capitulo": 1,
                "descripcion": "No se abre con llaves. Solo se abre si la torre quiere."
            },
            "simbolo_espejo": {
                "termino": "«Símbolo del espejo»",
                "significado": "Marca geométrica grabada en el revés de un espejo del piso 2.",
                "tipo": "encontrar",
                "capitulo": 2,
                "descripcion": "El mismo trazo que los símbolos de la torre. La misma desesperación."
            },
            "puerta_espejo": {
                "termino": "«Puerta-espejo»",
                "significado": "La puerta de salida del piso 2. Sin cerradura, sin manilla, con símbolos grabados.",
                "tipo": "encontrar",
                "capitulo": 2,
                "descripcion": "No se abre con llaves. Solo se abre si la torre quiere."
            },
            "puerta_teatro": {
                "termino": "«Puerta del teatro»",
                "significado": "Puerta detrás del telón. Sin cerradura. Con símbolos grabados.",
                "tipo": "encontrar",
                "capitulo": 3,
                "descripcion": "No se abre con llaves. Solo se abre si el teatro quiere."
            },
            "cinta_rosa": {
                "termino": "«Cinta rosa»",
                "significado": "La cinta que Hana lleva en el pelo. Simboliza a su hermana.",
                "tipo": "encontrar",
                "capitulo": 3,
                "descripcion": "La lleva siempre. Nunca se la quita. Ni siquiera para dormir."
            },
            "telon_no_abre": {
                "termino": "«El telón no se abre»",
                "significado": "Frase repetida en todos los programas y carteles del teatro.",
                "tipo": "encontrar",
                "capitulo": 3,
                "descripcion": "..."
            },
            "aplauso_vacio": {
                "termino": "«Aplauso vacío»",
                "significado": "El sonido de un público que no existe.",
                "tipo": "oir",
                "capitulo": 3,
                "descripcion": "..."
            },
            # ── Capítulo 4: Mei & Daichi ──
            "puertas_nombres": {
                "termino": "«Puertas con nombres»",
                "significado": "Todas las puertas del piso 4 tienen un nombre grabado.",
                "tipo": "encontrar",
                "capitulo": 4,
                "descripcion": "Cada puerta es una persona. Y cada nombre, un recuerdo que no se quiere dejar ir."
            },
            "llaves_peso": {
                "termino": "«Llaves que pesan»",
                "significado": "Las llaves del cuarto pesan distinto. Algunas más que otras.",
                "tipo": "encontrar",
                "capitulo": 4,
                "descripcion": "Las que pesan más son de los que todavía están vivos. O de los que acaban de morir."
            },
            "susurro_nombre": {
                "termino": "«El susurro con nombre»",
                "significado": "Un susurro que dice tu nombre. Pero nadie lo dice.",
                "tipo": "oir",
                "capitulo": 4,
                "audio": "audio/voces/susurro_nombre.ogg",
                "descripcion": "El·yon no siempre susurra palabras. A veces susurra nombres. Nombres de los que están dentro de la torre."
            },
            "puerta_19": {
                "termino": "«La puerta 19»",
                "significado": "Una puerta que no existía. Hasta que Mei la dibujó.",
                "tipo": "encontrar",
                "capitulo": 4,
                "descripcion": "Las puertas del piso 4 son 18. Pero hay una más. Y solo aparece cuando alguien la crea."
            },
            "puerta_19": {
                "termino": "«La puerta 19»",
                "significado": "Una puerta que no existía. Hasta que Mei la dibujó.",
                "tipo": "encontrar",
                "capitulo": 4,
                "descripcion": "Las puertas del piso 4 son 18. Pero hay una más. Y solo aparece cuando alguien la crea."
            },
            # ── Capítulo 5: Rin & Tsubasa ──
            "tablero_reinicia": {
                "termino": "«El tablero se reinicia»",
                "significado": "Cada 5 minutos, el tablero vuelve a su posición inicial.",
                "tipo": "encontrar",
                "capitulo": 5,
                "descripcion": "Alguien está jugando al otro lado. Y mientras no gane, el tablero se reinicia. Una y otra vez."
            },
            "sombra_rin": {
                "termino": "«La sombra de Rin»",
                "significado": "Una sombra que solo Rin ve. Alargada. Con ojos rojos.",
                "tipo": "oir",
                "capitulo": 5,
                "audio": "audio/voces/sombra_rin.ogg",
                "descripcion": "Es lo que Rin dejó atrás cuando cruzó la puerta del piso 1. Una parte de ella que se quedó con el piso."
            },
            "pieza_33": {
                "termino": "«La pieza 33»",
                "significado": "Una pieza de ajedrez que no debería existir.",
                "tipo": "encontrar",
                "capitulo": 5,
                "descripcion": "El ajedrez tiene 32 piezas. Siempre. 32. Ni una más. Pero esta es la 33. Y no es ninguna de los 18."
            },
            "reloj_tsubasa": {
                "termino": "«El reloj de Tsubasa»",
                "significado": "Un reloj de latón que no funciona. Pero que marca el tiempo del tablero.",
                "tipo": "encontrar",
                "capitulo": 5,
                "descripcion": "Está parado a las 5:00. Pero a veces avanza un segundo. Y cuando avanza, algo cambia en el tablero."
            },
            # ── Capítulo 6: Ayame & Hiro ──
            "velas_nombres": {
                "termino": "«Velas con nombres»",
                "significado": "Cada vela del templo tiene un nombre. Y todas están encendidas.",
                "tipo": "encontrar",
                "capitulo": 6,
                "descripcion": "Las velas no son decoración. Son un censo. Cada vela es una persona. Y cuando la vela se apaga, la persona se olvida."
            },
            "campanas_nombres": {
                "termino": "«Campanas con nombres»",
                "significado": "Cada campana del templo tiene un nombre. Y todas están quietas.",
                "tipo": "encontrar",
                "capitulo": 6,
                "descripcion": "Las campanas suenan cuando alguien las llama. Y cada campana solo suena una vez por persona. Después, se rompe."
            },
            "pozo_habla": {
                "termino": "«El pozo que habla»",
                "significado": "Un pozo sin fondo que dice nombres. Y que come culpa.",
                "tipo": "oir",
                "capitulo": 6,
                "audio": "audio/voces/pozo_habla.ogg",
                "descripcion": "El pozo no está encantado. Ni avisa de nada. Tiene hambre. Y come culpa. Cada vez que alguien se siente culpable, el pozo se alimenta."
            },
            "puerta_al_fondo": {
                "termino": "«La puerta al fondo»",
                "significado": "Una puerta de madera al final del templo. Con sellos de papel rotos.",
                "tipo": "encontrar",
                "capitulo": 6,
                "descripcion": "La puerta se abre solo si el pozo se cierra. Y el pozo se cierra solo si alguien deja de sentir culpa. Alguien de los que están aquí."
            },

            # ── Capítulo 7: Nao & Souta ──
            "mascara_nao": {
                "termino": "«La máscara de Nao»",
                "significado": "Una máscara de porcelana rota. Con el nombre de Nao dentro.",
                "tipo": "encontrar",
                "capitulo": 7,
                "descripcion": "Nao sonríe siempre. Pero la máscara no es suya. O sí. Y cuando se le cae, no puede volver a ponérsela."
            },
            "risa_forzada": {
                "termino": "«Risa forzada»",
                "significado": "La risa que el circo se alimenta. La que Nao lleva puesta desde niña.",
                "tipo": "oir",
                "capitulo": 7,
                "audio": "audio/voces/risa_forzada.ogg",
                "descripcion": "El público no aplaude porque la función sea buena. Aplaude porque la risa es forzada. Y de eso se alimenta."
            },
            "espejo_deformante": {
                "termino": "«Espejo deformante»",
                "significado": "Un espejo del circo que refleja lo que deberías ser. No lo que eres.",
                "tipo": "encontrar",
                "capitulo": 7,
                "descripcion": "Los espejos del circo no mienten. Reflejan la versión de ti que sonríe. La que nunca se cansa. La que nunca llora."
            },
            "publico_rie": {
                "termino": "«El público que ríe»",
                "significado": "Las siluetas sin cara que aplauden desde las gradas. No respiran. Solo esperan.",
                "tipo": "oir",
                "capitulo": 7,
                "audio": "audio/voces/publico_rie.ogg",
                "descripcion": "El público no es público. Es lo que queda de los que rieron antes. Y cuando alguien deja de sonreír, se sientan. Y esperan."
            },
            "funcion_33": {
                "termino": "«La función 33»",
                "significado": "La función que nunca termina. La que lleva 33 años representándose.",
                "tipo": "encontrar",
                "capitulo": 7,
                "descripcion": "33 butacas. 33 funciones. 33 nombres. Y ninguno ha salido. Porque la función no termina hasta que alguien se ríe de verdad."
            },

            # ── Capítulo 8: Emi & Kazuki ──
            "poema_emi": {
                "termino": "«Poema de Emi»",
                "significado": "Un poema escrito en la pared del hospital. Con la letra de Emi.",
                "tipo": "encontrar",
                "capitulo": 8,
                "descripcion": "Emi escribió este poema. O alguien con su letra. Porque habla de cosas que solo ella sabe. Y de un hospital que nunca la dejó salir."
            },
            "seis_meses": {
                "termino": "«Seis meses»",
                "significado": "El tiempo que Emi estuvo ingresada. O el tiempo que lleva sin salir.",
                "tipo": "oir",
                "capitulo": 8,
                "audio": "audio/voces/seis_meses.ogg",
                "descripcion": "Seis meses. Ni uno más. Ni uno menos. Ese fue el tiempo que le dijeron. Y ese fue el tiempo que estuvo. Pero cuando salió, no salió del todo."
            },
            "favor_kazuki": {
                "termino": "«El favor de Kazuki»",
                "significado": "Un favor que Kazuki hizo hace dos años. Y que todavía paga.",
                "tipo": "encontrar",
                "capitulo": 8,
                "descripcion": "No fue un favor. Fue un cambio. Kazuki cambió un voto. Y desde entonces, sonríe. Porque si no sonríe, se acuerda."
            },
            "presidencia_comprada": {
                "termino": "«Presidencia comprada»",
                "significado": "La presidencia de Kazuki no se ganó. Se compró.",
                "tipo": "encontrar",
                "capitulo": 8,
                "descripcion": "Kazuki no ganó las elecciones. Las compró. Y por eso sonríe siempre. Porque si deja de sonreír, la gente verá lo que hay debajo. Y lo que hay debajo no es un líder."
            },



        },
        # ── DLCs futuros ──
        # "mansion": { ... },
        # "bosque": { ... },
    }


    # -----------------------------------------------------------------
    # FUNCIONES (por historia)
    # -----------------------------------------------------------------
    def aprender_palabra(historia, clave):
        if historia not in DICCIONARIO_ENTRADAS:
            return False
        if clave not in DICCIONARIO_ENTRADAS[historia]:
            return False
        if clave not in persistent.diccionario_aprendido.get(historia, {}):
            persistent.diccionario_aprendido.setdefault(historia, {})[clave] = DICCIONARIO_ENTRADAS[historia][clave]["tipo"]
            try:
                renpy.sound.play("audio/sfx\escribir.ogg", channel="sound")
            except Exception:
                pass
            notificar("📖", "Nueva palabra", DICCIONARIO_ENTRADAS[historia][clave]["termino"], "#00AAFF")
            return True
        return False

    def olvidar_palabra(historia, clave):
        if historia in persistent.diccionario_aprendido and clave in persistent.diccionario_aprendido[historia]:
            del persistent.diccionario_aprendido[historia][clave]
            return True
        return False

    def palabra_aprendida(historia, clave):
        return clave in persistent.diccionario_aprendido.get(historia, {})

    def total_palabras(historia="torre"):
        if historia not in DICCIONARIO_ENTRADAS:
            return 0
        return len(DICCIONARIO_ENTRADAS[historia])

    def total_aprendidas(historia="torre"):
        return len(persistent.diccionario_aprendido.get(historia, {}))

    def total_aprendidas_global():
        total = 0
        for historia, palabras in persistent.diccionario_aprendido.items():
            total += len(palabras)
        return total

    def total_palabras_global():
        total = 0
        for historia in DICCIONARIO_ENTRADAS.keys():
            total += len(DICCIONARIO_ENTRADAS[historia])
        return total

    def palabras_por_tipo(historia, tipo):
        if historia not in DICCIONARIO_ENTRADAS:
            return []
        if tipo == "todas":
            return list(DICCIONARIO_ENTRADAS[historia].keys())
        return [k for k, v in DICCIONARIO_ENTRADAS[historia].items() if v["tipo"] == tipo]

    def contar_palabras_tipo(historia, tipo):
        return len(palabras_por_tipo(historia, tipo))

    def contar_aprendidas_tipo(historia, tipo):
        return sum(1 for k in palabras_por_tipo(historia, tipo) if palabra_aprendida(historia, k))

    def palabras_de_capitulo(historia, cap):
        if historia not in DICCIONARIO_ENTRADAS:
            return []
        return [k for k, v in DICCIONARIO_ENTRADAS[historia].items() if v.get("capitulo") == cap]


# -----------------------------------------------------------------
# SCREEN DEL DICCIONARIO
# -----------------------------------------------------------------
screen diccionario_menu():
    tag menu
    modal True

    default historia_actual = "torre"
    default filtro_tipo = "todas"
    default filtro_cap = 0

    add "#00000000"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1000
        ysize 750
        background Solid("#141414")
        padding (30, 25)

        has vbox spacing 15 xfill True

        text "📖 DICCIONARIO":
            size 34
            bold True
            color "#8b0000"
            xalign 0.5
            text_align 0.5

        text "Palabras aprendidas: [total_aprendidas_global()] / [total_palabras_global()]":
            size 16
            color "#888"
            xalign 0.5
            text_align 0.5

        # ── Selector de historia ──
        hbox:
            spacing 8
            xalign 0.5

            for hist_id, hist_data in capitulos.historias.items():
                if hist_data.get("desbloqueado", False):
                    textbutton "[hist_data['icono']] [hist_data['nombre']]":
                        action [SetScreenVariable("historia_actual", hist_id), SetScreenVariable("filtro_cap", 0)]
                        style "trophy_tab_button"
                        if historia_actual == hist_id:
                            background "#FF4444"
                            text_color "#FFFFFF"

        # ── Filtro por tipo ──
        hbox:
            spacing 8
            xalign 0.5

            textbutton "Todas ([contar_palabras_tipo(historia_actual, 'todas')])":
                action SetScreenVariable("filtro_tipo", "todas")
                style "trophy_tab_button"
                if filtro_tipo == "todas":
                    background "#FF4444"
                    text_color "#FFFFFF"

            textbutton "🔊 Oír ([contar_palabras_tipo(historia_actual, 'oir')])":
                action SetScreenVariable("filtro_tipo", "oir")
                style "trophy_tab_button"
                if filtro_tipo == "oir":
                    background "#FF4444"
                    text_color "#FFFFFF"

            textbutton "🔍 Encontrar ([contar_palabras_tipo(historia_actual, 'encontrar')])":
                action SetScreenVariable("filtro_tipo", "encontrar")
                style "trophy_tab_button"
                if filtro_tipo == "encontrar":
                    background "#FF4444"
                    text_color "#FFFFFF"

        # ── Filtro por capítulo ──
        hbox:
            spacing 6
            xalign 0.5

            for c in range(1, 13):
                $ n_cap = len(palabras_de_capitulo(historia_actual, c))
                if n_cap > 0:
                    textbutton "Cap [c] ([n_cap])":
                        action SetScreenVariable("filtro_cap", c)
                        style "trophy_tab_button"
                        if filtro_cap == c:
                            background "#FF4444"
                            text_color "#FFFFFF"

            textbutton "Todos":
                action SetScreenVariable("filtro_cap", 0)
                style "trophy_tab_button"
                if filtro_cap == 0:
                    background "#FF4444"
                    text_color "#FFFFFF"

        null height 5

        # ── Lista de palabras ──
        viewport:
            xfill True
            yfill True
            mousewheel True
            scrollbars "vertical"

            has vbox spacing 12 xfill True

            $ claves_filtradas = palabras_por_tipo(historia_actual, filtro_tipo)
            if filtro_cap != 0:
                $ claves_filtradas = [k for k in claves_filtradas if DICCIONARIO_ENTRADAS[historia_actual][k].get("capitulo") == filtro_cap]

            if claves_filtradas:
                for clave in claves_filtradas:
                    $ data = DICCIONARIO_ENTRADAS[historia_actual][clave]
                    $ aprendida = palabra_aprendida(historia_actual, clave)

                    if aprendida:
                        frame:
                            xfill True
                            background Solid("#1e1e1e")
                            padding (16, 12)
                            has vbox spacing 4

                            hbox:
                                spacing 10
                                text data["termino"] size 20 bold True color "#fff"
                                text "· " + data["tipo"] size 12 color "#888" yalign 0.5
                                text "· Cap " + str(data.get("capitulo", "?")) size 12 color "#888" yalign 0.5

                                # ── Botón reproducir audio (solo para tipo "oir" con audio) ──
                                if data["tipo"] == "oir" and data.get("audio"):
                                    if renpy.loadable(data["audio"]):
                                        textbutton "▶ Reproducir":
                                            style "menu_button"
                                            yalign 4.5
                                            action Play("sound", data["audio"])
                                    else:
                                        text "▶ (audio no disponible)":
                                            size 12
                                            color "#666"
                                            yalign 0.5
                                            italic True

                            text data["significado"] size 15 color "#ccc"
                            if data.get("descripcion"):
                                text data["descripcion"] size 13 color "#777" italic True
                    else:
                        frame:
                            xfill True
                            background Solid("#0e0e0e")
                            padding (16, 12)
                            text "🔒 ???" size 18 color "#444" bold True
            else:
                text "No hay palabras en este filtro." size 15 color "#666" xalign 0.5 italic True

    textbutton "← Volver":
        style "menu_button"
        xalign 0.5
        action ShowMenu("extras_menu")