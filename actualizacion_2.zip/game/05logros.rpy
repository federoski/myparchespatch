# ═══════════════════════════════════════════════════════════════
#  05logros.rpy — Sistema de logros por historia
# ═══════════════════════════════════════════════════════════════

init python:
    TROPHY_COLORS = {
        "bronze":   "#CD7F32",
        "silver":   "#C0C0C0",
        "gold":     "#FFD700",
        "platinum": "#E5E4E2",
        "hidden":   "#555555",
        "locked":   "#555555",
        "default":  "#888888"
    }


init python early:
    class Achievement(NoRollback):
        all_achievements = {}

        def __init__(self, name='', message='', image=None, type='bronze', category='historia', historia='torre'):
            self.name = name
            self.message = message
            self.type = type
            self.category = category
            self.historia = historia
            self.image = image or f"images/icons/{type}.png"

        def add(self):
            if not Achievement.has(self.name):
                persistent.my_achievements.insert(0, self.name)
                try:
                    renpy.sound.play("audio/trofeo.ogg", channel="sound")
                except Exception:
                    pass

        @staticmethod
        def has(name):
            return name in persistent.my_achievements

        @staticmethod
        def register(trophy):
            Achievement.all_achievements[trophy.name] = trophy

        @staticmethod
        def purge():
            persistent.my_achievements.clear()


init python:
    def add_achievement_with_popup(trophy):
        trophy.add()
        notificar("🎖️", "Logro desbloqueado", trophy.name, TROPHY_COLORS.get(trophy.type, "#FFD700"))

    def contar_logros_categoria(cat, historia=None):
        if historia is None:
            return sum(1 for a in Achievement.all_achievements.values() if a.category == cat)
        return sum(1 for a in Achievement.all_achievements.values() if a.category == cat and a.historia == historia)

    def contar_logros_categoria_desbloqueados(cat, historia=None):
        if historia is None:
            return sum(1 for a in Achievement.all_achievements.values() if a.category == cat and Achievement.has(a.name))
        return sum(1 for a in Achievement.all_achievements.values() if a.category == cat and a.historia == historia and Achievement.has(a.name))

    def contar_logros_historia(historia):
        return sum(1 for a in Achievement.all_achievements.values() if a.historia == historia)

    def contar_logros_historia_desbloqueados(historia):
        return sum(1 for a in Achievement.all_achievements.values() if a.historia == historia and Achievement.has(a.name))


# -----------------------------------------------------------------
# LOGROS — Estructura: "clave": [nombre, desc, img, tipo, categoría, historia]
# -----------------------------------------------------------------
init python:
    achievement_name = {

        # =======================================================
        # HISTORIA
        # =======================================================
        'primer_despertar': ['El despertar', 'Comienza la pesadilla.', None, 'bronze', 'historia', 'torre'],
        'segundo_despertar': ['El eco despierta', 'Comienza el Capítulo 2.', None, 'bronze', 'historia', 'torre'],
        'tercer_despertar': ['La grieta se abre', 'Comienza el Capítulo 3.', None, 'bronze', 'historia', 'torre'],
        'cuarto_despertar': ['El susurro despierta', 'Comienza el Capítulo 4.', None, 'bronze', 'historia', 'torre'],
        'cap1_completado': ['Sobrevivir al despertar', 'Completa el Capítulo 1.', None, 'silver', 'historia', 'torre'],
        'cap2_completado': ['El eco resuena', 'Completa el Capítulo 2.', None, 'silver', 'historia', 'torre'],
        'cap3_completado': ['La grieta se abre', 'Completa el Capítulo 3.', None, 'silver', 'historia', 'torre'],
        'cap4_completado': ['Sobrevivir al susurro', 'Completa el Capítulo 4.', None, 'silver', 'historia', 'torre'],
        'cap5_completado': ['La sombra se disipa', 'Completa el Capítulo 5.', None, 'silver', 'historia', 'torre'],
        'cap6_completado': ['El vacío se llena', 'Completa el Capítulo 6.', None, 'silver', 'historia', 'torre'],
        'cap7_completado': ['La máscara cae', 'Completa el Capítulo 7.', None, 'silver', 'historia', 'torre'],
        'cap8_completado': ['El reflejo se rompe', 'Completa el Capítulo 8.', None, 'silver', 'historia', 'torre'],
        'cap9_completado': ['La última puerta', 'Completa el Capítulo 9.', None, 'gold', 'historia', 'torre'],
        'cap10_desbloqueado': ['El umbral', 'Desbloquea el Capítulo 10.', None, 'gold', 'historia', 'torre'],
        'cap11_desbloqueado': ['La raíz', 'Desbloquea el Capítulo 11.', None, 'gold', 'historia', 'torre'],
        'cap12_desbloqueado': ['Grita tu nombre', 'Desbloquea el Capítulo 12.', None, 'platinum', 'historia', 'torre'],
        'eco_completo': ['El que escucha', 'Escucha las tres apariciones de El·yon en el Capítulo 1.', None, 'silver', 'historia', 'torre'],
        'recuerdos_cap1': ['Los recuerdos del piso 1', 'Ve los dos flashbacks del Capítulo 1.', None, 'bronze', 'historia', 'torre'],
        'notas_completas': ['El cuaderno de Akira', 'Descubre todas las notas del Capítulo 1.', None, 'silver', 'historia', 'torre'],
        'eco_completo_cap2': ['El que escucha II', 'Escucha las tres apariciones de El·yon en el Capítulo 2.', None, 'silver', 'historia', 'torre'],
        'recuerdos_cap2': ['Los recuerdos del piso 2', 'Ve los dos flashbacks del Capítulo 2.', None, 'bronze', 'historia', 'torre'],
        'notas_completas_cap2': ['El cuaderno de Yuki', 'Descubre todas las notas del Capítulo 2.', None, 'silver', 'historia', 'torre'],
        'recuerdos_cap3': ['Los recuerdos del piso 3', 'Ve los dos flashbacks del Capítulo 3.', None, 'bronze', 'historia', 'torre'],
        'notas_completas_cap3': ['El cuaderno de Hana', 'Descubre todas las notas del Capítulo 3.', None, 'silver', 'historia', 'torre'],
        'eco_completo_cap3': ['El que escucha III', 'Escucha las tres apariciones de El·yon en el Capítulo 3.', None, 'silver', 'historia', 'torre'],
        'oculto_eco_callado': ['El eco que no repite', 'Oye el eco tres veces sin contárselo a nadie.', None, 'hidden', 'historia', 'torre'],
        'oculto_silencio': ['Silencio en el teatro', 'Oye el aplauso sin decir nada.', None, 'hidden', 'historia', 'torre'],
        'oculto_oyo_todo': ['El que oyó todo', 'Oye los 9 ecos de El·yon.', None, 'hidden', 'historia', 'torre'],
        'recuerdos_cap4': ['Los recuerdos del piso 4', 'Ve los dos flashbacks del Capítulo 4.', None, 'bronze', 'historia', 'torre'],
        'notas_completas_cap4': ['El cuaderno de Mei', 'Descubre todas las notas del Capítulo 4.', None, 'silver', 'historia', 'torre'],
        'eco_completo_cap4': ['El que escucha IV', 'Escucha las tres apariciones de El·yon en el Capítulo 4.', None, 'silver', 'historia', 'torre'],

        # =======================================================
        # FINALES
        # =======================================================
        'final_bueno_cap1': ['Ambos salieron', 'Consigue el final bueno del Capítulo 1.', None, 'gold', 'final', 'torre'],
        'final_especial_cap1': ['De la mano', 'Consigue el final especial del Capítulo 1.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap2': ['El eco se calló', 'Consigue el final bueno del Capítulo 2.', None, 'gold', 'final', 'torre'],
        'final_especial_cap2': ['De la mano II', 'Consigue el final especial del Capítulo 2.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap3': ['Sin grietas', 'Consigue el final bueno del Capítulo 3.', None, 'gold', 'final', 'torre'],
        'final_especial_cap3': ['Sin palabras', 'Consigue el final especial del Capítulo 3.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap4': ['El susurro cesa', 'Consigue el final bueno del Capítulo 4.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap5': ['Luz en la sombra', 'Consigue el final bueno del Capítulo 5.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap6': ['Vacío lleno', 'Consigue el final bueno del Capítulo 6.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap7': ['Sin máscaras', 'Consigue el final bueno del Capítulo 7.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap8': ['Reflejo entero', 'Consigue el final bueno del Capítulo 8.', None, 'gold', 'final', 'torre'],
        'final_bueno_cap9': ['Puerta abierta', 'Consigue el final bueno del Capítulo 9.', None, 'platinum', 'final', 'torre'],
        'todos_finales_buenos': ['Grita tu nombre', 'Consigue todos los finales buenos de los capítulos 1 al 9.', None, 'platinum', 'final', 'torre'],
        'final_malo_primero': ['Algo se rompió', 'Consigue tu primer final malo.', None, 'bronze', 'final', 'torre'],
        'final_asesinato': ['No debía pasar', 'Presencia una muerte por mala ruta.', None, 'silver', 'final', 'torre'],
        'oculto_vio_todo': ['El que vio todo', 'Consigue los 7 finales especiales.', None, 'hidden', 'final', 'torre'],
        'final_especial_cap4': ['Sin miedo', 'Consigue el final especial del Capítulo 4.', None, 'gold', 'final', 'torre'],

        # =======================================================
        # EXPLORACIÓN
        # =======================================================
        'objetos_cap1': ['Ojo de lince', 'Pulsa los dos objetos especiales del Capítulo 1.', None, 'bronze', 'exploracion', 'torre'],
        'objetos_cap2': ['Ojo de lince II', 'Pulsa los dos objetos especiales del Capítulo 2.', None, 'bronze', 'exploracion', 'torre'],
        'objetos_cap3': ['Ojo de lince III', 'Pulsa los dos objetos especiales del Capítulo 3.', None, 'bronze', 'exploracion', 'torre'],
        'explorador_novato': ['Explorador novato', 'Descubre 3 zonas de la torre.', None, 'bronze', 'exploracion', 'torre'],
        'explorador_experto': ['Explorador experto', 'Descubre 6 zonas de la torre.', None, 'silver', 'exploracion', 'torre'],
        'explorador_maestro': ['Explorador maestro', 'Descubre todas las zonas de la torre.', None, 'gold', 'exploracion', 'torre'],
        'oculto_no_aparto': ['El que no apartó la mirada', 'Mira todas las siluetas del teatro sin huir.', None, 'hidden', 'exploracion', 'torre'],
        'oculto_puertas': ['La puerta que no se abre', 'Intenta abrir todas las puertas de la torre.', None, 'hidden', 'exploracion', 'torre'],
        'oculto_reflejo': ['Reflejo tardío', 'Mira un espejo durante demasiado tiempo.', None, 'hidden', 'exploracion', 'torre'],
        'oculto_funcion': ['Función privada', 'Mira el escenario desde todas las butacas.', None, 'hidden', 'exploracion', 'torre'],
        'objetos_cap4': ['Ojo de lince IV', 'Pulsa los dos objetos especiales del Capítulo 4.', None, 'bronze', 'exploracion', 'torre'],

        # =======================================================
        # PERSONAJES
        # =======================================================
        'conoce_akira': ['Akira', 'Conoce a Akira.', None, 'bronze', 'personajes', 'torre'],
        'conoce_ren': ['Ren', 'Conoce a Ren.', None, 'bronze', 'personajes', 'torre'],
        'conoce_yuki': ['Yuki', 'Conoce a Yuki.', None, 'bronze', 'personajes', 'torre'],
        'conoce_sora': ['Sora', 'Conoce a Sora.', None, 'bronze', 'personajes', 'torre'],
        'conoce_hana': ['Hana', 'Conoce a Hana.', None, 'bronze', 'personajes', 'torre'],
        'conoce_kaito': ['Kaito', 'Conoce a Kaito.', None, 'bronze', 'personajes', 'torre'],
        'conoce_mei': ['Mei', 'Conoce a Mei.', None, 'bronze', 'personajes', 'torre'],
        'conoce_daichi': ['Daichi', 'Conoce a Daichi.', None, 'bronze', 'personajes', 'torre'],
        'conoce_rin': ['Rin', 'Conoce a Rin.', None, 'bronze', 'personajes', 'torre'],
        'conoce_tsubasa': ['Tsubasa', 'Conoce a Tsubasa.', None, 'bronze', 'personajes', 'torre'],
        'conoce_ayame': ['Ayame', 'Conoce a Ayame.', None, 'bronze', 'personajes', 'torre'],
        'conoce_hiro': ['Hiro', 'Conoce a Hiro.', None, 'bronze', 'personajes', 'torre'],
        'conoce_nao': ['Nao', 'Conoce a Nao.', None, 'bronze', 'personajes', 'torre'],
        'conoce_souta': ['Souta', 'Conoce a Souta.', None, 'bronze', 'personajes', 'torre'],
        'conoce_emi': ['Emi', 'Conoce a Emi.', None, 'bronze', 'personajes', 'torre'],
        'conoce_kazuki': ['Kazuki', 'Conoce a Kazuki.', None, 'bronze', 'personajes', 'torre'],
        'conoce_kanae': ['Prof. Kanae', 'Conoce a la profesora Kanae.', None, 'silver', 'personajes', 'torre'],
        'conoce_ryo': ['Prof. Ryō', 'Conoce al profesor Ryō.', None, 'silver', 'personajes', 'torre'],
        'todas_fichas': ['Los dieciocho', 'Conoce a los 18 personajes de la torre.', None, 'platinum', 'personajes', 'torre'],

        # =======================================================
        # DICCIONARIO / COLECCIÓN
        # =======================================================
        'primera_palabra': ['Primera palabra', 'Aprende tu primera palabra.', None, 'bronze', 'coleccion', 'torre'],
        'cinco_palabras': ['Lingüista novato', 'Aprende 5 palabras.', None, 'silver', 'coleccion', 'torre'],
        'diez_palabras': ['Políglota', 'Aprende 10 palabras.', None, 'gold', 'coleccion', 'torre'],
        'todas_palabras': ['Traductor de la torre', 'Aprende todas las palabras del diccionario.', None, 'platinum', 'coleccion', 'torre'],

        # =======================================================
        # MIEDO
        # =======================================================
        'primer_miedo': ['Primer escalofrío', 'Alcanza 20 de Miedo.', None, 'bronze', 'miedo', 'torre'],
        'miedo_alto': ['Terror creciente', 'Alcanza 60 de Miedo.', None, 'silver', 'miedo', 'torre'],
        'miedo_maximo': ['Pánico', 'Alcanza 100 de Miedo.', None, 'gold', 'miedo', 'torre'],
        'primer_terror': ['Algo no va bien', 'Alcanza 20 de Terror.', None, 'bronze', 'miedo', 'torre'],
        'terror_maximo': ['Colapso', 'Alcanza 100 de Terror.', None, 'gold', 'miedo', 'torre'],
        'primera_angustia': ['Nudo en el pecho', 'Alcanza 20 de Angustia.', None, 'bronze', 'miedo', 'torre'],
        'angustia_maxima': ['Sin aire', 'Alcanza 100 de Angustia.', None, 'gold', 'miedo', 'torre'],

        # =======================================================
        # ESTADOS
        # =======================================================
        'primer_amor': ['Algo parecido al cariño', 'Alcanza 20 de Amor.', None, 'bronze', 'estados', 'torre'],
        'amor_maximo': ['Apego total', 'Alcanza 100 de Amor.', None, 'gold', 'estados', 'torre'],
        'primer_odio': ['No te soporto', 'Alcanza 20 de Odio.', None, 'bronze', 'estados', 'torre'],
        'odio_maximo': ['Rencor puro', 'Alcanza 100 de Odio.', None, 'gold', 'estados', 'torre'],

        # =======================================================
        # DECISIONES
        # =======================================================
        'deducciones_cap1': ['Mente despierta', 'Acierta las dos deducciones del Capítulo 1.', None, 'silver', 'decisiones', 'torre'],
        'deducciones_cap3': ['Mente despierta III', 'Acierta las dos deducciones del Capítulo 3.', None, 'silver', 'decisiones', 'torre'],
        'primera_decision': ['Primera decisión', 'Toma tu primera decisión importante.', None, 'bronze', 'decisiones', 'torre'],
        'diez_decisiones': ['Decidido', 'Toma 10 decisiones.', None, 'silver', 'decisiones', 'torre'],
        'veinte_decisiones': ['Influyente', 'Toma 20 decisiones.', None, 'gold', 'decisiones', 'torre'],
        'confiar': ['Confianza ciega', 'Decide confiar plenamente en alguien.', None, 'silver', 'decisiones', 'torre'],
        'desconfiar': ['Lobo solitario', 'Decide no confiar en nadie.', None, 'bronze', 'decisiones', 'torre'],
        'salvar': ['Salvador', 'Decide salvar a alguien.', None, 'silver', 'decisiones', 'torre'],
        'no_salvar': ['Egoísta', 'Decide no salvar a nadie.', None, 'bronze', 'decisiones', 'torre'],
        'deducciones_cap2': ['Mente despierta II', 'Acierta las dos deducciones del Capítulo 2.', None, 'silver', 'decisiones', 'torre'],
        'oculto_no_grito': ['El que no gritó', 'Completa los 3 primeros capítulos sin gritar.', None, 'hidden', 'decisiones', 'torre'],
        'primera_deduccion': ['Primera deducción', 'Acierta tu primera deducción.', None, 'bronze', 'decisiones', 'torre'],
        'segunda_deduccion': ['Deducción certera', 'Acierta una segunda deducción.', None, 'bronze', 'decisiones', 'torre'],
        'deducciones_cap4': ['Mente despierta IV', 'Acierta las dos deducciones del Capítulo 4.', None, 'silver', 'decisiones', 'torre'],

        # =======================================================
        # RUTAS
        # =======================================================
        'primera_ruta': ['Primera ruta', 'Descubre tu primera ruta.', None, 'bronze', 'rutas', 'torre'],
        'cinco_rutas': ['Caminante', 'Descubre 5 rutas.', None, 'silver', 'rutas', 'torre'],
        'diez_rutas': ['Cartógrafo', 'Descubre 10 rutas.', None, 'gold', 'rutas', 'torre'],
        'todas_rutas': ['Conoces todos los caminos', 'Descubre todas las rutas del juego.', None, 'platinum', 'rutas', 'torre'],

        # =======================================================
        # MINIJUEGOS
        # =======================================================
        'primer_minijuego': ['Primer reto', 'Completa tu primer minijuego.', None, 'bronze', 'minijuegos', 'torre'],
        'minijuego_perfecto': ['Sin errores', 'Completa un minijuego sin fallar.', None, 'silver', 'minijuegos', 'torre'],
        'todos_minijuegos': ['Maestro de la torre', 'Completa todos los minijuegos.', None, 'gold', 'minijuegos', 'torre'],

        # =======================================================
        # HISTORIA (continuación) — Cap 5
        # =======================================================
        'quinto_despertar': ['El tablero despierta', 'Comienza el Capítulo 5.', None, 'bronze', 'historia', 'torre'],

        # =======================================================
        # FINALES — Cap 5
        # =======================================================
        'final_bueno_cap5':    ['Bye Bye sombra',  'Consigue el final bueno del Capítulo 5.',    None, 'gold', 'final', 'torre'],
        'final_especial_cap5': ['Jaque mate',            'Consigue el final especial del Capítulo 5.', None, 'gold', 'final', 'torre'],

        # =======================================================
        # PERSONAJES — Cap 5
        # =======================================================
        'conoce_rin':     ['Rin',     'Conoce a Rin.',     None, 'bronze', 'personajes', 'torre'],
        'conoce_tsubasa': ['Tsubasa', 'Conoce a Tsubasa.', None, 'bronze', 'personajes', 'torre'],

        # =======================================================
        # HISTORIA / EXPLORACIÓN / DECISIONES — Cap 5
        # =======================================================
        'recuerdos_cap5':       ['Los recuerdos del piso 5', 'Ve los dos flashbacks del Capítulo 5.',                     None, 'bronze', 'historia',    'torre'],
        'notas_completas_cap5': ['El cuaderno de Rin',       'Descubre todas las notas del Capítulo 5.',                  None, 'silver', 'historia',    'torre'],
        'eco_completo_cap5':    ['El que escucha V',         'Escucha las tres apariciones de El·yon en el Capítulo 5.',  None, 'silver', 'historia',    'torre'],
        'objetos_cap5':         ['Ojo de lince V',           'Pulsa los dos objetos especiales del Capítulo 5.',          None, 'bronze', 'exploracion', 'torre'],
        'deducciones_cap5':     ['Mente despierta V',        'Acierta las dos deducciones del Capítulo 5.',               None, 'silver', 'decisiones',  'torre'],

        # =======================================================
        # HISTORIA (continuación) — Cap 6
        # =======================================================
        'sexto_despertar': ['El vacío despierta', 'Comienza el Capítulo 6.', None, 'bronze', 'historia', 'torre'],

        # =======================================================
        # FINALES — Cap 6
        # =======================================================
        'final_bueno_cap6':    ['El vacío se sacia',  'Consigue el final bueno del Capítulo 6.',    None, 'gold', 'final', 'torre'],
        'final_especial_cap6': ['Sin sonrisa',         'Consigue el final especial del Capítulo 6.', None, 'gold', 'final', 'torre'],

        # =======================================================
        # PERSONAJES — Cap 6
        # =======================================================
        'conoce_ayame': ['Ayame', 'Conoce a Ayame.', None, 'bronze', 'personajes', 'torre'],
        'conoce_hiro':  ['Hiro',  'Conoce a Hiro.',  None, 'bronze', 'personajes', 'torre'],

        # =======================================================
        # HISTORIA / EXPLORACIÓN / DECISIONES — Cap 6
        # =======================================================
        'recuerdos_cap6':       ['Los recuerdos del piso 6', 'Ve los dos flashbacks del Capítulo 6.',                     None, 'bronze', 'historia',    'torre'],
        'notas_completas_cap6': ['El cuaderno de Ayame',     'Descubre todas las notas del Capítulo 6.',                  None, 'silver', 'historia',    'torre'],
        'eco_completo_cap6':    ['El que escucha VI',        'Escucha las tres apariciones de El·yon en el Capítulo 6.',  None, 'silver', 'historia',    'torre'],
        'objetos_cap6':         ['Ojo de lince VI',          'Pulsa los dos objetos especiales del Capítulo 6.',          None, 'bronze', 'exploracion', 'torre'],
        'deducciones_cap6':     ['Mente despierta VI',       'Acierta las dos deducciones del Capítulo 6.',               None, 'silver', 'decisiones',  'torre'],

        # HISTORIA (continuación) — Cap 7
        'septimo_despertar': ['La máscara despierta', 'Comienza el Capítulo 7.', None, 'bronze', 'historia', 'torre'],

        # FINALES — Cap 7
        'final_especial_cap7': ['Sin máscara', 'Consigue el final especial del Capítulo 7.', None, 'gold', 'final', 'torre'],

        # HISTORIA / EXPLORACIÓN / DECISIONES — Cap 7
        'recuerdos_cap7':       ['Los recuerdos del piso 7', 'Ve los dos flashbacks del Capítulo 7.',                     None, 'bronze', 'historia',    'torre'],
        'notas_completas_cap7': ['El cuaderno de Nao',       'Descubre todas las notas del Capítulo 7.',                  None, 'silver', 'historia',    'torre'],
        'eco_completo_cap7':    ['El que escucha VII',       'Escucha las tres apariciones de El·yon en el Capítulo 7.',  None, 'silver', 'historia',    'torre'],
        'objetos_cap7':         ['Ojo de lince VII',         'Pulsa los dos objetos especiales del Capítulo 7.',          None, 'bronze', 'exploracion', 'torre'],
        'deducciones_cap7':     ['Mente despierta VII',      'Acierta las dos deducciones del Capítulo 7.',               None, 'silver', 'decisiones',  'torre'],

        # =======================================================
        # HISTORIA (continuación) — Cap 8
        # =======================================================
        'octavo_despertar': ['El reflejo despierta', 'Comienza el Capítulo 8.', None, 'bronze', 'historia', 'torre'],

        # =======================================================
        # FINALES — Cap 8
        # =======================================================
        'final_especial_cap8': ['Sin reflejo', 'Consigue el final especial del Capítulo 8.', None, 'gold', 'final', 'torre'],

        # =======================================================
        # HISTORIA / EXPLORACIÓN / DECISIONES — Cap 8
        # =======================================================
        'recuerdos_cap8':       ['Los recuerdos del piso 8', 'Ve los dos flashbacks del Capítulo 8.',                     None, 'bronze', 'historia',    'torre'],
        'notas_completas_cap8': ['El cuaderno de Emi',       'Descubre todas las notas del Capítulo 8.',                  None, 'silver', 'historia',    'torre'],
        'eco_completo_cap8':    ['El que escucha VIII',      'Escucha las tres apariciones de El·yon en el Capítulo 8.',  None, 'silver', 'historia',    'torre'],
        'objetos_cap8':         ['Ojo de lince VIII',        'Pulsa los dos objetos especiales del Capítulo 8.',          None, 'bronze', 'exploracion', 'torre'],
        'deducciones_cap8':     ['Mente despierta VIII',     'Acierta las dos deducciones del Capítulo 8.',               None, 'silver', 'decisiones',  'torre'],


        # ═══════════════════════════════════════════════════════
        # DLC DE PRUEBA — La Mansión (COMENTADO hasta que salga el DLC)
        # ═══════════════════════════════════════════════════════
        # "mansion_cap1": ["El umbral de la mansión", "Empieza el Capítulo 1 de La Mansión.", None, "bronze", "historia", "mansion"],
        # "mansion_cap1_completado": ["Huésped", "Completa el Capítulo 1 de La Mansión.", None, "silver", "historia", "mansion"],
        # "mansion_conocer_mayordomo": ["El mayordomo sin nombre", "Conoce al mayordomo.", None, "bronze", "personajes", "mansion"],
        # "mansion_primera_decision": ["Bienvenido a la casa", "Toma tu primera decisión en La Mansión.", None, "bronze", "decisiones", "mansion"],
        # "mansion_espejo_roto": ["Siete años de mala suerte", "Rompe un espejo en La Mansión.", None, "silver", "exploracion", "mansion"],
        # "mansion_final_bueno": ["Salir con vida", "Consigue el final bueno del Capítulo 1.", None, "gold", "final", "mansion"],
        # "mansion_final_malo": ["No salió nadie", "Consigue el final malo del Capítulo 1.", None, "silver", "final", "mansion"],
    }


init python:
    def create_trophy(key):
        data = achievement_name[key]
        return Achievement(
            name=data[0],
            message=data[1],
            image=data[2],
            type=data[3],
            category=data[4],
            historia=data[5] if len(data) > 5 else "torre"
        )

    Achievement.all_achievements = {}

    for key in achievement_name:
        trophy = create_trophy(key)
        globals()["achievement_" + key] = trophy
        Achievement.register(trophy)


transform TrophyAppear:
    alpha 0.0
    yoffset 30.0
    on show:
        easein 0.3 alpha 1.0
        easein 0.3 yoffset 0


style trophy_menu_title:
    font gui.title_text_font
    size 60
    outlines gui.title_text_outlines
    color "#FF4444"
    xalign 0.5
    yalign 0.5

style trophy_counter:
    font gui.text_font
    size 24
    outlines gui.title_text_outlines
    color "#FF4444"
    xalign 1.0

style trophy_name:
    size 16
    color "#131111"
    bold True
    xalign 0.5
    text_align 0.5

style trophy_message:
    size 14
    color "#0f0e0e"
    xalign 0.5
    text_align 0.5

style trophy_tab_button:
    font gui.text_font
    size 18
    color "#FFFFFF"
    background "#444444"
    hover_background "#666666"
    selected_background "#FF4444"
    selected_color "#FFFFFF"
    padding (12, 6, 12, 6)
    xalign 0.5
    yalign 0.5


# -----------------------------------------------------------------
# MENÚ DE LOGROS — VERSIÓN MEJORADA
# -----------------------------------------------------------------
# -----------------------------------------------------------------
# MENÚ DE LOGROS — VERSIÓN MEJORADA
# -----------------------------------------------------------------
screen achievement_menu():
    tag menu

    default historia_actual = "torre"
    default current_category = "historia"
    default categories = [
        ("historia",   "Historia"),
        ("final",      "Finales"),
        ("exploracion","Exploración"),
        ("personajes", "Personajes"),
        ("coleccion",  "Colección"),
        ("miedo",      "Miedo"),
        ("estados",    "Estados"),
        ("decisiones", "Decisiones"),
        ("rutas",      "Rutas"),
        ("minijuegos", "Minijuegos"),
    ]

    # ── Fondo ──
    add "images/fondotrofeos.png"
    add Solid("#00000088")

    # ── Marco principal ──
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1760
        ysize 980
        background Solid("#14120aEE")
        padding (40, 30)

        vbox:
            spacing 15
            xfill True
            yfill True

            # ═══════════════════════════════════════════════════════════
            #  CABECERA
            # ═══════════════════════════════════════════════════════════
            vbox:
                spacing 4
                xalign 0.5

                text "🏆 TROFEOS":
                    size 42
                    bold True
                    color "#FFD700"
                    xalign 0.5

                $ total_achievements = len(Achievement.all_achievements)
                $ unlocked_achievements = len([a for a in Achievement.all_achievements.values() if Achievement.has(a.name)])
                text "[unlocked_achievements] / [total_achievements] desbloqueados":
                    size 15
                    color "#a0a0a0"
                    xalign 0.5

            # ═══════════════════════════════════════════════════════════
            #  SELECTOR DE HISTORIA
            # ═══════════════════════════════════════════════════════════
            hbox:
                spacing 10
                xalign 0.5

                for hist_id, hist_data in capitulos.historias.items():
                    if hist_data.get("desbloqueado", False):
                        textbutton "[hist_data['icono']]":
                            action SetScreenVariable("historia_actual", hist_id)
                            style "trophy_tab_button"
                            xminimum 60
                            if historia_actual == hist_id:
                                background "#FFD700"
                                text_color "#000"
                            else:
                                background "#333333"
                                text_color "#CCCCCC"

                $ nom_hist = capitulos.historias[historia_actual]["nombre"]
                text "[nom_hist]":
                    size 18
                    bold True
                    color "#FFD700"
                    yalign 0.5
                    xoffset 10

            null height 5

            # ═══════════════════════════════════════════════════════════
            #  PESTAÑAS DE CATEGORÍA
            # ═══════════════════════════════════════════════════════════
            vbox:
                spacing 6
                xalign 0.5

                hbox:
                    spacing 8
                    xalign 0.5

                    for i in range(0, 5):
                        if i < len(categories):
                            $ cat_id, cat_name = categories[i]
                            $ n_total = contar_logros_categoria(cat_id, historia_actual)
                            $ n_unlocked = contar_logros_categoria_desbloqueados(cat_id, historia_actual)

                            textbutton "[cat_name] ([n_unlocked]/[n_total])":
                                action SetScreenVariable("current_category", cat_id)
                                style "trophy_tab_button"
                                xminimum 180
                                if current_category == cat_id:
                                    background "#FFD700"
                                    text_color "#000"
                                else:
                                    background "#333333"
                                    text_color "#CCCCCC"

                hbox:
                    spacing 8
                    xalign 0.5

                    for i in range(5, len(categories)):
                        $ cat_id, cat_name = categories[i]
                        $ n_total = contar_logros_categoria(cat_id, historia_actual)
                        $ n_unlocked = contar_logros_categoria_desbloqueados(cat_id, historia_actual)

                        textbutton "[cat_name] ([n_unlocked]/[n_total])":
                            action SetScreenVariable("current_category", cat_id)
                            style "trophy_tab_button"
                            xminimum 180
                            if current_category == cat_id:
                                background "#FFD700"
                                text_color "#000"
                            else:
                                background "#333333"
                                text_color "#CCCCCC"

            null height 10

            # ═══════════════════════════════════════════════════════════
            #  GRID DE LOGROS
            # ═══════════════════════════════════════════════════════════
            frame:
                xfill True
                yfill True
                background Solid("#0a0805")
                padding (15, 15)

                viewport:
                    xfill True
                    yfill True
                    mousewheel True
                    scrollbars "vertical"

                    vbox:
                        spacing 15

                        $ achievements_list = [a for a in Achievement.all_achievements.values() if a.category == current_category and a.historia == historia_actual]
                        $ cols = 5
                        $ total_a = len(achievements_list)
                        $ rows = (total_a + cols - 1) // cols

                        if achievements_list:
                            for r in range(rows):
                                hbox:
                                    spacing 15
                                    xalign 0.5

                                    for c in range(cols):
                                        $ idx = r * cols + c
                                        if idx < total_a:
                                            $ t = achievements_list[idx]
                                            $ unlocked = Achievement.has(t.name)
                                            $ is_hidden = t.type == "hidden"

                                            $ show_name = t.name if unlocked else "???"
                                            $ show_msg = t.message if unlocked else "???"
                                            $ show_type = t.type if unlocked else "locked"
                                            $ show_image = t.image if unlocked else ("images/icons/hidden.png" if is_hidden else "images/icons/locked.png")
                                            $ color_borde = TROPHY_COLORS.get(show_type, "#888888")

                                            # ── Card de logro ──
                                            frame:
                                                xsize 320
                                                ysize 240
                                                background Solid("#1a1a1a")
                                                padding (14, 14)

                                                vbox:
                                                    spacing 12
                                                    xalign 0.5
                                                    yalign 0.5
                                                    xfill True

                                                    frame:
                                                        xsize 90
                                                        ysize 90
                                                        background Solid(color_borde)
                                                        padding (5, 5)
                                                        xalign 0.5

                                                        if renpy.loadable(show_image):
                                                            add Transform(show_image, xsize=80, ysize=80) xalign 0.5 yalign 0.5
                                                        else:
                                                            text "?" size 45 color "#FFF" xalign 0.5 yalign 0.5

                                                    text show_name:
                                                        size 18
                                                        bold True
                                                        color (color_borde if unlocked else "#666666")
                                                        xalign 0.5
                                                        text_align 0.5
                                                        xmaximum 290

                                                    text show_msg:
                                                        size 13
                                                        color ("#cccccc" if unlocked else "#444444")
                                                        xalign 0.5
                                                        text_align 0.5
                                                        xmaximum 290
                                        else:
                                            null width 320 height 240
                        else:
                            text "No hay trofeos en esta categoría":
                                size 18
                                color "#666"
                                xalign 0.5
                                italic True

        # ═══════════════════════════════════════════════════════════
        #  BOTÓN VOLVER ARRIBA IZQUIERDA
        # ═══════════════════════════════════════════════════════════
        textbutton "← Volver":
            style "menu_button"
            xalign 0.0
            yalign 0.0
            action Return()