# ═══════════════════════════════════════════════════════════════
#  57cap08_objetos.rpy — Objetos clicables del Capítulo 8
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE OBJETOS
# ─────────────────────────────────────────────────────────────
image cap08_poema = Solid("#1e1a22")
image cap08_espejo = Solid("#1c1c24")


# ═══════════════════════════════════════════════════════════════
#  OBJETO 1 — POEMA EN LA PARED
# ═══════════════════════════════════════════════════════════════
screen cap08_poema_interactivo():
    modal True

    add "bg_piso8_despertar"

    # ── Pista visual: poema en la pared ──
    frame:
        xpos 0.42
        ypos 0.55
        xsize 250
        ysize 250
        background Solid("#1e1a22")

        text "📜":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.7)

    # ── Zona clicable ──
    button:
        xpos 0.42
        ypos 0.55
        xsize 250
        ysize 250
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa el poema":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  OBJETO 2 — ESPEJO ROTO
# ═══════════════════════════════════════════════════════════════
screen cap08_espejo_interactivo():
    modal True

    add "bg_piso8_habitaciones"

    # ── Pista visual: espejo roto sobre la cama ──
    frame:
        xpos 0.5
        ypos 0.5
        xsize 250
        ysize 250
        background Solid("#1c1c24")

        text "🪞":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.6)

    # ── Zona clicable ──
    button:
        xpos 0.5
        ypos 0.5
        xsize 250
        ysize 250
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa el espejo roto":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  LABELS DE EFECTO
# ═══════════════════════════════════════════════════════════════

# ── Al pulsar el poema ──
label cap08_pulsar_poema:
    $ marcar_objeto_visto("poema_pared")
    $ gtn_puertas_pulsadas += 1

    show cap08_poema at truecenter
    with dissolve

    n "El poema está escrito con letra temblorosa."

    n "Y habla de una niña que escribe."

    n "Y de un hospital que nunca duerme."

    n "Y al final, una firma."

    n "El nombre de Emi."

    $ aprender_palabra("torre", "poema_emi")

    em "..."

    em "Es mi nombre."

    kz "¿Qué?"

    em "El poema. Está firmado con mi nombre."

    kz "..."

    kz "Eso no puede ser bueno."

    em "No lo es."

    em "Porque si mi poema está aquí..."

    em "Significa que yo también estoy aquí."

    em "Como los demás."

    n "Y entonces, la tinta del poema tiembla."

    n "Y por un momento, se mueve."

    n "Y vuelve a quedarse quieta."

    n "Como si hubiera respirado."

    hide cap08_poema
    with dissolve

    $ desbloquear_pista("torre", "p8_poema_emi")
    call cap08_nota_hospital

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    return


# ── Al pulsar el espejo roto ──
label cap08_pulsar_espejo:
    $ marcar_objeto_visto("espejo_roto")
    $ gtn_puertas_pulsadas += 1

    show cap08_espejo at truecenter
    with dissolve

    n "El espejo está roto. Partido en tres."

    n "Pero todavía refleja."

    n "Y en el reflejo, hay alguien."

    n "Que no eres tú."

    $ aprender_palabra("torre", "favor_kazuki")

    em "Kazuki."

    kz "¿Qué?"

    em "Este espejo."

    em "Refleja a alguien."

    kz "..."

    kz "No lo mires."

    em "¿Por qué?"

    kz "Porque si lo miras, te ve."

    em "¿Y qué pasa si te ve?"

    kz "..."

    kz "No lo sé."

    kz "Pero no quiero saberlo."

    n "Emi retira la mirada."

    n "Despacio."

    n "Pero el espejo sigue ahí."

    n "Roto."

    n "Con el reflejo de Kazuki."

    hide cap08_espejo
    with dissolve

    $ desbloquear_pista("torre", "p8_favor_kazuki")
    call cap08_nota_favor

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("terror", +5)

    return