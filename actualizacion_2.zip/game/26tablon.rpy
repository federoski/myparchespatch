# ═══════════════════════════════════════════════════════════════
#  25tablon.rpy — Tablón de investigación
#  -----------------------------------------------------------------
#  Diseño tipo corcho con papeles clavados.
# ═══════════════════════════════════════════════════════════════

init python:
    if not hasattr(persistent, "tablon_pistas") or persistent.tablon_pistas is None or isinstance(persistent.tablon_pistas, bool):
        persistent.tablon_pistas = {}

    if not hasattr(persistent, "tablon_deducciones") or persistent.tablon_deducciones is None or isinstance(persistent.tablon_deducciones, bool):
        persistent.tablon_deducciones = {}

    # ── PISTAS ──
    PISTAS = {
        "torre": {
            "p1_puerta_cerrada": {
                "nombre": "La puerta que se cierra",
                "icono": "🚪",
                "capitulo": 1,
                "categoria": "evento",
                "texto": "Akira recuerda una puerta cerrándose. Es lo único que recuerda antes de despertar en la torre.",
            },
            "p1_marca_pared": {
                "nombre": "La marca «Ayúdame»",
                "icono": "🩸",
                "capitulo": 1,
                "categoria": "objeto",
                "texto": "Alguien escribió «ayúdame» con las uñas y sangre en la pared. Los puntos suspensivos no me cuadra que alguien lo haga al pedir ayuda.",
            },
            "p1_susurro_elyon": {
                "nombre": "El susurro «El·yon»",
                "icono": "👁️",
                "capitulo": 1,
                "categoria": "evento",
                "texto": "Solo Akira lo oyó. Ren no. Y el nombre no aparece escrito en ningún sitio.",
            },
            "p2_reflejo_retrasado": {
                "nombre": "El reflejo con retraso",
                "icono": "🪞",
                "capitulo": 2,
                "categoria": "evento",
                "texto": "Los espejos del piso 2 tardan medio segundo en copiar los movimientos.",
            },
            "p2_inscripcion_espejo": {
                "nombre": "«El reflejo no miente»",
                "icono": "📜",
                "capitulo": 2,
                "categoria": "objeto",
                "texto": "Inscripción en el marco de un espejo. Alguien la dejó antes. Nadie sabe quién.",
            },
            "p2_eco_verdadero": {
                "nombre": "El eco que no repite",
                "icono": "🗣️",
                "capitulo": 2,
                "categoria": "evento",
                "texto": "El eco del piso 2 no repite lo que dices. Dice lo que piensas.",
            },
            "p2_fragmento_18": {
                "nombre": "El fragmento con 18 figuras",
                "icono": "🧩",
                "capitulo": 2,
                "categoria": "objeto",
                "texto": "Un fragmento de espejo roto mostró a 18 personas juntas. Ninguna era Yuki ni Sora.",
            },
            "p3_telon_subido": {
                "nombre": "El telón subido",
                "icono": "🎭",
                "capitulo": 3,
                "categoria": "evento",
                "texto": "El telón del teatro nunca debería estar subido. Pero a veces lo está.",
            },
            "p3_butacas_ocupadas": {
                "nombre": "Las butacas ocupadas",
                "icono": "🪑",
                "capitulo": 3,
                "categoria": "lugar",
                "texto": "Algunas butacas del teatro tienen siluetas que no se mueven. Demasiado quietas para estar vivas.",
            },
            "p3_programa_mano": {
                "nombre": "El programa de mano",
                "icono": "📄",
                "capitulo": 3,
                "categoria": "objeto",
                "texto": "Todos los programas tienen subrayada la misma frase: «El telón no se abre».",
            },
            "p3_aplauso_vacio": {
                "nombre": "El aplauso sin público",
                "icono": "👏",
                "capitulo": 3,
                "categoria": "evento",
                "texto": "Se escuchan aplausos cuando no hay nadie en las butacas.",
            },
            "p1_simbolo_suelo": {
                "nombre": "El símbolo del suelo",
                "icono": "🔯",
                "capitulo": 1,
                "categoria": "objeto",
                "texto": "Un símbolo tallado en el suelo. Mismo trazo que la marca de la pared. La misma persona. O la misma cosa.",
            },
            "p1_puerta_cerrada_simbolos": {
                "nombre": "La puerta sin cerradura",
                "icono": "🔑",
                "capitulo": 1,
                "categoria": "objeto",
                "texto": "La puerta de salida tiene símbolos grabados y no tiene cerradura. ¿Cómo se supone que se abre? ¿Con qué? ¿Con quién?",
            },
            "p1_no_es_casualidad": {
                "nombre": "No es casualidad",
                "icono": "🎯",
                "capitulo": 1,
                "categoria": "evento",
                "texto": "Nadie llega a la torre por casualidad. Algo o alguien te trajo. Y no fue un accidente.",
            },
            "p1_torre_no_termina": {
                "nombre": "La torre no termina aquí",
                "icono": "🏢",
                "capitulo": 1,
                "categoria": "lugar",
                "texto": "La puerta no lleva a la salida. Lleva a otro piso. Y después, a otro. Y a otro. La torre no termina en el piso 1.",
            },
            "p2_todos_en_el_espejo": {
                "nombre": "Todos en el espejo",
                "icono": "🧩",
                "capitulo": 2,
                "categoria": "objeto",
                "texto": "El símbolo del espejo y el fragmento con 18 figuras. Los espejos no son decorado. Forman parte del sistema.",
            },
            "p2_puerta_sin_cerradura": {
                "nombre": "La puerta sin cerradura",
                "icono": "🔑",
                "capitulo": 2,
                "categoria": "objeto",
                "texto": "La puerta-espejo del piso 2 no tiene cerradura ni manilla. ¿Cómo se supone que se abre? ¿Con qué? ¿Con quién?",
            },
            "p2_reflejo_elige": {
                "nombre": "El reflejo elige",
                "icono": "🪞",
                "capitulo": 2,
                "categoria": "evento",
                "texto": "El retraso del reflejo no es un error. Es una decisión. Los espejos eligen qué copiar.",
            },
            "p2_eco_dice_pensamientos": {
                "nombre": "El eco dice lo que piensas",
                "icono": "🗣️",
                "capitulo": 2,
                "categoria": "evento",
                "texto": "El eco no repite lo que dices. Dice lo que piensas. Por eso cada uno oye algo distinto.",
            },
            "p3_puerta_sin_cerradura": {
                "nombre": "La puerta sin cerradura",
                "icono": "🔑",
                "capitulo": 3,
                "categoria": "objeto",
                "texto": "La puerta detrás del telón no tiene cerradura. Solo símbolos grabados. ¿Cómo se abre?",
            },
            "p3_susurro_elyon": {
                "nombre": "El susurro en el teatro",
                "icono": "👁️",
                "capitulo": 3,
                "categoria": "evento",
                "texto": "El·yon también susurra en el teatro. La misma voz. El mismo nombre.",
            },
            "p3_publico_recuerda": {
                "nombre": "El público recuerda",
                "icono": "👏",
                "capitulo": 3,
                "categoria": "evento",
                "texto": "El aplauso no es una grabación. Es un recuerdo. El teatro recuerda la última función. Y la repite.",
            },
            "p3_telon_es_puerta": {
                "nombre": "El telón es una puerta",
                "icono": "🎭",
                "capitulo": 3,
                "categoria": "objeto",
                "texto": "El telón no se cierra como una tela. Se cierra como una puerta. Y las puertas se cierran para que no pase algo.",
            },

            # ── Capítulo 4: Mei & Daichi ──
            "p4_puertas_nombres": {
                "nombre": "Las puertas con nombres",
                "icono": "🚪",
                "capitulo": 4,
                "categoria": "lugar",
                "texto": "Todas las puertas del piso 4 tienen un nombre grabado. Nombres de personas. Algunos conocidos. Otros no. Pero todos reales.",
            },
            "p4_llaves_colgadas": {
                "nombre": "El cuarto de las llaves",
                "icono": "🔑",
                "capitulo": 4,
                "categoria": "objeto",
                "texto": "Un cuarto lleno de llaves. Cada una con un nombre. Algunas pesan más que otras. Como si supieran algo.",
            },
            "p4_morgue_daichi": {
                "nombre": "La morgue de Daichi",
                "icono": "🥶",
                "capitulo": 4,
                "categoria": "lugar",
                "texto": "Daichi trabajó aquí. De noche. Dos años. Y aquí conoció a alguien que no debería haber conocido. Y que ya no está.",
            },
            "p4_cajon_abierto": {
                "nombre": "El cajón abierto",
                "icono": "⌚",
                "capitulo": 4,
                "categoria": "objeto",
                "texto": "Un cajón abierto. Y dentro, un reloj de pulsera que funciona. Y que no es de Daichi. Pero se parece. Y sigue andando.",
            },
            "p4_susurro_mei": {
                "nombre": "El susurro dice Mei",
                "icono": "🗣️",
                "capitulo": 4,
                "categoria": "evento",
                "texto": "El susurro dice «Mei». Solo Mei. Pero Daichi también lo oye. Y cada uno oye algo distinto.",
            },
            "p4_puerta_19": {
                "nombre": "La puerta 19",
                "icono": "🚪",
                "capitulo": 4,
                "categoria": "objeto",
                "texto": "Una puerta más. Una que no existía antes. Y que Mei ha dibujado sin darse cuenta. O quizá sí. Quizá la dibujó a propósito. Y no se acuerda.",
            },

            # ── Capítulo 5: Rin & Tsubasa ──
            "p5_tablero_se_reinicia": {
                "nombre": "El tablero se reinicia",
                "icono": "⏳",
                "capitulo": 5,
                "categoria": "evento",
                "texto": "Cada 5 minutos, el tablero vuelve a su posición inicial. Y cada vez se reinicia más rápido.",
            },
            "p5_sombra_rin": {
                "nombre": "La sombra de Rin",
                "icono": "🌑",
                "capitulo": 5,
                "categoria": "evento",
                "texto": "Una sombra que solo Rin ve. Es lo que dejó atrás cuando cruzó la primera puerta del piso 1.",
            },
            "p5_calculo_tsubasa": {
                "nombre": "El cálculo de Tsubasa",
                "icono": "🧮",
                "capitulo": 5,
                "categoria": "persona",
                "texto": "Tsubasa ya calculó la salida. La salida cuesta dos vidas. Y una es la suya.",
            },
            "p5_pieza_33": {
                "nombre": "La pieza 33",
                "icono": "♚",
                "capitulo": 5,
                "categoria": "objeto",
                "texto": "El ajedrez tiene 32 piezas. Siempre. 32. Ni una más. Pero esta es la 33.",
            },
            "p5_reloj_tsubasa": {
                "nombre": "El reloj de Tsubasa",
                "icono": "⌚",
                "capitulo": 5,
                "categoria": "objeto",
                "texto": "Marcaba las 5:00. Pero antes marcaba las 5:01. Y cuando Tsubasa lo mira, tiembla.",
            },
            "p5_puerta_al_fondo": {
                "nombre": "La puerta del fondo",
                "icono": "🚪",
                "capitulo": 5,
                "categoria": "lugar",
                "texto": "Al fondo del tablero, entre los dos reyes, hay una puerta. Pequeña. Alta. Con 32 casillas grabadas.",
            },

            # ── Capítulo 6: Ayame & Hiro ──
            "p6_velas_nombres": {
                "nombre": "Las velas con nombres",
                "icono": "🕯️",
                "capitulo": 6,
                "categoria": "objeto",
                "texto": "Cada vela del templo tiene un nombre. Y todas están encendidas. Cuando una vela se apaga, la persona se olvida.",
            },
            "p6_campanas_nombres": {
                "nombre": "Las campanas con nombres",
                "icono": "🔔",
                "capitulo": 6,
                "categoria": "objeto",
                "texto": "Cada campana tiene un nombre. Y todas están quietas. Suenan solo cuando alguien las llama. Y solo una vez.",
            },
            "p6_pozo_habla": {
                "nombre": "El pozo que habla",
                "icono": "🕳️",
                "capitulo": 6,
                "categoria": "evento",
                "texto": "El pozo dice nombres. Y come culpa. Cada vez que alguien se siente culpable, el pozo se alimenta.",
            },
            "p6_hiro_accidente": {
                "nombre": "El accidente de Hiro",
                "icono": "🚗",
                "capitulo": 6,
                "categoria": "evento",
                "texto": "Hiro cree que causó un accidente. Pero el pozo dice que no fue culpa suya. Y el pozo no miente.",
            },
            "p6_ayame_escucha": {
                "nombre": "Ayame escucha",
                "icono": "👂",
                "capitulo": 6,
                "categoria": "persona",
                "texto": "Ayame oye a los muertos. No con los oídos. Con el pecho. Como le enseñó su abuela.",
            },
            "p6_puerta_al_fondo": {
                "nombre": "La puerta al fondo",
                "icono": "🚪",
                "capitulo": 6,
                "categoria": "lugar",
                "texto": "Al fondo del templo, subiendo la escalera, hay una puerta con sellos de papel rotos. Solo se abre si el pozo se cierra.",
            },

            # ── Capítulo 7: Nao & Souta ──
            "p7_mascara_rota": {
                "nombre": "La máscara rota",
                "icono": "🎭",
                "capitulo": 7,
                "categoria": "objeto",
                "texto": "Una máscara de porcelana rota. Con el nombre de Nao dentro. Alguien la rompió. O ella misma. O el circo.",
            },
            "p7_espejo_nao": {
                "nombre": "El espejo de Nao",
                "icono": "🪞",
                "capitulo": 7,
                "categoria": "objeto",
                "texto": "Un espejo deformante que refleja a Nao. Pero no a la Nao que sonríe. A la que llora. Y que nunca ha visto nadie.",
            },
            "p7_souta_oidos": {
                "nombre": "Los oídos de Souta",
                "icono": "🤫",
                "capitulo": 7,
                "categoria": "persona",
                "texto": "Souta se tapa los oídos cuando hay silencio. Porque el silencio es lo que dejó atrás. Y no puede volver.",
            },
            "p7_publico_rie": {
                "nombre": "El público que ríe",
                "icono": "👥",
                "capitulo": 7,
                "categoria": "evento",
                "texto": "Las siluetas sin cara que aplauden desde las gradas. No respiran. Solo esperan. Y cuando alguien deja de sonreír, se sientan.",
            },
            "p7_funcion_unica": {
                "nombre": "La función única",
                "icono": "🎪",
                "capitulo": 7,
                "categoria": "lugar",
                "texto": "Un cartel en la entrada del circo: «FUNCIÓN ÚNICA — 33ª vez». Alguien ha contado mal. O alguien lleva 33 funciones sin terminar ninguna.",
            },
            "p7_puerta_al_fondo": {
                "nombre": "La puerta del circo",
                "icono": "🚪",
                "capitulo": 7,
                "categoria": "lugar",
                "texto": "Al fondo de la carpa, detrás del círculo, hay una puerta con una estrella pintada. Solo se abre si alguien recuerda los aplausos. En orden.",
            },

            # ── Capítulo 8: Emi & Kazuki ──
            "p8_poema_emi": {
                "nombre": "El poema de Emi",
                "icono": "📜",
                "capitulo": 8,
                "categoria": "objeto",
                "texto": "Un poema escrito en la pared del hospital. Con la letra de Emi. Pero ella no lo recuerda. O no quiere recordarlo.",
            },
            "p8_espejo": {
                "nombre": "El espejo del pasillo",
                "icono": "🪞",
                "capitulo": 8,
                "categoria": "objeto",
                "texto": "Un espejo al final del pasillo. Refleja una versión de Emi que sonríe. Pero Emi no sonríe. Y el reflejo tampoco deja de mirarla.",
            },
            "p8_seis_meses": {
                "nombre": "Los seis meses",
                "icono": "🕰️",
                "capitulo": 8,
                "categoria": "evento",
                "texto": "Emi estuvo ingresada seis meses. Salió. Pero no del todo. Porque cada vez que escribe un poema, vuelve a estar dentro.",
            },
            "p8_favor_kazuki": {
                "nombre": "El favor de Kazuki",
                "icono": "🤝",
                "capitulo": 8,
                "categoria": "evento",
                "texto": "Kazuki compró su presidencia con un favor. Y desde entonces, sonríe. Porque si no sonríe, se acuerda de lo que hizo.",
            },
            "p8_espejo_roto": {
                "nombre": "El espejo roto",
                "icono": "🔨",
                "capitulo": 8,
                "categoria": "objeto",
                "texto": "Un espejo pequeño, roto en tres. Con un nombre grabado. Y con un reflejo que sigue ahí. Aunque el espejo esté roto.",
            },
            "p8_puerta_al_fondo": {
                "nombre": "La puerta del hospital",
                "icono": "🚪",
                "capitulo": 8,
                "categoria": "lugar",
                "texto": "Al fondo del pasillo, una puerta de metal con una cruz roja descolorida. Solo se abre si alguien recuerda los poemas. En orden.",
            },
        },
    }

    # ── DEDUCCIONES ──
    DEDUCCIONES = {
        "torre": {
            "d_akira_olvida": {
                "nombre": "Akira olvidó algo importante",
                "icono": "🧠",
                "pistas_requeridas": ["p1_puerta_cerrada", "p1_susurro_elyon"],
                "texto": "La puerta cerrándose + que solo Akira oiga el susurro = Akira no vino aquí por accidente. Vino porque algo lo llamó.",
            },
            "d_los_18_saben": {
                "nombre": "Los 18 ya se conocen",
                "icono": "🧩",
                "pistas_requeridas": ["p2_fragmento_18", "p1_susurro_elyon"],
                "texto": "El fragmento muestra 18 personas juntas. El·yon ve a todos. La torre ya los tenía en cuenta antes de que llegaran.",
            },
            "d_los_reflejos_copian": {
                "nombre": "Los reflejos no copian. Guardan.",
                "icono": "🪞",
                "pistas_requeridas": ["p2_reflejo_retrasado", "p2_inscripcion_espejo"],
                "texto": "El retraso no es por lentitud. Es porque el reflejo decide qué copiar. Y lo que copia, lo guarda para siempre.",
            },
            "d_el_telon_come": {
                "nombre": "El telón se lleva recuerdos",
                "icono": "🎭",
                "pistas_requeridas": ["p3_telon_subido", "p3_programa_mano", "p3_aplauso_vacio"],
                "texto": "El telón no mata. Se lleva recuerdos. Por eso los programas insisten en la frase. Cada función arranca una memoria.",
            },
        },
    }

    # ── Funciones ──
    def desbloquear_pista(historia, clave):
        if historia in PISTAS and clave in PISTAS[historia]:
            if not pista_desbloqueada(historia, clave):
                persistent.tablon_pistas.setdefault(historia, {})[clave] = True
                notificar("🔍", "Nueva pista", PISTAS[historia][clave]["nombre"], "#FFD700")
                comprobar_deducciones(historia)
            return True
        return False

    def pista_desbloqueada(historia, clave):
        return persistent.tablon_pistas.get(historia, {}).get(clave, False)

    def pistas_descubiertas(historia):
        if historia not in PISTAS:
            return 0
        return sum(1 for k in PISTAS[historia].keys() if pista_desbloqueada(historia, k))

    def pistas_totales(historia):
        if historia not in PISTAS:
            return 0
        return len(PISTAS[historia])

    def comprobar_deducciones(historia):
        if historia not in DEDUCCIONES:
            return
        for clave, ded in DEDUCCIONES[historia].items():
            if deduccion_desbloqueada(historia, clave):
                continue
            if all(pista_desbloqueada(historia, p) for p in ded["pistas_requeridas"]):
                persistent.tablon_deducciones.setdefault(historia, {})[clave] = True
                notificar("💡", "Nueva deducción", ded["nombre"], "#FF6B9D")

    def deduccion_desbloqueada(historia, clave):
        return persistent.tablon_deducciones.get(historia, {}).get(clave, False)

    def deducciones_descubiertas(historia):
        if historia not in DEDUCCIONES:
            return 0
        return sum(1 for k in DEDUCCIONES[historia].keys() if deduccion_desbloqueada(historia, k))

    def deducciones_totales(historia):
        if historia not in DEDUCCIONES:
            return 0
        return len(DEDUCCIONES[historia])

    def color_categoria(cat):
        if cat == "evento":   return "#B33A3A"
        if cat == "objeto":   return "#A07830"
        if cat == "lugar":    return "#3A6B8C"
        if cat == "persona":  return "#3A7C3A"
        return "#888"

    def caps_deducciones(historia):
        caps = set()
        if historia not in DEDUCCIONES or historia not in PISTAS:
            return []
        for k, v in DEDUCCIONES[historia].items():
            for p in v["pistas_requeridas"]:
                if p in PISTAS[historia]:
                    caps.add(PISTAS[historia][p]["capitulo"])
                    break
        return sorted(caps)

    def deds_de_capitulo(historia, cap):
        resultado = []
        if historia not in DEDUCCIONES or historia not in PISTAS:
            return []
        for dk, dv in DEDUCCIONES[historia].items():
            for p in dv["pistas_requeridas"]:
                if p in PISTAS[historia] and PISTAS[historia][p]["capitulo"] == cap:
                    resultado.append(dk)
                    break
        return resultado


# ═══════════════════════════════════════════════════════════════
#  SCREEN DEL TABLÓN — ESTILO CORCHO
# ═══════════════════════════════════════════════════════════════
screen tablon_menu():
    tag menu
    modal True

    default historia_actual = "torre"
    default tab = "pistas"

    # Fondo color corcho
    add Solid("#3d2a1a")

    # Marco de madera
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1160
        ysize 820
        background Solid("#5a3d22")
        padding (10, 10)

        frame:
            xfill True
            yfill True
            background Solid("#4a3020")
            padding (20, 20)

            has vbox spacing 15

            # ── Cabecera estilo "papel clavado" ──
            frame:
                xalign 0.5
                background Solid("#f4e4c1")
                padding (30, 15)

                vbox:
                    spacing 2

                    text "📍":
                        xalign 0.5

                    text "🗝️ TABLÓN DE INVESTIGACIÓN":
                        size 26
                        bold True
                        color "#3a2410"
                        xalign 0.5
                        text_align 0.5

                    text "Pistas y deducciones — [capitulos.historias[historia_actual]['nombre']]":
                        size 13
                        color "#6b4a28"
                        xalign 0.5

            # ── Pestañas (Pistas / Deducciones) ──
            hbox:
                spacing 15
                xalign 0.5

                # Pestaña: Pistas
                button:
                    background (Solid("#f4e4c1") if tab == "pistas" else Solid("#a08050"))
                    hover_background Solid("#e8d4a0")
                    padding (20, 10)
                    action SetScreenVariable("tab", "pistas")

                    text "🔍 Pistas: [pistas_descubiertas(historia_actual)] / [pistas_totales(historia_actual)]":
                        size 15
                        bold True
                        color ("#3a2410" if tab == "pistas" else "#2a1a08")

                # Pestaña: Deducciones
                button:
                    background (Solid("#f4d0d0") if tab == "deducciones" else Solid("#a06060"))
                    hover_background Solid("#e8c0c0")
                    padding (20, 10)
                    action SetScreenVariable("tab", "deducciones")

                    text "💡 Deducciones: [deducciones_descubiertas(historia_actual)] / [deducciones_totales(historia_actual)]":
                        size 15
                        bold True
                        color ("#3a1010" if tab == "deducciones" else "#2a0808")

            # ── Contenido scrolleable ──
            frame:
                xfill True
                yfill True
                background Solid("#3a2418")
                padding (15, 15)

                viewport:
                    xfill True
                    yfill True
                    mousewheel True
                    scrollbars "vertical"

                    has vbox spacing 20 xfill True

                    if tab == "pistas":
                        # ─── PISTAS ───
                        text "▸ PISTAS":
                            size 22
                            bold True
                            color "#f4e4c1"

                        $ caps_con_pistas = sorted(set(PISTAS[historia_actual][k]["capitulo"] for k in PISTAS[historia_actual].keys()))
                        for cap in caps_con_pistas:
                            $ pistas_cap = [k for k, v in PISTAS[historia_actual].items() if v["capitulo"] == cap]

                            frame:
                                xfill True
                                background Solid("#2a1810")
                                padding (14, 8)
                                text "— Capítulo [cap] —":
                                    size 16
                                    bold True
                                    color "#d4b878"
                                    xalign 0.5

                            $ cols = 3
                            $ total_p = len(pistas_cap)
                            $ rows = (total_p + cols - 1) // cols

                            for r in range(rows):
                                hbox:
                                    spacing 15
                                    xfill True

                                    for c in range(cols):
                                        $ idx = r * cols + c
                                        if idx < total_p:
                                            $ pkey = pistas_cap[idx]
                                            $ pdata = PISTAS[historia_actual][pkey]
                                            $ descubierta = pista_desbloqueada(historia_actual, pkey)

                                            if descubierta:
                                                frame:
                                                    xsize 320
                                                    ysize 200
                                                    background Solid("#f4e4c1")
                                                    padding (14, 14)

                                                    has vbox spacing 6

                                                    text "📌":
                                                        xalign 0.5
                                                        yoffset -4

                                                    hbox:
                                                        spacing 8
                                                        text "[pdata['icono']]" size 22
                                                        text "[pdata['nombre']]":
                                                            size 15
                                                            bold True
                                                            color "#3a2410"
                                                            xmaximum 260

                                                    frame:
                                                        xfill True
                                                        ysize 2
                                                        background Solid("#a08050")

                                                    text "[pdata['texto']]":
                                                        size 12
                                                        color "#5a3820"
                                                        xmaximum 290

                                                    frame:
                                                        xalign 1.0
                                                        background Solid("#c8a878")
                                                        padding (6, 2)
                                                        text "[pdata['categoria']]":
                                                            size 10
                                                            color "#3a2410"
                                            else:
                                                frame:
                                                    xsize 320
                                                    ysize 200
                                                    background Solid("#2a1810")
                                                    padding (14, 14)

                                                    has vbox spacing 6
                                                    xalign 0.5
                                                    yalign 0.5

                                                    text "📌" size 24 xalign 0.5
                                                    text "?" size 60 color "#5a3820" xalign 0.5
                                                    text "Pista oculta":
                                                        size 14
                                                        color "#5a3820"
                                                        xalign 0.5
                                                        italic True

                    else:
                        # ─── DEDUCCIONES ───
                        text "▸ DEDUCCIONES DESBLOQUEADAS":
                            size 22
                            bold True
                            color "#f4d0d0"

                        # Contar cuántas deducciones desbloqueadas hay
                        $ deds_desbloqueadas = [k for k in DEDUCCIONES[historia_actual].keys() if deduccion_desbloqueada(historia_actual, k)]

                        if deds_desbloqueadas:
                            for cap in caps_deducciones(historia_actual):
                                $ deds_cap = [k for k in deds_de_capitulo(historia_actual, cap) if deduccion_desbloqueada(historia_actual, k)]

                                if deds_cap:
                                    frame:
                                        xfill True
                                        background Solid("#2a1010")
                                        padding (14, 8)
                                        text "— Capítulo [cap] —":
                                            size 16
                                            bold True
                                            color "#d4a0a0"
                                            xalign 0.5

                                    for dkey in deds_cap:
                                        $ ddata = DEDUCCIONES[historia_actual][dkey]

                                        frame:
                                            xfill True
                                            background Solid("#f4d0d0")
                                            padding (16, 12)

                                            has vbox spacing 6

                                            hbox:
                                                spacing 10
                                                text "📌" size 18 yalign 0.5
                                                text "[ddata['icono']]" size 20 yalign 0.5
                                                text "[ddata['nombre']]":
                                                    size 17
                                                    bold True
                                                    color "#3a1010"

                                            frame:
                                                xfill True
                                                ysize 1
                                                background Solid("#a06060")

                                            text "[ddata['texto']]":
                                                size 13
                                                color "#5a2020"
                        else:
                            frame:
                                xfill True
                                background Solid("#2a1010")
                                padding (20, 16)
                                text "Aún no has deducido nada.":
                                    size 14
                                    color "#6a3030"
                                    xalign 0.5
                                    italic True

                        # ─── DEDUCCIONES BLOQUEADAS ───
                        null height 20

                        text "▸ DEDUCCIONES OCULTAS":
                            size 22
                            bold True
                            color "#6a3030"

                        # Contar cuántas quedan bloqueadas
                        $ deds_bloqueadas = [k for k in DEDUCCIONES[historia_actual].keys() if not deduccion_desbloqueada(historia_actual, k)]

                        if deds_bloqueadas:
                            for dkey in deds_bloqueadas:
                                frame:
                                    xfill True
                                    background Solid("#2a1010")
                                    padding (16, 12)

                                    has hbox spacing 15

                                    text "🔒" size 30 yalign 0.5

                                    vbox:
                                        spacing 4
                                        yalign 0.5
                                        text "Deducción oculta":
                                            size 15
                                            bold True
                                            color "#6a3030"
                                        text "Encuentra todas las pistas para desbloquearla.":
                                            size 12
                                            color "#5a3030"
                                            italic True
                        else:
                            frame:
                                xfill True
                                background Solid("#0f2010")
                                padding (20, 16)
                                text "🎉 ¡Has descubierto TODAS las deducciones de esta historia!":
                                    size 14
                                    bold True
                                    color "#4CAF50"
                                    xalign 0.5

            # ── Botón volver estilo "post-it" ──
            textbutton "← Volver":
                style "menu_button"
                xalign 0.5
                action ShowMenu("extras_menu")