# ═══════════════════════════════════════════════════════════════
#  12minijuegos.rpy — Colección de minijuegos reutilizables
#  Todos devuelven True (éxito) o False (fallo) mediante un
#  store.gtn_minijuego_resultado.
# ═══════════════════════════════════════════════════════════════

default gtn_minijuego_resultado = None

init python:
    def _mj_reset():
        store.gtn_minijuego_resultado = None

    def _mj_fin(exito):
        store.gtn_minijuego_resultado = exito


# -----------------------------------------------------------------
# 1) QTE DE FLECHAS
# -----------------------------------------------------------------
screen minijuego_qte(secuencia, tiempo_por_paso=1.2):
    modal True
    zorder 200

    default indice = 0
    default tiempo_restante = tiempo_por_paso

    frame:
        xalign 0.5
        yalign 0.5
        background "#000000CC"
        padding (40, 30)

        vbox:
            spacing 20
            xalign 0.5

            text "¡PULSA LAS FLECHAS!" size 26 color "#FF4444" xalign 0.5

            hbox:
                spacing 20
                xalign 0.5
                for j, paso in enumerate(secuencia):
                    $ col = "#FFFFFF" if j < indice else ("#FF0000" if j == indice else "#666666")
                    text paso size 48 color col bold True

            text "Tiempo: [int(tiempo_restante)]s" size 18 color "#FFD700" xalign 0.5

    timer 0.1 repeat True action SetScreenVariable("tiempo_restante", max(0, tiempo_restante - 0.1))

    timer 0.1 repeat True action If(tiempo_restante <= 0, Return(False), NullAction())

    key "K_LEFT" action If(
        secuencia[indice] == "←",
        If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
        Return(False)
    )
    key "K_RIGHT" action If(
        secuencia[indice] == "→",
        If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
        Return(False)
    )
    key "K_UP" action If(
        secuencia[indice] == "↑",
        If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
        Return(False)
    )
    key "K_DOWN" action If(
        secuencia[indice] == "↓",
        If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
        Return(False)
    )


# -----------------------------------------------------------------
# 2) MEMORIA DE SECUENCIA
# -----------------------------------------------------------------
screen minijuego_memoria(secuencia, mostrar_tiempo=2.0):
    modal True
    zorder 200

    default fase = "mostrar"
    default indice = 0

    if fase == "mostrar":
        frame:
            xalign 0.5
            yalign 0.5
            background "#000000CC"
            padding (40, 30)

            vbox:
                spacing 20
                xalign 0.5
                text "MEMORIZA" size 26 color "#FFD700" xalign 0.5
                hbox:
                    spacing 20
                    xalign 0.5
                    for s in secuencia:
                        text s size 48 color "#FFFFFF" bold True

        timer mostrar_tiempo action SetScreenVariable("fase", "input")
    else:
        frame:
            xalign 0.5
            yalign 0.5
            background "#000000CC"
            padding (40, 30)

            vbox:
                spacing 20
                xalign 0.5
                text "REPITE" size 26 color "#FF4444" xalign 0.5
                hbox:
                    spacing 20
                    xalign 0.5
                    for j in range(len(secuencia)):
                        $ col = "#FFFFFF" if j < indice else "#666666"
                        text "?" size 48 color col bold True

        key "K_LEFT" action If(
            secuencia[indice] == "←",
            If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
            Return(False)
        )
        key "K_RIGHT" action If(
            secuencia[indice] == "→",
            If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
            Return(False)
        )
        key "K_UP" action If(
            secuencia[indice] == "↑",
            If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
            Return(False)
        )
        key "K_DOWN" action If(
            secuencia[indice] == "↓",
            If(indice + 1 >= len(secuencia), Return(True), SetScreenVariable("indice", indice + 1)),
            Return(False)
        )


label lanzar_memoria(secuencia):
    $ gtn_minijuego_resultado = renpy.call_screen("minijuego_memoria", secuencia=secuencia)
    return


# -----------------------------------------------------------------
# 3) TIMING (barra que rebota, pulsa en verde)
# -----------------------------------------------------------------
screen minijuego_timing(velocidad=1.0, zona_buena=0.15):
    modal True
    zorder 200

    default pos = 0.0
    default direccion = 1

    frame:
        xalign 0.5
        yalign 0.5
        background "#000000CC"
        padding (40, 30)
        xsize 700

        vbox:
            spacing 20
            xalign 0.5

            text "PULSA ESPACIO EN LA ZONA VERDE" size 22 color "#FFD700" xalign 0.5

            frame:
                xsize 600
                ysize 60
                background "#222"

                frame:
                    xpos int((0.5 - zona_buena / 2) * 600)
                    xsize int(zona_buena * 600)
                    ysize 60
                    background "#0F0"

                frame:
                    xpos int(pos * 580)
                    xsize 6
                    ysize 60
                    background "#FF0000"

    timer 0.02 repeat True action SetScreenVariable(
        "pos",
        max(0.0, min(1.0, pos + direccion * velocidad * 0.02))
    )

    timer 0.02 repeat True action If(
        pos >= 1.0,
        SetScreenVariable("direccion", -1),
        If(pos <= 0.0, SetScreenVariable("direccion", 1), NullAction())
    )

    key "K_SPACE" action If(
        abs(pos - 0.5) <= zona_buena / 2,
        Return(True),
        Return(False)
    )


# -----------------------------------------------------------------
# 4) PUZZLE DE CÓDIGO (introduce un número)
# -----------------------------------------------------------------
screen minijuego_codigo(codigo_correcto, pista=""):
    modal True
    zorder 200

    default entrada = ""
    default intentos = 0

    frame:
        xalign 0.5
        yalign 0.5
        background "#000000CC"
        padding (40, 30)
        xsize 600

        vbox:
            spacing 15
            xalign 0.5

            text "INTRODUCE EL CÓDIGO" size 24 color "#FF4444" xalign 0.5

            if pista:
                text pista size 16 color "#AAA" xalign 0.5

            frame:
                xsize 400
                ysize 70
                background "#111"
                text "[entrada]" size 40 color "#0F0" xalign 0.5 yalign 0.5

            hbox:
                spacing 10
                xalign 0.5
                for i in range(1, 10):
                    textbutton "[i]" action SetScreenVariable("entrada", entrada + str(i)) style "menu_button"
                textbutton "0" action SetScreenVariable("entrada", entrada + "0") style "menu_button"

            hbox:
                spacing 15
                xalign 0.5
                textbutton "Borrar" action SetScreenVariable("entrada", entrada[:-1]) style "menu_button"
                textbutton "Enviar" action [
                    If(entrada == codigo_correcto, _mj_fin(True), _mj_fin(False)),
                    Hide("minijuego_codigo")
                ] style "menu_button"

    key "K_ESCAPE" action Hide("minijuego_codigo")


# -----------------------------------------------------------------
# 5) ELIGE EL VERSO (memory simplificado con poemas — Cap 8)
# -----------------------------------------------------------------
screen minijuego_elige_verso(versos, correcto):
    modal True
    zorder 200

    default seleccion = None
    default intentos = 0

    frame:
        xalign 0.5
        yalign 0.5
        background "#000000CC"
        padding (40, 30)
        xsize 800

        vbox:
            spacing 20
            xalign 0.5

            text "¿CUÁL DE ESTOS VERSOS NO ES DE EMI?" size 24 color "#FFD700" xalign 0.5
            text "Intento: [intentos + 1] / 2" size 16 color "#AAAAAA" xalign 0.5

            for i, verso in enumerate(versos):
                textbutton "[verso]":
                    action SetScreenVariable("seleccion", i)
                    style "menu_button"
                    xalign 0.5
                    if seleccion == i:
                        background "#FFD700"
                        text_color "#000"

            null height 10

            if seleccion is not None:
                textbutton "Confirmar":
                    action If(
                        seleccion == correcto,
                        Return(True),
                        If(intentos + 1 >= 2, Return(False), SetScreenVariable("intentos", intentos + 1))
                    )
                    style "menu_button"
                    xalign 0.5


label lanzar_elige_verso(versos, correcto):
    $ gtn_minijuego_resultado = renpy.call_screen("minijuego_elige_verso", versos=versos, correcto=correcto)
    return


# -----------------------------------------------------------------
# 6) LABEL WRAPPER (para usar desde un capítulo)
# -----------------------------------------------------------------
label lanzar_qte(secuencia):
    $ gtn_minijuego_resultado = renpy.call_screen("minijuego_qte", secuencia=secuencia)
    return

label lanzar_timing(velocidad=1.0, zona_buena=0.15):
    $ gtn_minijuego_resultado = renpy.call_screen("minijuego_timing", velocidad=velocidad, zona_buena=zona_buena)
    return

label lanzar_codigo(codigo_correcto, pista=""):
    $ gtn_minijuego_resultado = renpy.call_screen("minijuego_codigo", codigo_correcto=codigo_correcto, pista=pista)
    return