# ═══════════════════════════════════════════════════════════════
#  56cap07_objetos.rpy — Objetos clicables del Capítulo 7
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE OBJETOS
# ─────────────────────────────────────────────────────────────
image cap07_mascara = Solid("#2e1a1e")
image cap07_caja_musica = Solid("#221a10")


# ═══════════════════════════════════════════════════════════════
#  OBJETO 1 — MÁSCARA ROTA
# ═══════════════════════════════════════════════════════════════
screen cap07_mascara_interactivo():
    modal True

    add "bg_piso7_despertar"

    # ── Pista visual: máscara rota en el serrín ──
    frame:
        xpos 0.42
        ypos 0.55
        xsize 250
        ysize 250
        background Solid("#2e1a1e")

        text "🎭":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.7)

    # ── Zona clicable ──
    button:
        xpos 0.42
        ypos 0.55
        xsize 250
        ysize 250
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa la máscara":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  OBJETO 2 — CAJA DE MÚSICA
# ═══════════════════════════════════════════════════════════════
screen cap07_caja_interactivo():
    modal True

    add "bg_piso7_vestuario"

    # ── Pista visual: caja de música sobre la cómoda ──
    frame:
        xpos 0.5
        ypos 0.5
        xsize 250
        ysize 250
        background Solid("#221a10")

        text "🎵":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.6)

    # ── Zona clicable ──
    button:
        xpos 0.5
        ypos 0.5
        xsize 250
        ysize 250
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa la caja de música":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  LABELS DE EFECTO
# ═══════════════════════════════════════════════════════════════

# ── Al pulsar la máscara ──
label cap07_pulsar_mascara:
    $ marcar_objeto_visto("mascara_rota")
    $ gtn_puertas_pulsadas += 1

    show cap07_mascara at truecenter
    with dissolve

    n "La máscara está partida por la mitad."

    n "Blanca. De porcelana."

    n "Con una sonrisa pintada. Descolorida."

    n "Y en el interior, algo escrito."

    n "Un nombre. Con letra temblorosa."

    n "El nombre de Nao."

    $ aprender_palabra("torre", "mascara_nao")

    nao "..."

    nao "Es mi nombre."

    so "¿Qué?"

    nao "La máscara. Tiene mi nombre dentro."

    so "..."

    so "Eso no puede ser bueno."

    nao "No lo es."

    nao "Porque si mi máscara está aquí..."

    nao "Significa que yo también estoy aquí."

    nao "Como los demás."

    n "Y entonces, la máscara tiembla."

    n "Y por un momento, la sonrisa pintada se mueve."

    n "Y vuelve a quedarse quieta."

    n "Como si hubiera respirado."

    hide cap07_mascara
    with dissolve

    $ desbloquear_pista("torre", "p7_mascara_rota")
    call cap07_nota_carpa

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    return


# ── Al pulsar la caja de música ──
label cap07_pulsar_caja:
    $ marcar_objeto_visto("caja_musica")
    $ gtn_puertas_pulsadas += 1

    show cap07_caja_musica at truecenter
    with dissolve

    n "La caja de música está cerrada. Pero tiene la llave puesta."

    n "Y un nombre grabado en la tapa."

    n "El nombre es de Souta."

    $ aprender_palabra("torre", "risa_forzada")

    nao "Souta."

    so "¿Qué?"

    nao "Esta caja."

    nao "Tiene tu nombre."

    so "..."

    so "No la abras."

    nao "¿Por qué?"

    so "Porque si la abres, suena."

    nao "¿Y qué pasa si suena?"

    so "..."

    so "No lo sé."

    so "Pero no quiero saberlo."

    n "Nao retira la mano."

    n "Despacio."

    n "Pero la caja sigue ahí."

    n "Cerrada."

    n "Con el nombre de Souta."

    hide cap07_caja_musica
    with dissolve

    $ desbloquear_pista("torre", "p7_souta_oidos")
    call cap07_nota_caja

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("terror", +5)

    return