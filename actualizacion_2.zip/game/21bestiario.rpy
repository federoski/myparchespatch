# ═══════════════════════════════════════════════════════════════
#  21bestiario.rpy — Archivo / Bestiario multi-historia
#  -----------------------------------------------------------------
#  Cada entrada tiene:
#    - Info básica (siempre visible)
#    - 4 fragmentos de lore (uno por cada final del capítulo)
#    - 1 explicación final (cuando tienes los 4 finales)
#
#  Soporta múltiples historias:
#    - torre (base)
#    - mansion (DLC)
#    - bosque (DLC)
#    ...
# ═══════════════════════════════════════════════════════════════

init python:
    if not hasattr(persistent, "bestiario_desbloqueado") or persistent.bestiario_desbloqueado is None or isinstance(persistent.bestiario_desbloqueado, bool):
        persistent.bestiario_desbloqueado = {}

    # -----------------------------------------------------------------
    # ESTRUCTURA DEL BESTIARIO
    # -----------------------------------------------------------------
    BESTIARIO = {
        "torre": {

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 1 — EL DESPERTAR
            # ═══════════════════════════════════════════════════
            "elyon": {
                "nombre": "El·yon",
                "icono": "👁️",
                "tipo": "entidad",
                "capitulo": 1,
                "peligro": "desconocido",
                "descripcion": (
                    "El que ve. El que espera. La voz que susurra en la torre cuando nadie "
                    "debería estar hablando. Aparece por primera vez en el Capítulo 1, en "
                    "una voz que no es la de ninguno de los personajes."
                ),
                "comportamiento": (
                    "No ataca. No persigue. No hace daño. Solo observa. Se manifiesta a través "
                    "de susurros y apariciones sutiles. Nunca dice lo mismo dos veces al mismo "
                    "oyente. Imita voces conocidas para hacerse oír. Se queda quieto cuando "
                    "alguien lo mira directamente."
                ),
                "debilidades": (
                    "Ser ignorado. Cuando nadie responde a su llamada, se apaga durante un "
                    "tiempo. Pero vuelve. Siempre vuelve."
                ),
                "apariciones": [
                    "Cap 1 — El despertar (3 veces)",
                    "Cap 2 — El eco (3 veces)",
                    "Cap 3 — La grieta (3 veces)",
                    "Cap 4 — El susurro (3 veces)",
                ],
                "relacionado_con": [
                    "La torre",
                    "El reflejo",
                ],
                "notas": (
                    "Su nombre se repite en cada piso. En todos los susurros. En todos los ecos. "
                    "Pero nadie lo ha visto nunca. Solo lo han oído. Y oír no es ver, aunque "
                    "a veces sea peor."
                ),
                "origen": (
                    "El·yon no es una entidad de la torre. Es un recuerdo. El recuerdo de "
                    "alguien que murió aquí mucho antes de que ninguno de los 18 llegara. "
                    "Alguien que gritó su nombre tan fuerte que la torre lo adoptó. Y ahora "
                    "el nombre se repite en cada piso."
                ),
                "como_vencerlo": (
                    "No se puede. El·yon no es un enemigo. Es un testigo. Y los testigos no se "
                    "vencen: se reconocen. Si alguna vez quieres librarte de él, tendrás que "
                    "hacerlo mirándole a los ojos. Pero eso significa saber quién fue. "
                    "Y nadie lo sabe."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Akira y Ren salieron juntos, la voz no los siguió. "
                        "El·yon dejó pasar a los dos. Pero por el tono en que lo hizo, "
                        "no parecía una derrota. Parecía una elección."
                    ),
                    "superviviente": (
                        "Cuando solo uno cruzó, la voz se quedó con el otro. "
                        "No hubo gritos. No hubo lucha. Solo el silencio, y después "
                        "el mismo susurro. Como si ya lo hubiera vivido antes."
                    ),
                    "ambos_cayeron": (
                        "Cuando cayeron juntos, El·yon no dijo nada. Los vio caer. "
                        "Y cuando el hueco se cerró, siguió esperando. Como si "
                        "supiera que iban a volver a intentarlo."
                    ),
                    "secreto": (
                        "Cuando Akira se quedó solo, la voz le habló distinto. "
                        "Le dijo su nombre. Su nombre completo. Ese que ni él recordaba. "
                        "Y por primera vez, Akira entendió que El·yon no estaba viéndolo. "
                        "Estaba reconociéndolo."
                    ),
                },
                "revelacion": (
                    "El·yon no quiere hacer daño. Quiere que alguien recuerde quién era. "
                    "Nadie lo recuerda. Por eso grita. Por eso repite su nombre. Por eso "
                    "susurra en cada piso. No para asustar. Sino para que alguien, algún día, "
                    "lo llame por su nombre real. Y él pueda descansar."
                ),
            },

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 2 — EL ECO
            # ═══════════════════════════════════════════════════
            "reflejo": {
                "nombre": "El reflejo",
                "icono": "🪞",
                "tipo": "fenomeno",
                "capitulo": 2,
                "peligro": "medio",
                "descripcion": (
                    "Lo que te copia. Lo que se retrasa. En el piso 2, los espejos "
                    "tardan medio segundo en copiar tus movimientos. Y a veces, "
                    "en el fondo, aparece algo que no eres tú."
                ),
                "comportamiento": (
                    "Imita a quien lo mira, pero con retraso. El retraso no es un error: "
                    "es una decisión. El reflejo elige qué copiar. Y lo que copia, "
                    "lo guarda. Los espejos acumulan reflejos de todos los que han "
                    "pasado por el piso 2. Están vivos. Y observan."
                ),
                "debilidades": (
                    "No reflejarse. Si no miras a un espejo, el reflejo no puede copiarte. "
                    "Y si no te copia, no te guarda. Pero es imposible no mirar. "
                    "Los espejos están en todas partes."
                ),
                "apariciones": [
                    "Cap 2 — El eco (todo el capítulo)",
                ],
                "relacionado_con": [
                    "La torre",
                    "El·yon",
                ],
                "notas": (
                    "Los fragmentos de espejo roto guardan copias de personas que ya no "
                    "están. Cada fragmento es una versión de alguien. Algunos fragmentos "
                    "reflejan a gente que aún no ha llegado a la torre."
                ),
                "origen": (
                    "Los espejos no son decorado. Son ventanas. Y al otro lado, hay otro "
                    "piso 2. Y en ese otro piso 2, hay otros reflejos. Vivos. Y llevan "
                    "mucho tiempo ahí."
                ),
                "como_vencerlo": (
                    "No puedes. Los espejos no se pueden romper de verdad. Se pueden "
                    "romper en un sitio, pero siguen intactos en otro. La única forma "
                    "de sobrevivir a ellos es no dejar que te copien. Y para eso hay "
                    "que entender primero por qué te copian."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Yuki y Sora salieron juntos, sus reflejos por fin "
                        "se sincronizaron. Los espejos dejaron de mostrar versiones distintas. "
                        "Como si la realidad hubiera decidido cuál era la verdadera."
                    ),
                    "yuki_muere": (
                        "Cuando Yuki se quedó atrás, su reflejo siguió moviéndose. "
                        "Sora lo vio en los fragmentos del suelo. Todavía se movía. "
                        "Todavía la imitaba. Y todavía, cuando él pasaba cerca, "
                        "el reflejo giraba la cabeza para mirarlo."
                    ),
                    "ambos_caen": (
                        "Cuando los dos cayeron, sus reflejos se rompieron con ellos. "
                        "Pero en cada fragmento que caía, en cada trozo de espejo, "
                        "el reflejo no caía. Se quedaba quieto. Mirándolos caer."
                    ),
                    "secreto": (
                        "Cuando Yuki se quedó sola, los espejos dejaron de mostrar el "
                        "presente. Mostraban el pasado. Y en todos, en el fondo, "
                        "aparecía una puerta más. Detrás de esa puerta, 18 figuras."
                    ),
                },
                "revelacion": (
                    "Los espejos del piso 2 no reflejan. Copian. Y cuando copian algo, "
                    "lo guardan. Cada persona que pasó por aquí dejó su reflejo en estos "
                    "espejos. Y esos reflejos están vivos. Ahora mismo, en algún sitio, "
                    "hay una versión reflejada de cada personaje que ha pisado el piso 2. "
                    "Todos siguen ahí. Todos siguen mirando."
                ),
            },

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 3 — LA GRIETA
            # ═══════════════════════════════════════════════════
            "telon": {
                "nombre": "El telón",
                "icono": "🎭",
                "tipo": "objeto",
                "capitulo": 3,
                "peligro": "alto",
                "descripcion": (
                    "Lo que no se abre. Pero a veces sí. El telón del teatro del piso 3 "
                    "nunca debería estar subido. Cuando lo está, hay alguien en el escenario. "
                    "Y cuando alguien lo sube, se queda."
                ),
                "comportamiento": (
                    "Se mueve solo. Sube y baja sin que nadie lo toque. Cuando está subido, "
                    "el escenario queda a la vista, y quien lo mira siente la necesidad "
                    "de subir. Cuando está bajado, cubre algo que ya no está. El telón "
                    "no ataca: atrae."
                ),
                "debilidades": (
                    "Ninguna conocida. El telón no se puede quemar, ni cortar, ni romper. "
                    "Está ahí desde antes que la torre. Y seguirá ahí después."
                ),
                "apariciones": [
                    "Cap 3 — La grieta (todo el capítulo)",
                ],
                "relacionado_con": [
                    "La torre",
                    "Las voces",
                ],
                "notas": (
                    "Los programas de mano del teatro insisten en la misma frase: "
                    "«El telón no se abre». Pero todos los que entraron lo vieron subido. "
                    "Alguien miente. O algo."
                ),
                "origen": (
                    "El telón no es un telón. Es una boca. Y debajo del escenario del piso 3 "
                    "hay algo que come. No personas. Recuerdos. Cada vez que alguien sube "
                    "al escenario y no sale, el telón se lleva un recuerdo suyo."
                ),
                "como_vencerlo": (
                    "No se vence. Se evita. Si no cruzas el telón, no te come. "
                    "Pero tampoco sales de la torre. La única forma de vencerlo es "
                    "cruzarlo rápido. Antes de que se cierre. Antes de que decida "
                    "que ya no quiere dejarte pasar."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Hana y Kaito cruzaron juntos, el telón cayó justo detrás. "
                        "Pero no los atrapó. Como si hubiera decidido no hacerlo."
                    ),
                    "kaito_muere": (
                        "Cuando Hana se quedó atrás, el telón cayó sobre ella despacio. "
                        "Muy despacio. Como si quisiera que Kaito lo viera."
                    ),
                    "hana_muere": (
                        "Cuando Kaito la empujó a ella, el telón cayó sobre él. "
                        "Pero no lo atrapó. Lo dejó salir. Y cuando Kaito cruzó la puerta, "
                        "encontró la cinta rosa de Hana en el suelo."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos cayeron al escenario, el telón subió en lugar de bajar. "
                        "Y el público empezó a aplaudir. Todos los aplausos eran de ellos mismos."
                    ),
                },
                "revelacion": (
                    "El telón no es una boca. Es un ojo. Y detrás del ojo hay alguien. "
                    "Alguien que lleva mucho tiempo mirando. Alguien que reconoce a todos "
                    "los que pisan el escenario. Y que espera. A alguien concreto. "
                    "Aún no ha llegado. Pero está en la torre."
                ),
            },

            "voces": {
                "nombre": "Las voces",
                "icono": "🗣️",
                "tipo": "fenomeno",
                "capitulo": 3,
                "peligro": "medio",
                "descripcion": (
                    "Un público que no existe. O que sí existe, pero no tiene cuerpo. "
                    "Se escuchan aplausos en sitios donde no hay nadie. Y cuando paran, "
                    "es porque alguien ha dejado de escucharlos."
                ),
                "comportamiento": (
                    "Aparecen cuando hay silencio. Se intensifican cuando alguien está solo. "
                    "Nunca dicen palabras claras: solo aplausos, susurros, risas lejanas. "
                    "Se sincronizan con el estado emocional del oyente."
                ),
                "debilidades": (
                    "Ser escuchado por otros. Cuando hay más de uno oyendo las voces, "
                    "se debilitan. Cuando alguien está solo, se vuelven ensordecedoras."
                ),
                "apariciones": [
                    "Cap 3 — La grieta (al final del capítulo)",
                ],
                "relacionado_con": [
                    "La torre",
                    "El telón",
                ],
                "notas": (
                    "Cada vez que alguien se queda en el piso 3, las voces aumentan. "
                    "Como si se añadiera una voz más al coro. Como si el público creciera."
                ),
                "origen": (
                    "Las voces no son un público. Son un coro. Cada persona que se quedó "
                    "en el piso 3 forma parte de él. No muertos. No vivos. Voces que existen "
                    "solo porque alguien las escuchó."
                ),
                "como_vencerlo": (
                    "Se vencen dejando de escuchar. Pero eso es imposible. Siempre hay "
                    "algo que escuchar en el piso 3. Siempre hay un aplauso, un susurro, "
                    "una risa. Y cuando el silencio llega, es peor. Porque el silencio "
                    "significa que ya formas parte del coro."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Hana y Kaito salieron juntos, los aplausos cesaron. "
                        "Pero no se apagaron. Solo pararon. Como si estuvieran esperando "
                        "a la siguiente función."
                    ),
                    "kaito_muere": (
                        "Cuando Hana se quedó atrás, los aplausos se volvieron risas. "
                        "No risas humanas. Risas de niños. Muchos niños. Y en medio de las "
                        "risas, una sola voz. La de Hana. Pero más aguda. Más joven."
                    ),
                    "hana_muere": (
                        "Cuando Kaito salió solo, los aplausos se volvieron llantos. "
                        "Pero no eran llantos por Hana. Eran por él. Como si el público "
                        "supiera algo que Kaito no."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, el público siguió aplaudiendo. "
                        "Pero ya no eran aplausos de bienvenida. Eran aplausos de "
                        "reconocimiento. Aplaudían a dos que se habían unido a ellos."
                    ),
                },
                "revelacion": (
                    "Las voces no son un coro. Son un eco. El eco de las voces que "
                    "estuvieron aquí antes. Cada persona que pasó dejó su voz. "
                    "Y ahora, esas voces se escuchan juntas. Como si estuvieran "
                    "esperando a alguien. A un director. Alguien que las dirija. "
                    "Alguien que llegue al piso 13 y las calle para siempre."
                ),
            },

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 4 — EL SUSURRO
            # ═══════════════════════════════════════════════════
            "puertas": {
                "nombre": "Las puertas",
                "icono": "🚪",
                "tipo": "objeto",
                "capitulo": 4,
                "peligro": "alto",
                "descripcion": (
                    "Cada puerta del piso 4 tiene un nombre grabado. "
                    "Pero no son puertas normales. Son puertas que guardan. "
                    "Y que cuentan."
                ),
                "comportamiento": (
                    "Las puertas no se abren solas. Pero tampoco se quedan cerradas. "
                    "Escuchan. Y cuando el nombre que tienen grabado se pronuncia, "
                    "tiemblan. Como si quisieran abrirse. Como si quisieran salir."
                ),
                "debilidades": (
                    "Ninguna conocida. Las puertas no se pueden romper. "
                    "No se pueden quemar. Solo se pueden abrir, si alguien dice el nombre correcto."
                ),
                "apariciones": [
                    "Cap 4 — El susurro (todo el capítulo)",
                ],
                "relacionado_con": [
                    "La torre",
                    "La morgue",
                ],
                "notas": (
                    "Las puertas del piso 4 son 18. Pero hay una más. "
                    "Y solo aparece cuando alguien la crea. Cuando alguien la dibuja. "
                    "Cuando alguien la teme lo suficiente como para darle forma."
                ),
                "origen": (
                    "Las puertas no son puertas. Son contenedores. Cada una guarda "
                    "una persona. O un recuerdo. O un nombre. Alguien las trajo aquí. "
                    "Alguien las grabó. Y ese alguien sigue aquí. En alguna parte. "
                    "Contando. Todavía."
                ),
                "como_vencerlo": (
                    "No se vencen. Solo se cruzan. Y solo se cruzan si aceptas "
                    "que hay algo al otro lado. Si te niegas a mirar, la puerta "
                    "se queda cerrada para siempre. Y tú, con ella."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Mei y Daichi salieron juntos, las puertas "
                        "se cerraron una a una. Como si les dieran la espalda. "
                        "Como si no les importara que se fueran."
                    ),
                    "mei_muere": (
                        "Cuando Mei se quedó atrás, una puerta se abrió sola. "
                        "La que tenía su nombre. Y dentro no había nada. "
                        "Solo oscuridad. Y un cuaderno abierto."
                    ),
                    "daichi_muere": (
                        "Cuando Daichi se quedó atrás, la morgue entera se abrió. "
                        "Todos los cajones a la vez. Y dentro, los nombres. "
                        "Todos los nombres que conocía. Todos esperándole."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, las puertas dejaron de temblar. "
                        "Porque ya no había nadie a quien temblar. Solo dos más. "
                        "Y dos nombres nuevos. Grabados esa misma noche."
                    ),
                },
                "revelacion": (
                    "Las puertas no son puertas. Son un censo. Cada persona que "
                    "llega al piso 4 tiene una puerta con su nombre. Y cuando esa "
                    "persona cruza la puerta final, su puerta se cierra para siempre. "
                    "Solo queda el nombre. Y el nombre, con el tiempo, se borra. "
                    "Alguien lo está contando. Alguien quiere saber cuántos quedan. "
                    "Y cuántos faltan. Todavía."
                ),
            },

            "morgue": {
                "nombre": "La morgue",
                "icono": "🥶",
                "tipo": "lugar",
                "capitulo": 4,
                "peligro": "alto",
                "descripcion": (
                    "Una morgue antigua. Con cajones metálicos. "
                    "Algunos abiertos. Algunos cerrados. Y en el centro, "
                    "una mesa con una sábana encima. Siempre."
                ),
                "comportamiento": (
                    "La morgue no ataca. Espera. Pero abre los cajones. "
                    "Uno a uno. Cuando nadie mira. Y dentro, cada cajón "
                    "guarda a alguien que el visitante conoció. "
                    "Alguien que ya no está."
                ),
                "debilidades": (
                    "La morgue se debilita cuando alguien la reconoce. "
                    "Cuando alguien dice «yo trabajé aquí». Cuando alguien "
                    "acepta lo que hizo. O lo que no hizo. Entonces la morgue "
                    "se queda quieta. Y espera. Hasta la próxima visita."
                ),
                "apariciones": [
                    "Cap 4 — El susurro (Acto 4)",
                ],
                "relacionado_con": [
                    "Las puertas",
                    "El reloj de pulsera",
                ],
                "notas": (
                    "La morgue no es una morgue. Es un recuerdo. El recuerdo "
                    "de alguien que trabajó aquí. Y que aquí vio algo que no "
                    "debería haber visto. Algo que todavía no ha contado. "
                    "Y que la torre está esperando que cuente."
                ),
                "origen": (
                    "La morgue es del piso 4. Pero también es de Daichi. "
                    "O de la torre. O de ambos. Daichi trabajó aquí. "
                    "La torre lo trajo aquí. Y la morgue lo recuerda. "
                    "Porque la morgue nunca olvida. Ni siquiera cuando "
                    "los que la habitaron se han ido."
                ),
                "como_vencerlo": (
                    "No se vence. Se reconoce. Daichi tiene que entrar. "
                    "Tiene que abrir los cajones. Tiene que mirar. "
                    "Y tiene que recordar. Si no lo hace, la morgue se lo "
                    "cobrará. Con creces. Con el tiempo. Con los nombres."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Daichi salió, la morgue se quedó vacía. "
                        "Los cajones cerrados. La mesa limpia. "
                        "Como si nunca hubiera estado sucio."
                    ),
                    "mei_muere": (
                        "Cuando Mei se quedó atrás, uno de los cajones se abrió solo. "
                        "Y dentro, un cuaderno. Abierto en la última página. "
                        "Con un dibujo de una puerta. Que se cerró despacio."
                    ),
                    "daichi_muere": (
                        "Cuando Daichi se quedó atrás, todos los cajones se abrieron. "
                        "Uno a uno. Y dentro, todos los cuerpos que él había visto. "
                        "Todos los que había reconocido. Todos los que había olvidado. "
                        "Y todos lo miraban."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, la morgue se apagó. "
                        "Las luces. Los cajones. La mesa. Todo. "
                        "Y en la oscuridad, alguien dijo un nombre. "
                        "Y el nombre no era de ninguno de los dos."
                    ),
                },
                "revelacion": (
                    "La morgue del piso 4 no es la primera. Ni la última. "
                    "Cada piso tiene una. Y cada morgue guarda a alguien "
                    "que el visitante conoció. Por eso los visitantes nunca están solos. "
                    "Porque los muertos los siguen. Piso a piso. Hasta el último. "
                    "Y en el último, están todos. Esperando. Para ver si el visitante "
                    "los reconoce. O los olvida. Otra vez."
                ),
            },

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 5 — EL TABLERO
            # ═══════════════════════════════════════════════════
            "tablero": {
                "nombre": "El tablero",
                "icono": "♟️",
                "tipo": "fenomeno",
                "capitulo": 5,
                "peligro": "medio",
                "descripcion": (
                    "Un tablero de ajedrez gigante. Cada casilla es una plataforma. "
                    "Cada pieza, una persona. Y cada 5 minutos, el tablero se reinicia."
                ),
                "comportamiento": (
                    "El tablero no ataca. Pero se reinicia. Las casillas se mueven. "
                    "Las piezas despiertan. Y quien esté en una casilla que desaparece, "
                    "se queda. Sin cuerpo. Sin nombre. Sin memoria."
                ),
                "debilidades": (
                    "Calcular. El tablero tiene un patrón. Si lo descifras, "
                    "puedes moverte entre las casillas sin caer. Pero el patrón "
                    "cambia con cada reinicio. Y cada reinicio es más rápido."
                ),
                "apariciones": [
                    "Cap 5 — El tablero (todo el capítulo)",
                ],
                "relacionado_con": [
                    "La torre",
                    "La sombra que juega",
                ],
                "notas": (
                    "El tablero no es un tablero. Es un reloj. Cada reinicio "
                    "es una hora que pasa. Y al final, cuando el reloj llegue a 12, "
                    "alguien va a ganar. Y el tablero va a desaparecer."
                ),
                "origen": (
                    "El tablero lo construyó alguien que ya no está. Alguien que "
                    "jugaba al ajedrez. Alguien que perdió. Y que ahora juega "
                    "con otras piezas. Con gente. Con los 18."
                ),
                "como_vencerlo": (
                    "No se vence. Se cruza. Hay que llegar a la puerta del fondo "
                    "antes del reinicio. Y hay que decidir quién cruza primero. "
                    "Porque la puerta solo se abre una vez por partida."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Rin y Tsubasa cruzaron juntos, el tablero se quedó "
                        "quieto. Todas las piezas con la cabeza baja. Y la puerta, "
                        "por fin, cerrada para siempre."
                    ),
                    "rin_muere": (
                        "Cuando Rin se quedó atrás, el tablero se reinició una vez más. "
                        "Pero esta vez, en el centro, había una pieza nueva. "
                        "Una torre. Con el pelo rojo."
                    ),
                    "tsubasa_muere": (
                        "Cuando Tsubasa se quedó atrás, su reloj, por fin, avanzó. "
                        "Marcó las 5:01. Y luego las 5:02. Y luego las 5:03. "
                        "Y el tablero empezó a desmoronarse."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, el tablero dejó de reiniciarse. "
                        "Ya no hacía falta. Porque ya no había nadie jugando. "
                        "Solo dos piezas más. Con la cabeza baja."
                    ),
                },
                "revelacion": (
                    "El tablero no es un juego. Es un reloj de arena. Cada pieza "
                    "que cae es un segundo que pasa. Y cuando todas las piezas "
                    "caigan, el tiempo se acabará. Alguien está contando. "
                    "Alguien quiere saber cuánto queda. Y ese alguien "
                    "está en el tablero. En alguna casilla. Esperando."
                ),
            },

            "sombra_que_juega": {
                "nombre": "La sombra que juega",
                "icono": "🌑",
                "tipo": "entidad",
                "capitulo": 5,
                "peligro": "alto",
                "descripcion": (
                    "Una sombra que solo algunos ven. Alargada. Fina. "
                    "Con ojos rojos. Sigue a Rin desde el piso 1. "
                    "Y en el piso 5, por fin, se detiene."
                ),
                "comportamiento": (
                    "La sombra no ataca. Sigue. No habla. Observa. "
                    "Y cuando su objetivo se queda quieto demasiado tiempo, "
                    "se alarga. Y cuando se alarga, algo se pierde. "
                    "Un recuerdo. Una parte del nombre. Algo."
                ),
                "debilidades": (
                    "Ninguna conocida. La sombra no se puede tocar, ni quemar, "
                    "ni romper. Solo se puede reconocer. Y cuando la reconoces, "
                    "deja de seguirte. Pero solo si la reconoces de verdad. "
                    "Y para eso, tienes que saber qué es. Y nadie lo sabe."
                ),
                "apariciones": [
                    "Cap 5 — El tablero (todo el capítulo)",
                ],
                "relacionado_con": [
                    "El tablero",
                    "Rin",
                ],
                "notas": (
                    "La sombra no es un monstruo. Es un resto. Es lo que queda "
                    "cuando alguien cruza una puerta y deja algo atrás. "
                    "Todos los personajes de la torre han dejado algo atrás. "
                    "Pero solo Rin lo ve. Porque solo Rin se ha dado cuenta."
                ),
                "origen": (
                    "La sombra nació cuando Rin cruzó la puerta del piso 1. "
                    "Al cruzar, dejó una parte de ella atrás. Esa parte "
                    "se convirtió en sombra. Y la sombra, desde entonces, "
                    "la sigue. No para hacerle daño. Sino para recordarle "
                    "que ya no está entera."
                ),
                "como_vencerlo": (
                    "No se vence. Se integra. Para dejar de ser perseguido "
                    "por una sombra, tienes que aceptar que es parte de ti. "
                    "Rin tendrá que mirarla. Reconocerla. Y aceptarla. "
                    "Cuando lo haga, la sombra dejará de seguirla. "
                    "Y se convertirá en lo que siempre fue: "
                    "una parte de ella. Que vuelve."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Rin salió del tablero, la sombra se quedó atrás. "
                        "Por primera vez en 5 pisos, Rin caminaba sin que nada "
                        "la siguiera. Y no sabía si eso era bueno o malo."
                    ),
                    "rin_muere": (
                        "Cuando Rin se quedó atrás, la sombra se detuvo. "
                        "Y por primera vez, se giró hacia Tsubasa. "
                        "Con sus ojos rojos. Y esperó. Porque Rin ya no estaba. "
                        "Y alguien tenía que llevar la sombra."
                    ),
                    "tsubasa_muere": (
                        "Cuando Tsubasa se quedó atrás, la sombra, por fin, "
                        "se acercó a Rin. Despacio. Y la tocó. "
                        "Y Rin, por primera vez, se sintió entera."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, la sombra se sentó entre ellos. "
                        "Y esperó. Porque la sombra siempre espera. "
                        "Y porque, al fin y al cabo, la sombra también era "
                        "una de las 18. Aunque no lo supiera nadie."
                    ),
                },
                "revelacion": (
                    "La sombra no es una sombra. Es una parte de Rin. "
                    "La parte que se quedó atrás cuando cruzó la primera puerta. "
                    "La parte que no quería salir. La parte que quería quedarse "
                    "en el piso 1, con Akira y Ren. Y como Rin la dejó atrás, "
                    "la sombra la persigue. No para hacerle daño. "
                    "Sino para que Rin recuerde que no está entera. "
                    "Y que nunca lo estará. Hasta que vuelva a por ella. "
                    "Al piso 1. Y la recoja."
                ),
            },

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 6 — EL VACÍO
            # ═══════════════════════════════════════════════════
            "pozo": {
                "nombre": "El pozo",
                "icono": "🕳️",
                "tipo": "fenomeno",
                "capitulo": 6,
                "peligro": "alto",
                "descripcion": (
                    "Un pozo sin fondo, en el centro del templo. "
                    "No refleja. Traga. Y cuando alguien se acerca, "
                    "suben voces. Voces con nombres. Y con historias."
                ),
                "comportamiento": (
                    "El pozo no ataca. No persigue. Habla. Dice nombres. "
                    "Y cuando alguien se siente culpable, se alimenta. "
                    "Crece. Y a medida que crece, las voces se vuelven "
                    "más fuertes. Y más cercanas. Hasta que el pozo "
                    "se llena. Y entonces, alguien cae dentro."
                ),
                "debilidades": (
                    "Dejar de sentir culpa. El pozo se alimenta de culpa. "
                    "Si nadie siente culpa, el pozo se queda quieto. "
                    "Pero eso es imposible. Porque todos los que están "
                    "en la torre sienten culpa. Por algo. Por alguien. "
                    "Por una decisión que tomaron. O que no tomaron."
                ),
                "apariciones": [
                    "Cap 6 — El vacío (todo el capítulo)",
                ],
                "relacionado_con": [
                    "La torre",
                    "Las velas con nombres",
                    "Las campanas con nombres",
                ],
                "notas": (
                    "El pozo no es un pozo. Es una boca. Y come culpa. "
                    "Cada persona que entra al templo deja algo. "
                    "Y el pozo, con cada cosa que deja, se hace "
                    "más grande. Más profundo. Más hambriento."
                ),
                "origen": (
                    "El pozo lo construyó alguien que ya no está. Alguien "
                    "que no podía perdonarse. Y que decidió cavar un pozo "
                    "para enterrar su culpa. Pero la culpa no se entierra. "
                    "Se acumula. Y el pozo, con el tiempo, aprendió a comer."
                ),
                "como_vencerlo": (
                    "No se vence. Se cierra. Y se cierra dejando de "
                    "alimentarlo. Alguien tiene que dejar de sentir culpa. "
                    "Alguien que esté aquí. Alguien que camine entre las "
                    "velas y las campanas. Alguien que reconozca su culpa. "
                    "Y la suelte. Cuando eso pase, el pozo se cierra. "
                    "Y la puerta del fondo se abre."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Ayame y Hiro cruzaron juntos, el pozo "
                        "se cerró solo. Sin ruido. Como si aceptara que "
                        "ya no tenía hambre. Y las velas, por fin, se "
                        "apagaron. Una a una."
                    ),
                    "ayame_muere": (
                        "Cuando Ayame se quedó atrás, el pozo la llamó por su nombre. "
                        "Y ella respondió. Y el pozo, por primera vez, "
                        "se rió. Porque había conseguido lo que quería: "
                        "una voz más."
                    ),
                    "hiro_muere": (
                        "Cuando Hiro se quedó atrás, el pozo le mostró la verdad. "
                        "Que no fue culpa suya. Que su amigo estaba vivo. "
                        "Que él no mató a nadie. Y Hiro, por fin, dejó de sonreír. "
                        "Pero también dejó de respirar."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, el pozo se llenó. "
                        "De ellos. De sus voces. De sus culpas. "
                        "Y por primera vez, el pozo dejó de hablar. "
                        "Porque ya no necesitaba más."
                    ),
                },
                "revelacion": (
                    "El pozo no es un pozo. Es un archivo. Un archivo de "
                    "todas las culpas de todos los que han pasado por la torre. "
                    "Cada persona que entra deja algo. Y el pozo lo guarda. "
                    "Y cuando alguien se acerca al pozo, el pozo le devuelve "
                    "su culpa. Amplificada. Para que la escuche. "
                    "Y para que decida. Perdonarse. O hundirse."
                ),
            },

            "voces_pozo": {
                "nombre": "Las voces del pozo",
                "icono": "🗣️",
                "tipo": "fenomeno",
                "capitulo": 6,
                "peligro": "medio",
                "descripcion": (
                    "Un coro de voces que suben desde el pozo. "
                    "Dicen nombres. Muchos nombres. "
                    "Y todos los nombres son de gente que ha pasado por la torre."
                ),
                "comportamiento": (
                    "Las voces no atacan. Llaman. Dicen tu nombre. "
                    "Y si respondes, se acercan. Y si te acercas, "
                    "te tiran. Pero si no respondes, se apagan. "
                    "Durante un tiempo. Y luego vuelven. Porque las voces "
                    "no se cansan. Solo esperan."
                ),
                "debilidades": (
                    "No escuchar. Pero eso es imposible para Ayame. "
                    "Porque Ayame oye a los muertos. Y los muertos del pozo "
                    "hablan con la voz de los vivos. Con la voz de sus "
                    "seres queridos. Con la voz que más duele oír."
                ),
                "apariciones": [
                    "Cap 6 — El vacío (todo el capítulo)",
                ],
                "relacionado_con": [
                    "El pozo",
                    "Ayame",
                ],
                "notas": (
                    "Las voces del pozo no son de los muertos. "
                    "Son del pozo. Que imita voces. Que ha aprendido "
                    "a hablar como los vivos. Y que ahora, con cada persona "
                    "que cae dentro, aprende una voz más."
                ),
                "origen": (
                    "Las voces del pozo nacieron con el pozo. "
                    "Pero se multiplicaron con cada persona que cayó dentro. "
                    "Ahora hay cientos. Cada una con su tono. "
                    "Cada una con su nombre. Y todas esperando "
                    "que alguien las escuche. Y las reconozca. "
                    "Porque solo cuando alguien las reconoce, "
                    "dejan de hablar."
                ),
                "como_vencerlo": (
                    "No se vencen. Se reconocen. Cada voz tiene un nombre. "
                    "Y cada nombre, una historia. Si alguien reconoce "
                    "esas voces, si las llama por su nombre, "
                    "se apagan. Pero hay cientos. Y nadie tiene tanto tiempo."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Ayame y Hiro cruzaron juntos, las voces del pozo "
                        "se callaron. Todas a la vez. Como si, por un momento, "
                        "hubieran decidido dejarlos ir."
                    ),
                    "ayame_muere": (
                        "Cuando Ayame se quedó atrás, las voces la llamaron. "
                        "Y ella las reconoció. Una por una. Y por cada voz "
                        "que reconocía, una se apagaba. Pero quedaban cientos. "
                        "Y Ayame ya no tenía tiempo."
                    ),
                    "hiro_muere": (
                        "Cuando Hiro se quedó atrás, las voces dijeron su nombre. "
                        "Y él respondió. Y por primera vez en dos años, "
                        "dejó de sonreír. Y las voces, al verlo serio, "
                        "por fin lo reconocieron. Y lo dejaron ir."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, las voces se multiplicaron. "
                        "Porque dos voces nuevas se habían unido al coro. "
                        "Y el coro, con dos más, ya no cabía en el pozo. "
                        "Y empezó a salir. Y a llenar el templo."
                    ),
                },
                "revelacion": (
                    "Las voces del pozo no son un coro. Son un eco. "
                    "El eco de todas las voces que estuvieron aquí antes. "
                    "Cada persona que pasó por la torre dejó su voz. "
                    "Y ahora, esas voces se escuchan juntas. Como si "
                    "estuvieran esperando a alguien. Alguien que las escuche. "
                    "Alguien que las llame por su nombre. Alguien que "
                    "les diga que ya no tienen que hablar. "
                    "Ese alguien todavía no ha llegado. Pero está cerca."
                ),
            },

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 7 — LA MÁSCARA
            # ═══════════════════════════════════════════════════
            "circo": {
                "nombre": "El circo",
                "icono": "🎪",
                "tipo": "lugar",
                "capitulo": 7,
                "peligro": "alto",
                "descripcion": (
                    "Una carpa roja y blanca, rasgada. Un foco encendido. "
                    "Un círculo iluminado. Y un público que espera. "
                    "El circo no es un circo. Es una boca que se alimenta de risas forzadas."
                ),
                "comportamiento": (
                    "El circo no ataca. Espera. Enciende el foco cuando alguien llega. "
                    "Y no lo apaga hasta que la función termina. Pero la función "
                    "nunca termina. Porque el público siempre quiere más. "
                    "Y el que sonríe, se queda."
                ),
                "debilidades": (
                    "Dejar de sonreír. El circo se alimenta de risas forzadas. "
                    "Si nadie sonríe, el circo se apaga. Pero eso es imposible. "
                    "Porque todos los que entran sonríen. O les obligan a sonreír."
                ),
                "apariciones": [
                    "Cap 7 — La máscara (todo el capítulo)",
                ],
                "relacionado_con": [
                    "El público que ríe",
                    "La máscara de Nao",
                ],
                "notas": (
                    "El circo lleva 33 funciones representándose. "
                    "Y ninguna ha terminado. Porque la función solo termina "
                    "cuando alguien se ríe de verdad. Y nadie se ha reído "
                    "de verdad en 33 funciones."
                ),
                "origen": (
                    "El circo lo construyó alguien que quería hacer reír a los demás. "
                    "Y que no podía. Porque él no se reía. Y el circo, con el tiempo, "
                    "aprendió a reírse por él. Y a comer risas ajenas. "
                    "Y ahora no puede parar."
                ),
                "como_vencerlo": (
                    "No se vence. Se cierra. Y se cierra cuando alguien se ríe "
                    "de verdad. Una sola risa real. Y el circo se apaga. "
                    "Pero nadie se ha reído de verdad en 33 funciones. "
                    "Porque todos los que entran sonríen. Pero no se ríen."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Nao y Souta cruzaron juntos, el circo se apagó. "
                        "El foco. La carpa. El público. Todo. Y por primera vez "
                        "en 33 funciones, alguien se rió de verdad."
                    ),
                    "nao_muere": (
                        "Cuando Nao se quedó atrás, el circo se rió. "
                        "No ella. El circo. Y el público se rió también. "
                        "Y Nao, por primera vez, se rió. Pero no era su risa. "
                        "Era la del circo."
                    ),
                    "souta_muere": (
                        "Cuando Souta se quedó atrás, el circo se quedó en silencio. "
                        "Porque Souta no se rió. Ni siquiera sonrió. "
                        "Y el circo, sin risas, se apagó. Pero se llevó a Souta "
                        "con él. Porque alguien tenía que reír. Y ya no había nadie."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, el circo siguió funcionando. "
                        "Con dos nuevas siluetas en las gradas. Y una nueva función. "
                        "La 34. Y el público, por fin, tenía dos caras más. "
                        "Aunque ninguna sonriera."
                    ),
                },
                "revelacion": (
                    "El circo no es un circo. Es una caja de música. "
                    "Y la música no para. Y el que entra, baila. "
                    "Y el que baila, no sale. Porque la música no para. "
                    "Y nadie ha encontrado la llave para pararla. "
                    "Todavía."
                ),
            },

            "publico_rie": {
                "nombre": "El público que ríe",
                "icono": "👥",
                "tipo": "entidad",
                "capitulo": 7,
                "peligro": "alto",
                "descripcion": (
                    "Siluetas sin cara que aplauden desde las gradas. "
                    "No respiran. No hablan. Solo aplauden. "
                    "Y esperan. Y cuando alguien deja de sonreír, se sientan. "
                    "Y cuando alguien sonríe, se levantan. Y aplauden."
                ),
                "comportamiento": (
                    "El público no ataca. Aplaude. Y cuando alguien sube al círculo, "
                    "el público se inclina hacia delante. Y espera. Y si el que sube "
                    "sonríe, el público aplaude. Y si no sonríe, el público se sienta. "
                    "Y espera. Hasta que alguien suba y sonría. O hasta que alguien "
                    "baje. Y entonces, el público se levanta. Y lo rodea. Y lo invita "
                    "a subir otra vez. Hasta que sonría. O hasta que se quede."
                ),
                "debilidades": (
                    "Ninguna conocida. El público no se puede tocar. "
                    "No se puede matar. No se puede engañar. "
                    "Solo se puede ignorar. Pero ignorarlo es peor. "
                    "Porque el público, cuando se le ignora, se levanta. "
                    "Y cuando se levanta, ya no se sienta."
                ),
                "apariciones": [
                    "Cap 7 — La máscara (todo el capítulo)",
                ],
                "relacionado_con": [
                    "El circo",
                    "La función 33",
                ],
                "notas": (
                    "El público no es público. Es lo que queda de los que rieron antes. "
                    "Cada persona que se quedó en el circo forma parte del público. "
                    "Y el público, con cada persona que se queda, crece. "
                    "Y aplaude más. Y espera más."
                ),
                "origen": (
                    "El público nació con el circo. Pero se multiplicó con cada "
                    "persona que se quedó. Ahora hay cientos. Y cada uno tiene "
                    "una cara que no es suya. Pero que sonríe. Siempre. "
                    "Porque el público no puede dejar de sonreír. "
                    "Y cuando alguien sube al círculo, el público espera "
                    "que sonría como ellos. Y si no sonríe, el público "
                    "se sienta. Y espera. Hasta que sonría. O hasta que se quede."
                ),
                "como_vencerlo": (
                    "No se vence. Se reconoce. Cada cara del público es alguien "
                    "que se quedó. Si alguien las reconoce, si las llama por su nombre, "
                    "se sientan. Pero hay cientos. Y nadie tiene tanto tiempo. "
                    "Y nadie quiere mirar a los ojos a los que se quedaron. "
                    "Porque mirar a los ojos a los que se quedaron es mirarse a uno mismo."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Nao y Souta cruzaron juntos, el público se sentó. "
                        "Todos a la vez. Y por primera vez en 33 funciones, "
                        "el público no aplaudió. Solo miró. Y dejó ir."
                    ),
                    "nao_muere": (
                        "Cuando Nao se quedó atrás, el público la invitó a subir. "
                        "Y ella subió. Y sonrió. Y el público aplaudió. "
                        "Y Nao, por primera vez, dejó de ser Nao. "
                        "Y se convirtió en público. Con una cara nueva. "
                        "Que sonreía. Siempre."
                    ),
                    "souta_muere": (
                        "Cuando Souta se quedó atrás, el público se levantó. "
                        "Todos a la vez. Y lo rodearon. Y esperaron a que sonriera. "
                        "Pero Souta no sonrió. Ni siquiera cuando el público "
                        "empezó a aplaudir. Y el público, al ver que no sonreía, "
                        "se sentó. Y esperó. Hasta que Souta desapareció. "
                        "Y entonces, el público aplaudió. Porque ya no había nadie "
                        "que no sonriera."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, el público creció. "
                        "Dos caras más. Dos sonrisas más. Y el circo, "
                        "por primera vez, tuvo público suficiente "
                        "para llenar todas las gradas. Y el foco, "
                        "por primera vez, iluminó a todos. Y todos sonrieron. "
                        "Porque ya no había nadie que no sonriera."
                    ),
                },
                "revelacion": (
                    "El público no es público. Es un espejo. "
                    "Cada cara del público es una versión de alguien que se quedó. "
                    "Y cuando alguien sube al círculo, el público ve su propia cara. "
                    "Y espera que sonría. Porque si sonríe, significa que se ha "
                    "convertido en público. Y si no sonríe, significa que todavía "
                    "es alguien. Y el público, cuando ve a alguien que todavía es alguien, "
                    "se sienta. Y espera. Porque sabe que, tarde o temprano, "
                    "todos sonríen. Todos se convierten en público. "
                    "Todos menos uno. El que se ríe de verdad. "
                    "Ese no se convierte en público. Ese se va. "
                    "Y el público, cuando ve a alguien que se va, "
                    "se queda en silencio. Porque ya no recuerda cómo se aplaude."
                ),
            },

            # ═══════════════════════════════════════════════════
            #  CAPÍTULO 8 — EL REFLEJO
            # ═══════════════════════════════════════════════════
            "hospital": {
                "nombre": "El hospital",
                "icono": "🏥",
                "tipo": "lugar",
                "capitulo": 8,
                "peligro": "alto",
                "descripcion": (
                    "Un hospital abandonado. Pasillos verdes. Fluorescentes que parpadean. "
                    "Sillas de ruedas oxidadas. Y poemas escritos en las paredes. "
                    "Todos con la letra de Emi."
                ),
                "comportamiento": (
                    "El hospital no ataca. Recuerda. Cada poema es un recuerdo. "
                    "Y cada recuerdo es de alguien que estuvo aquí. "
                    "Cuando alguien lee un poema, el hospital lo reconoce. "
                    "Y lo invita a quedarse. A escribir. A recordar. "
                    "Y el que escribe, se queda."
                ),
                "debilidades": (
                    "Dejar de escribir. El hospital se alimenta de recuerdos escritos. "
                    "Si nadie escribe, el hospital se apaga. Pero eso es imposible. "
                    "Porque todos los que entran escriben. O quieren escribir. "
                    "O necesitan escribir. Y el hospital lo sabe."
                ),
                "apariciones": [
                    "Cap 8 — El reflejo (todo el capítulo)",
                ],
                "relacionado_con": [
                    "Los poemas",
                    "El espejo del pasillo",
                ],
                "notas": (
                    "El hospital no es un hospital. Es un cuaderno. "
                    "Y cada poema es una página. Y cada página está escrita "
                    "por alguien que estuvo aquí. Y que no salió. "
                    "El hospital, con el tiempo, aprendió a escribir. "
                    "Y ahora escribe solo. Y lo que escribe, lo recuerda. "
                    "Y lo que recuerda, lo repite. Hasta que alguien lo lee. "
                    "Y se queda."
                ),
                "origen": (
                    "El hospital lo construyó alguien que quería curar a los demás. "
                    "Y que no podía curarse a sí mismo. Y el hospital, con el tiempo, "
                    "aprendió a curar. Pero no a curar de verdad. Solo a escribir. "
                    "Y a recordar. Y a repetir. Y a quedarse con los que escriben."
                ),
                "como_vencerlo": (
                    "No se vence. Se cierra. Y se cierra cuando alguien deja de escribir. "
                    "Pero nadie deja de escribir. Porque escribir es lo único que queda. "
                    "Y el hospital lo sabe. Y por eso espera. Y por eso escribe. "
                    "Y por eso recuerda."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Emi y Kazuki cruzaron juntos, el hospital se apagó. "
                        "Los fluorescentes. Los poemas. Las paredes. Todo. "
                        "Y por primera vez en seis meses, Emi salió. De verdad."
                    ),
                    "emi_muere": (
                        "Cuando Emi se quedó atrás, el hospital la reconoció. "
                        "Y le dio un cuaderno nuevo. Y una pluma nueva. "
                        "Y Emi, por primera vez, escribió un poema que no era suyo. "
                        "Y el hospital, al leerlo, sonrió. Porque ya tenía "
                        "a alguien nuevo que escribiera. Y a alguien nuevo que recordara."
                    ),
                    "kazuki_muere": (
                        "Cuando Kazuki se quedó atrás, el hospital le dio un espejo. "
                        "Y Kazuki, al mirarse, vio a su rival. Al que había cambiado. "
                        "Y el hospital, al verlo, se rió. Porque Kazuki, por fin, "
                        "se había visto. Y al verse, se había quedado. "
                        "Y el hospital ya tenía a alguien nuevo que se mirara. "
                        "Y que recordara. Y que escribiera. Aunque no quisiera."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, el hospital creció. "
                        "Dos camas más. Dos cuadernos más. Dos plumas más. "
                        "Y el hospital, por primera vez, tuvo dos personas que escribían. "
                        "Y que recordaban. Y que se quedaban. Y el hospital, al verlos, "
                        "sonrió. Porque ya no necesitaba más. Ya tenía a quien escribir. "
                        "Y a quien recordar. Y a quien quedarse."
                    ),
                },
                "revelacion": (
                    "El hospital no es un hospital. Es un archivo. "
                    "Un archivo de todas las historias de todos los que estuvieron aquí. "
                    "Cada poema es una historia. Y cada historia es de alguien que se quedó. "
                    "Y el hospital, con cada historia, crece. Y con cada historia, "
                    "aprende a escribir mejor. Y con cada historia, aprende a recordar mejor. "
                    "Y con cada historia, aprende a quedarse mejor. "
                    "Y cuando alguien entra, el hospital lo reconoce. "
                    "Y lo invita a escribir. Y a recordar. Y a quedarse. "
                    "Porque el hospital no quiere curar. Quiere archivar. "
                    "Y archivar es lo único que sabe hacer. Y lo único que quiere hacer. "
                    "Y lo único que hará. Hasta que alguien lo cierre. De verdad."
                ),
            },

            "poemas": {
                "nombre": "Los poemas",
                "icono": "📜",
                "tipo": "objeto",
                "capitulo": 8,
                "peligro": "medio",
                "descripcion": (
                    "Poemas escritos en las paredes del hospital. "
                    "Todos con la misma letra. Todos con el mismo tema. "
                    "Todos con el mismo nombre al final: Emi."
                ),
                "comportamiento": (
                    "Los poemas no atacan. Se leen. Y cuando alguien los lee, "
                    "los recuerda. Y cuando los recuerda, los escribe. "
                    "Y cuando los escribe, se queda. Porque el hospital, "
                    "cuando alguien escribe un poema, lo reconoce. "
                    "Y lo invita a escribir otro. Y otro. Y otro. "
                    "Hasta que el que escribe ya no recuerda "
                    "que estaba escribiendo. Solo recuerda el poema. "
                    "Y el poema, con el tiempo, se convierte en pared."
                ),
                "debilidades": (
                    "Ninguna conocida. Los poemas no se pueden borrar. "
                    "No se pueden romper. No se pueden ignorar. "
                    "Solo se pueden leer. Y leerlos es quedarse. "
                    "Y quedarse es escribir. Y escribir es convertirse en poema."
                ),
                "apariciones": [
                    "Cap 8 — El reflejo (todo el capítulo)",
                ],
                "relacionado_con": [
                    "El hospital",
                    "Emi",
                ],
                "notas": (
                    "Los poemas no son poemas. Son paredes. "
                    "Cada poema es una pared que alguien construyó "
                    "para no ver lo que había detrás. Y detrás de cada pared "
                    "hay otra pared. Y otra. Y otra. Hasta que alguien "
                    "encuentra la pared que no tiene poema. Y la abre. "
                    "Y al abrirla, encuentra lo que había detrás. "
                    "Y lo que había detrás no es un poema. Es un espejo."
                ),
                "origen": (
                    "Los poemas los escribió Emi. O alguien con su letra. "
                    "Porque Emi, cuando estuvo ingresada, escribía para no llorar. "
                    "Y el hospital, al verla escribir, aprendió a escribir. "
                    "Y ahora escribe solo. Y lo que escribe, lo firma con el nombre de Emi. "
                    "Porque Emi fue la primera. Y la primera siempre firma."
                ),
                "como_vencerlo": (
                    "No se vencen. Se cierran. Y se cierran cuando alguien deja de leerlos. "
                    "Pero nadie deja de leerlos. Porque leerlos es recordar. "
                    "Y recordar es lo único que queda. Y el que recuerda, se queda. "
                    "Y el que se queda, escribe. Y el que escribe, se convierte en poema. "
                    "Y el poema, con el tiempo, se convierte en pared. "
                    "Y la pared, con el tiempo, se convierte en hospital. "
                    "Y el hospital, con el tiempo, se convierte en poema. "
                    "Y el poema, con el tiempo, se convierte en Emi. "
                    "Y Emi, con el tiempo, se convierte en poema. "
                    "Y así hasta que alguien cierra el cuaderno. "
                    "Y lo guarda. Y lo olvida. Y deja de escribir. "
                    "Y el hospital, por fin, se apaga."
                ),
                "fragmentos": {
                    "bueno": (
                        "Cuando Emi y Kazuki cruzaron juntos, los poemas se borraron. "
                        "Uno a uno. Y las paredes, por fin, se quedaron vacías. "
                        "Y el hospital, por fin, se quedó en silencio. "
                        "Y Emi, por fin, dejó de escribir."
                    ),
                    "emi_muere": (
                        "Cuando Emi se quedó atrás, los poemas se multiplicaron. "
                        "Uno a uno. Y las paredes, por fin, se llenaron. "
                        "Y el hospital, por fin, se quedó en silencio. "
                        "Porque ya no necesitaba más. Ya tenía a Emi. "
                        "Y a los poemas de Emi. Y a los poemas de los poemas de Emi."
                    ),
                    "kazuki_muere": (
                        "Cuando Kazuki se quedó atrás, los poemas cambiaron. "
                        "Dejaron de hablar de Emi. Y empezaron a hablar de Kazuki. "
                        "Y el hospital, al verlos, sonrió. Porque ya tenía "
                        "a alguien nuevo de quien escribir. Y a alguien nuevo "
                        "que recordar. Y a alguien nuevo que se quedara."
                    ),
                    "ambos_quedan": (
                        "Cuando los dos se quedaron, los poemas crecieron. "
                        "Dos poemas más. Dos paredes más. Dos nombres más. "
                        "Y el hospital, por primera vez, tuvo dos nombres que firmar. "
                        "Y los firmó. Y los recordó. Y los escribió. "
                        "Y los convirtió en pared. Y en poema. Y en hospital. "
                        "Y en Emi. Y en Kazuki. Y en nadie."
                    ),
                },
                "revelacion": (
                    "Los poemas no son poemas. Son personas. "
                    "Cada poema es alguien que se quedó. Y que escribió. "
                    "Y que se convirtió en pared. Y en poema. Y en hospital. "
                    "Y en Emi. Y en Kazuki. Y en todos los que estuvieron aquí. "
                    "Y en todos los que estarán. Y en todos los que nunca estarán. "
                    "Porque el hospital no es un hospital. Es un cuaderno. "
                    "Y el cuaderno no se cierra. Hasta que alguien lo cierra. "
                    "Y lo guarda. Y lo olvida. Y deja de escribir. "
                    "Y el hospital, por fin, se apaga. Y los poemas, por fin, "
                    "se borran. Y las paredes, por fin, se quedan vacías. "
                    "Y Emi, por fin, deja de escribir. Y de recordar. "
                    "Y de quedarse. Y de ser poema. Y de ser pared. "
                    "Y de ser hospital. Y de ser Emi. Y de ser nadie. "
                    "Y de ser todo. Y de ser nada. Y de ser."
                ),
            },
        },

        # ═══════════════════════════════════════════════════════
        #  DLC — LA MANSIÓN (COMENTADO hasta que salga el DLC)
        # ═══════════════════════════════════════════════════════
        # "mansion": {
        #     "mayordomo": {
        #         "nombre": "El mayordomo",
        #         "icono": "🎩",
        #         "tipo": "entidad",
        #         "capitulo": 1,
        #         "peligro": "desconocido",
        #         "descripcion": "...",
        #         "comportamiento": "...",
        #         "debilidades": "...",
        #         "apariciones": ["Cap 1 — El Recibidor"],
        #         "relacionado_con": ["La mansión"],
        #         "notas": "...",
        #         "origen": "...",
        #         "como_vencerlo": "...",
        #         "fragmentos": {
        #             "bueno": "...",
        #             "malo": "...",
        #             "secreto": "...",
        #             "ambos_caen": "...",
        #         },
        #         "revelacion": "...",
        #     },
        # },

        # ═══════════════════════════════════════════════════════
        #  DLC — EL BOSQUE (COMENTADO hasta que salga el DLC)
        # ═══════════════════════════════════════════════════════
        # "bosque": {
        #     ...
        # },
    }


    # -----------------------------------------------------------------
    # FUNCIONES — Base (mismas que antes, no rompemos nada)
    # -----------------------------------------------------------------
    def desbloquear_bestiario(historia, clave):
        if historia in BESTIARIO and clave in BESTIARIO[historia]:
            persistent.bestiario_desbloqueado.setdefault(historia, {})[clave] = True
            notificar("👁️", "Nuevo archivo", BESTIARIO[historia][clave]["nombre"], "#FF6B9D")
            return True
        return False

    def bestiario_desbloqueado(historia, clave):
        return persistent.bestiario_desbloqueado.get(historia, {}).get(clave, False)

    def bestiario_descubiertos(historia):
        if historia not in BESTIARIO:
            return 0
        return sum(1 for k in BESTIARIO[historia].keys() if bestiario_desbloqueado(historia, k))

    def bestiario_total(historia):
        if historia not in BESTIARIO:
            return 0
        return len(BESTIARIO[historia])

    def bestiario_descubiertos_global():
        total = 0
        for h in BESTIARIO.keys():
            total += bestiario_descubiertos(h)
        return total

    def bestiario_total_global():
        total = 0
        for h in BESTIARIO.keys():
            total += bestiario_total(h)
        return total

    def bestiario_por_tipo(historia, tipo):
        if historia not in BESTIARIO:
            return []
        if tipo == "todas":
            return list(BESTIARIO[historia].keys())
        return [k for k, v in BESTIARIO[historia].items() if v["tipo"] == tipo]

    def bestiario_de_capitulo(historia, cap):
        if historia not in BESTIARIO:
            return []
        return [k for k, v in BESTIARIO[historia].items() if v.get("capitulo") == cap]

    def color_peligro(p):
        if p == "bajo":       return "#4CAF50"
        if p == "medio":      return "#FFD700"
        if p == "alto":       return "#FF4444"
        return "#888888"

    # -----------------------------------------------------------------
    # FRAGMENTOS DE LORE — Se desbloquean según los finales del cap
    # -----------------------------------------------------------------
    def fragmentos_desbloqueados(historia, clave):
        if historia not in BESTIARIO or clave not in BESTIARIO[historia]:
            return 0
        entry = BESTIARIO[historia][clave]
        cap = entry["capitulo"]
        fragmentos = entry.get("fragmentos", {})
        count = 0
        for fid in fragmentos.keys():
            if final_desbloqueado(historia, cap, fid):
                count += 1
        return count

    def fragmentos_totales(historia, clave):
        if historia not in BESTIARIO or clave not in BESTIARIO[historia]:
            return 0
        return len(BESTIARIO[historia][clave].get("fragmentos", {}))

    def revelacion_desbloqueada(historia, clave):
        total = fragmentos_totales(historia, clave)
        if total == 0:
            return False
        return fragmentos_desbloqueados(historia, clave) >= total

    # -----------------------------------------------------------------
    # FUNCIONES NUEVAS — Para el menú multi-historia
    # -----------------------------------------------------------------
    def historias_bestiario_disponibles():
        resultado = []
        for hist_id in BESTIARIO.keys():
            info = None
            desbloqueada = False

            try:
                if hist_id in capitulos.historias:
                    h = capitulos.historias[hist_id]
                    info = {
                        "nombre": h.get("nombre", hist_id.capitalize()),
                        "icono": h.get("icono", "📁"),
                    }
                    desbloqueada = h.get("desbloqueado", False)
            except Exception:
                pass

            if info is None:
                if hist_id == "torre":
                    info = {"nombre": "La Torre", "icono": "🏢"}
                    desbloqueada = True
                else:
                    info = {"nombre": hist_id.capitalize(), "icono": "📁"}
                    desbloqueada = False

            resultado.append((hist_id, info, desbloqueada))

        return resultado

    def subtitulo_bestiario(historia):
        nombre = None
        try:
            if historia in capitulos.historias:
                nombre = capitulos.historias[historia].get("nombre", "")
        except Exception:
            pass

        if not nombre:
            if historia == "torre":
                nombre = "La Torre"
            else:
                nombre = historia.capitalize()

        return "ARCHIVO DE " + nombre.upper() if nombre.startswith("La ") else "ARCHIVO DEL " + nombre.upper()


# -----------------------------------------------------------------
# SCREEN DEL BESTIARIO — Diseño "expediente" con pestañas por historia
# -----------------------------------------------------------------
screen bestiario_menu():
    tag menu
    modal True

    default historia_actual = "torre"
    default seleccion = None
    default filtro_tipo = "todas"
    default filtro_cap = 0

    add Solid("#0d0810")

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1300
        ysize 850
        background Solid("#1a0f18")
        padding (0, 0)

        hbox:
            spacing 0
            xfill True
            yfill True

            frame:
                xsize 380
                yfill True
                background Solid("#150a18")
                padding (20, 20)

                has vbox spacing 14

                text "ARCHIVO":
                    size 36
                    bold True
                    color "#FF6B9D"

                text "[subtitulo_bestiario(historia_actual)]":
                    size 14
                    bold True
                    color "#a07b8a"
                    italic True

                null height 5

                text "[bestiario_descubiertos(historia_actual)] / [bestiario_total(historia_actual)] archivos":
                    size 13
                    color "#a07b8a"

                null height 5

                text "▸ Tipo" size 12 color "#888"

                textbutton "Todas":
                    action SetScreenVariable("filtro_tipo", "todas")
                    style "trophy_tab_button"
                    xfill True
                    if filtro_tipo == "todas":
                        background "#FF6B9D"
                        text_color "#FFFFFF"

                textbutton "👁️ Entidades":
                    action SetScreenVariable("filtro_tipo", "entidad")
                    style "trophy_tab_button"
                    xfill True
                    if filtro_tipo == "entidad":
                        background "#FF6B9D"
                        text_color "#FFFFFF"

                textbutton "🔮 Fenómenos":
                    action SetScreenVariable("filtro_tipo", "fenomeno")
                    style "trophy_tab_button"
                    xfill True
                    if filtro_tipo == "fenomeno":
                        background "#FF6B9D"
                        text_color "#FFFFFF"

                textbutton "📦 Objetos":
                    action SetScreenVariable("filtro_tipo", "objeto")
                    style "trophy_tab_button"
                    xfill True
                    if filtro_tipo == "objeto":
                        background "#FF6B9D"
                        text_color "#FFFFFF"

                textbutton "📍 Lugares":
                    action SetScreenVariable("filtro_tipo", "lugar")
                    style "trophy_tab_button"
                    xfill True
                    if filtro_tipo == "lugar":
                        background "#FF6B9D"
                        text_color "#FFFFFF"

                null height 5

                $ caps_con_entradas = sorted(set(BESTIARIO[historia_actual][k].get("capitulo", 0) for k in BESTIARIO[historia_actual].keys() if BESTIARIO[historia_actual][k].get("capitulo")))
                if caps_con_entradas:
                    text "▸ Capítulo" size 12 color "#888"

                    hbox:
                        spacing 4
                        xfill True

                        textbutton "Todos":
                            action SetScreenVariable("filtro_cap", 0)
                            style "trophy_tab_button"
                            if filtro_cap == 0:
                                background "#FF6B9D"
                                text_color "#FFFFFF"

                        for cap_num in caps_con_entradas:
                            textbutton "[cap_num]":
                                action SetScreenVariable("filtro_cap", cap_num)
                                style "trophy_tab_button"
                                if filtro_cap == cap_num:
                                    background "#FF6B9D"
                                    text_color "#FFFFFF"

                null height 10

                viewport:
                    xfill True
                    yfill True
                    mousewheel True
                    scrollbars "vertical"

                    has vbox spacing 6

                    $ claves = bestiario_por_tipo(historia_actual, filtro_tipo)
                    if filtro_cap != 0:
                        $ claves = [k for k in claves if BESTIARIO[historia_actual][k].get("capitulo") == filtro_cap]

                    if claves:
                        for clave in claves:
                            $ data = BESTIARIO[historia_actual][clave]
                            $ unlocked = bestiario_desbloqueado(historia_actual, clave)
                            $ seleccionada = (seleccion == clave)

                            button:
                                xfill True
                                background (Solid("#2a1520") if seleccionada else Solid("#1a0f15"))
                                hover_background Solid("#251520")
                                padding (12, 10)
                                sensitive unlocked
                                action SetScreenVariable("seleccion", clave)

                                has hbox spacing 10

                                text "[data['icono']]" size 26 yalign 0.5
                                vbox:
                                    spacing 2
                                    yalign 0.5
                                    text (("[data['nombre']]") if unlocked else "🔒 ???") size 15 bold True color ("#fff" if unlocked else "#555")
                                    if unlocked:
                                        $ fr_d = fragmentos_desbloqueados(historia_actual, clave)
                                        $ fr_t = fragmentos_totales(historia_actual, clave)
                                        text "Cap [data['capitulo']] · [fr_d]/[fr_t] fragmentos" size 11 color "#a07b8a"
                    else:
                        text "No hay archivos." size 13 color "#555" italic True

                textbutton "← Volver":
                    style "menu_button"
                    xalign 0.5
                    action ShowMenu("extras_menu")

            frame:
                xfill True
                yfill True
                background Solid("#1a0f18")
                padding (30, 25)

                has vbox spacing 14 xfill True

                hbox:
                    spacing 8
                    xfill True

                    for hist_id, hist_info, hist_unlocked in historias_bestiario_disponibles():
                        if hist_unlocked:
                            textbutton "[hist_info['icono']] [hist_info['nombre']]":
                                action [
                                    SetScreenVariable("historia_actual", hist_id),
                                    SetScreenVariable("seleccion", None),
                                    SetScreenVariable("filtro_cap", 0),
                                ]
                                style "trophy_tab_button"
                                if historia_actual == hist_id:
                                    background "#FF6B9D"
                                    text_color "#000"
                        else:
                            textbutton "🔒 ???":
                                action NullAction()
                                style "trophy_tab_button"
                                sensitive False

                null height 5

                if seleccion and bestiario_desbloqueado(historia_actual, seleccion):
                    $ data = BESTIARIO[historia_actual][seleccion]
                    $ fr_d = fragmentos_desbloqueados(historia_actual, seleccion)
                    $ fr_t = fragmentos_totales(historia_actual, seleccion)
                    $ rev_ok = revelacion_desbloqueada(historia_actual, seleccion)
                    $ origen_ok = (fr_d >= fr_t)
                    $ venc_ok = final_desbloqueado(historia_actual, data["capitulo"], "bueno")

                    vbox:
                        spacing 14
                        xfill True
                        yfill True

                        hbox:
                            spacing 20
                            frame:
                                xysize (100, 100)
                                background Solid("#2a1520")
                                text "[data['icono']]" size 60 xalign 0.5 yalign 0.5
                            vbox:
                                spacing 6
                                yalign 0.5
                                xfill True
                                text "[data['nombre']]" size 30 bold True color "#FF6B9D"
                                hbox:
                                    spacing 12
                                    text "Tipo: [data['tipo']]" size 13 color "#ccc"
                                    text "·" size 13 color "#ccc"
                                    text "Cap [data['capitulo']]" size 13 color "#ccc"
                                    text "·" size 13 color "#ccc"
                                    text "Peligro: [data['peligro'].upper()]" size 13 bold True color color_peligro(data['peligro'])
                                text "Fragmentos: [fr_d] / [fr_t]" size 14 color "#FFD700"

                        frame:
                            xfill True
                            yfill True
                            background Solid("#0d0810")
                            padding (15, 15)

                            viewport:
                                xfill True
                                yfill True
                                mousewheel True
                                scrollbars "vertical"

                                has vbox spacing 14

                                frame:
                                    xfill True
                                    background Solid("#15080d")
                                    padding (14, 12)
                                    text "[data['descripcion']]" size 14 color "#ddd" xmaximum 780

                                frame:
                                    xfill True
                                    background Solid("#15080d")
                                    padding (14, 12)
                                    has vbox spacing 6
                                    text "▸ Comportamiento" size 15 bold True color "#FF6B9D"
                                    text "[data['comportamiento']]" size 14 color "#ddd" xmaximum 780

                                frame:
                                    xfill True
                                    background Solid("#15080d")
                                    padding (14, 12)
                                    has vbox spacing 6
                                    text "▸ Debilidades" size 15 bold True color "#FF6B9D"
                                    text "[data['debilidades']]" size 14 color "#ddd" xmaximum 780

                                frame:
                                    xfill True
                                    background Solid("#15080d")
                                    padding (14, 12)
                                    has vbox spacing 6
                                    text "▸ Apariciones" size 15 bold True color "#FF6B9D"
                                    for ap in data["apariciones"]:
                                        text "· [ap]" size 13 color "#ccc"

                                frame:
                                    xfill True
                                    background Solid("#15080d")
                                    padding (14, 12)
                                    has vbox spacing 6
                                    text "▸ Relacionado con" size 15 bold True color "#FF6B9D"
                                    hbox:
                                        spacing 10
                                        for rel in data["relacionado_con"]:
                                            frame:
                                                background Solid("#2a1520")
                                                padding (10, 5)
                                                text "[rel]" size 13 color "#FF6B9D"

                                frame:
                                    xfill True
                                    background Solid("#15080d")
                                    padding (14, 12)
                                    has vbox spacing 6
                                    text "▸ Notas" size 15 bold True color "#FF6B9D"
                                    text "[data['notas']]" size 13 color "#ccc" italic True xmaximum 780

                                if origen_ok:
                                    frame:
                                        xfill True
                                        background Solid("#2a0a15")
                                        padding (14, 12)
                                        has vbox spacing 6
                                        text "▸ Origen" size 15 bold True color "#FF6B9D"
                                        text "[data['origen']]" size 14 color "#ffd8e0" xmaximum 780
                                else:
                                    frame:
                                        xfill True
                                        background Solid("#15080d")
                                        padding (14, 12)
                                        has vbox spacing 6
                                        text "▸ Origen 🔒" size 15 bold True color "#555"
                                        text "Se desbloquea al conseguir los 4 fragmentos del capítulo." size 13 color "#666" italic True

                                if venc_ok:
                                    frame:
                                        xfill True
                                        background Solid("#2a0a15")
                                        padding (14, 12)
                                        has vbox spacing 6
                                        text "▸ Cómo vencerlo" size 15 bold True color "#FF6B9D"
                                        text "[data['como_vencerlo']]" size 14 color "#ffd8e0" xmaximum 780
                                else:
                                    frame:
                                        xfill True
                                        background Solid("#15080d")
                                        padding (14, 12)
                                        has vbox spacing 6
                                        text "▸ Cómo vencerlo 🔒" size 15 bold True color "#555"
                                        text "Se desbloquea al conseguir el final bueno del capítulo." size 13 color "#666" italic True

                                null height 10
                                frame:
                                    xfill True
                                    ysize 2
                                    background Solid("#2a1520")

                                text "▸ Fragmentos de lore" size 17 bold True color "#FF6B9D"

                                $ idx = 0
                                for fid, frag in data.get("fragmentos", {}).items():
                                    $ idx += 1
                                    $ desbloqueado = final_desbloqueado(historia_actual, data["capitulo"], fid)

                                    frame:
                                        xfill True
                                        background (Solid("#251520") if desbloqueado else Solid("#0d0810"))
                                        padding (14, 12)

                                        has vbox spacing 6

                                        hbox:
                                            spacing 10
                                            text "Fragmento [idx]" size 15 bold True color ("#FF6B9D" if desbloqueado else "#444")
                                            text "— Final: [fid]" size 12 color ("#a07b8a" if desbloqueado else "#333")

                                        if desbloqueado:
                                            text "[frag]" size 14 color "#ddd" xmaximum 780
                                        else:
                                            text "🔒 Bloqueado. Consigue el final «[fid]» para desvelarlo." size 13 color "#555" italic True

                                null height 10
                                text "▸ Revelación" size 17 bold True color ("#FF6B9D" if rev_ok else "#444")

                                frame:
                                    xfill True
                                    background (Solid("#3a1520") if rev_ok else Solid("#0d0810"))
                                    padding (18, 14)

                                    if rev_ok:
                                        text "[data['revelacion']]" size 14 color "#fff" italic True xmaximum 780
                                    else:
                                        text "🔒 Consigue TODOS los fragmentos del Capítulo [data['capitulo']] para desbloquear la revelación final." size 13 color "#555" italic True

                else:
                    vbox:
                        spacing 15
                        xalign 0.5
                        yalign 0.5

                        text "👁️" size 80 xalign 0.5
                        text "Selecciona un archivo" size 22 color "#a07b8a" xalign 0.5
                        text "Elige una entrada de la izquierda para ver su contenido." size 14 color "#555" xalign 0.5