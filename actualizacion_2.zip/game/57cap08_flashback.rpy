# ═══════════════════════════════════════════════════════════════
#  57cap08_flashbacks.rpy — Flashbacks del Capítulo 8
#  -----------------------------------------------------------------
#  2 escenas del pasado de Emi y Kazuki.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES PARA FLASHBACKS
# ─────────────────────────────────────────────────────────────

# Emi en flashback (voz más joven, más frágil)
define em_old = Character(
    "Emi",
    color="#cfd8dc",
    what_color="#e8e0e8",
    what_italic=True,
    what_size=28
)

# Kazuki en flashback (voz más joven, antes del favor)
define kz_old = Character(
    "Kazuki",
    color="#aed581",
    what_color="#d0e8c8",
    what_italic=True,
    what_size=28
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE FLASHBACK
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Emi en el hospital (flashback)
# Archivo: images/fondos/cap08/flash_emi_hospital.png
# Prompt: Anime dark psychological horror scene, soft melancholic
#         tone. A hospital room at night, seen from the bed.
#         Pale blue light from a window. On the bedside table, a
#         notebook and a pen. The notebook is open, filled with
#         handwritten poems. In the bed, a teenage girl (Emi,
#         15 years old, ash-blonde hair) writes slowly. She is
#         alone. The door is closed. Atmosphere: isolation,
#         the moment writing becomes the only way to breathe.
#         Cold palette: pale blues, faded whites. 16:9, no text.
image bg_flash_emi_hospital = Solid("#1a2228")

# 🎨 PROMPT IMAGEN — Kazuki y el favor (flashback)
# Archivo: images/fondos/cap08/flash_kazuki_favor.png
# Prompt: Anime dark psychological horror scene, melancholic
#         tone. A high school corridor at dusk, empty. Lockers
#         on both sides, a window at the end letting in orange
#         light. In the foreground, a teenage boy (Kazuki, 17
#         years old, brown hair) stands facing another student
#         (silhouette, back turned). They are shaking hands.
#         The handshake looks wrong. Atmosphere: the second
#         before a deal that cannot be undone. Warm muted
#         palette, orange light on cold walls. 16:9, no text.
image bg_flash_kazuki_favor = Solid("#2a2218")


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 1 — Emi en el hospital
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Emi recuerda los seis meses que estuvo ingresada.
# ═══════════════════════════════════════════════════════════════
label cap08_flashback_emi_hospital:

    # ── Transición ──
    n "..."

    n "Y por un momento, dejas de estar aquí."

    scene bg_flash_emi_hospital
    with Dissolve(1.0)

    # ── Indicador visual de flashback ──
    show screen flashback_overlay

    # ── Música de flashback ──
    $ musica("flashback_suave", fade=2.0)

    # ── Ambientación ──
    n "El hospital."

    n "Tenías quince años."

    n "Y no entendías por qué te habían encerrado."

    em_old "(No estoy enferma.)"
    em_old "(Solo escribo.)"

    # ── Detalle clave ──
    n "Los médicos te decían que escribir era bueno."

    n "Pero luego te quitaban el cuaderno."

    n "Y tú escribías en las paredes."

    n "Y ellos borraban las paredes."

    n "Y tú volvías a escribir."

    em_old "(Si no escribo, me ahogo.)"
    em_old "(Y si me ahogo, me encierran más.)"

    n "No te lo explicaron."

    n "Te dijeron que era por tu bien."

    n "Y que algún día lo entenderías."

    # ── Conexión con el presente ──
    n "Ese día no tardó en llegar."

    n "A los dieciséis, saliste."

    n "A los diecisiete, dejaste de escribir."

    n "Y desde entonces, no escribes."

    n "Aunque quieras."

    em_old "(Los poemas no se van.)"
    em_old "(Se quedan.)"
    em_old "(Pero solo si alguien los recuerda.)"
    em_old "(Y yo los recuerdo.)"
    em_old "(A todos.)"

    # ── Métrica ──
    $ modificar_metrica("angustia", +4)
    $ modificar_metrica("miedo", +3)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "emi")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso8_despertar
    with Dissolve(1.0)

    show emi_img at left
    show kazuki_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al hospital. A Kazuki."

    n "Kazuki te está mirando."

    kz "¿Estás bien?"

    em "Sí."

    kz "No lo parece."

    em "..."

    em "Es solo que..."

    em "Este sitio me recuerda a algo."

    kz "..."

    kz "A mí también."

    n "Y por un momento, los dos os quedáis en silencio."

    n "Pero es un silencio distinto. Un silencio compartido."

    # ── Flag ──
    $ gtn_flag("fb_emi_visto", True)

    return


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 2 — Kazuki y el favor
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Kazuki recuerda el favor que lo trajo aquí.
# ═══════════════════════════════════════════════════════════════
label cap08_flashback_kazuki_favor:

    # ── Transición ──
    n "..."

    n "Kazuki se ha quedado en silencio."

    n "Y por un momento, ves algo distinto en él."

    # ── Flashback ──
    scene bg_flash_kazuki_favor
    with Dissolve(1.0)

    show screen flashback_overlay

    $ musica("flashback_tension", fade=2.0)

    # ── Ambientación ──
    n "Un pasillo. De instituto."

    n "Al atardecer."

    n "Las clases habían terminado."

    n "Y Kazuki tenía una mano delante."

    kz_old "(Un favor.)"
    kz_old "(Solo uno.)"

    n "Eso le dijeron."

    n "Y él aceptó."

    # ── Detalle clave ──
    n "El favor era simple."

    n "Votar por alguien."

    n "En las elecciones de delegado."

    n "Pero cuando llegó el momento..."

    n "Kazuki no votó."

    n "Kazuki contó los votos."

    n "Y cambió uno."

    kz_old "(No.)"
    kz_old "(No, no, no.)"

    n "Su rival no salió."

    n "O eso creyó él."

    n "Porque cuando llegó a casa, estaba solo."

    n "Sin el otro."

    n "Sin nadie."

    # ── Conexión con el presente ──
    n "Desde esa noche, Kazuki sonríe."

    n "Sonríe siempre."

    n "Porque si no sonríe, se acuerda."

    kz_old "(No pasa nada.)"
    kz_old "(No pasa nada, ¿vale?)"
    kz_old "(No pasa nada.)"
    kz_old "(No pasa nada.)"

    n "Pero sí pasa."

    n "Y él lo sabe."

    n "Pero no lo dice."

    # ── Métrica ──
    $ modificar_metrica("angustia", +5)
    $ modificar_metrica("miedo", +3)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "kazuki")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso8_espejo
    with Dissolve(1.0)

    show emi_img at left
    show kazuki_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al presente. Al espejo."

    n "Kazuki está mirando su propio reflejo."

    n "Pero el espejo no refleja."

    n "Traga."

    em "Kazuki."

    kz "¿Sí?"

    em "Te has quedado en blanco."

    kz "Solo estaba... pensando."

    n "Las mismas palabras que le has dicho tú antes."

    em_p "(Ha usado mi frase.)"
    em_p "(Como el eco.)"

    # ── Flag ──
    $ gtn_flag("fb_kazuki_visto", True)

    return