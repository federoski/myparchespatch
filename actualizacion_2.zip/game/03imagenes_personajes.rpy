# ═══════════════════════════════════════════════════════════════
#  03imagenes_personajes.rpy
#  -----------------------------------------------------------------
#  Sistema de imágenes de personaje con callback.
#  La imagen aparece cuando el personaje habla y desaparece al
#  terminar su línea. Adaptado del proyecto anterior.
#
#  ⚠️ Este archivo SOLO define imágenes y callbacks de diálogo.
#     Las FICHAS de personajes van en 04ficha_personajes.rpy.
# ═══════════════════════════════════════════════════════════════

# -----------------------------------------------------------------
# 1) DEFINICIÓN DE IMÁGENES
# -----------------------------------------------------------------
# 🎨 PROMPT IMAGEN — Akira
# Archivo: images/personajes/akira.png
# Prompt: Retrato anime oscuro de Akira, chico de 17 años,
#         pelo negro despeinado y algo largo, ojos grises cansados,
#         ropa urbana oscura (sudadera negra), expresión de miedo
#         contenido, iluminación tenue azulada, fondo transparente.
image akira_img = "images/personajes/akira.png"

# 🎨 PROMPT IMAGEN — Ren
# Archivo: images/personajes/ren.png
# Prompt: Retrato anime oscuro de Ren, chico de 18 años,
#         pelo castaño claro corto, ojos verdes apagados, gafas finas
#         opcionales, camisa clara arrugada, expresión seria pero
#         protectora, fondo transparente.
image ren_img = "images/personajes/ren.png"

# 🎨 PROMPT IMAGEN — Yuki
# Archivo: images/personajes/yuki.png
# Prompt: Retrato anime oscuro de Yuki, chica de 16 años, pelo negro
#         recogido en coleta alta, ojos marrones grandes, ropa escolar
#         desgastada, expresión curiosa pero nerviosa, fondo transparente.
image yuki_img = "images/personajes/yuki.png"

# 🎨 PROMPT IMAGEN — Sora
# Archivo: images/personajes/sora.png
# Prompt: Retrato anime oscuro de Sora, chico de 18 años, pelo
#         azulado oscuro, ojos azules, ropa deportiva, expresión
#         tranquila que oculta algo, fondo transparente.
image sora_img = "images/personajes/sora.png"

# 🎨 PROMPT IMAGEN — Hana
# Archivo: images/personajes/hana.png
# Prompt: Retrato anime oscuro de Hana, chica de 17 años, pelo rosa
#         apagado, ojos violeta, ropa con detalles florales, expresión
#         dulce pero triste, fondo transparente.
image hana_img = "images/personajes/hana.png"

# 🎨 PROMPT IMAGEN — Kaito
# Archivo: images/personajes/kaito.png
# Prompt: Retrato anime oscuro de Kaito, chico de 19 años, pelo
#         negro puntiagudo, ojos rojizos, chaqueta con capucha,
#         expresión desafiante, fondo transparente.
image kaito_img = "images/personajes/kaito.png"

# 🎨 PROMPT IMAGEN — Mei
# Archivo: images/personajes/mei.png
# Prompt: Retrato anime oscuro de Mei, chica de 16 años, pelo corto
#         negro con mechón blanco, ojos grises, ropa gótica sencilla,
#         expresión temerosa, fondo transparente.
image mei_img = "images/personajes/mei.png"

# 🎨 PROMPT IMAGEN — Daichi
# Archivo: images/personajes/daichi.png
# Prompt: Retrato anime oscuro de Daichi, chico de 20 años, pelo
#         castaño oscuro, ojos marrones, complexión fuerte, ropa
#         informal, expresión seria, fondo transparente.
image daichi_img = "images/personajes/daichi.png"

# 🎨 PROMPT IMAGEN — Rin
# Archivo: images/personajes/rin.png
# Prompt: Retrato anime oscuro de Rin, chica de 17 años, pelo
#         pelirrojo largo, ojos verdes brillantes, ropa cómoda,
#         expresión decidida, fondo transparente.
image rin_img = "images/personajes/rin.png"

# 🎨 PROMPT IMAGEN — Tsubasa
# Archivo: images/personajes/tsubasa.png
# Prompt: Retrato anime oscuro de Tsubasa, chico de 18 años, pelo
#         gris claro, ojos ámbar, ropa elegante informal, expresión
#         analítica, fondo transparente.
image tsubasa_img = "images/personajes/tsubasa.png"

# 🎨 PROMPT IMAGEN — Ayame
# Archivo: images/personajes/ayame.png
# Prompt: Retrato anime oscuro de Ayame, chica de 17 años, pelo
#         negro liso hasta hombros, ojos morados, ropa tradicional
#         japonesa moderna, expresión calmada, fondo transparente.
image ayame_img = "images/personajes/ayame.png"

# 🎨 PROMPT IMAGEN — Hiro
# Archivo: images/personajes/hiro.png
# Prompt: Retrato anime oscuro de Hiro, chico de 19 años, pelo
#         azul marino, ojos azul claro, ropa deportiva, expresión
#         amistosa que esconde culpa, fondo transparente.
image hiro_img = "images/personajes/hiro.png"

# 🎨 PROMPT IMAGEN — Nao
# Archivo: images/personajes/nao.png
# Prompt: Retrato anime oscuro de Nao, chica de 16 años, pelo
#         castaño claro con coletas, ojos celestes, ropa escolar
#         con lazos, expresión alegre forzada, fondo transparente.
image nao_img = "images/personajes/nao.png"

# 🎨 PROMPT IMAGEN — Souta
# Archivo: images/personajes/souta.png
# Prompt: Retrato anime oscuro de Souta, chico de 20 años, pelo
#         negro largo recogido, ojos oscuros, ropa formal desgastada,
#         expresión reservada, fondo transparente.
image souta_img = "images/personajes/souta.png"

# 🎨 PROMPT IMAGEN — Emi
# Archivo: images/personajes/emi.png
# Prompt: Retrato anime oscuro de Emi, chica de 18 años, pelo
#         rubio ceniza, ojos gris-verdosos, ropa elegante sencilla,
#         expresión melancólica, fondo transparente.
image emi_img = "images/personajes/emi.png"

# 🎨 PROMPT IMAGEN — Kazuki
# Archivo: images/personajes/kazuki.png
# Prompt: Retrato anime oscuro de Kazuki, chico de 19 años, pelo
#         castaño con reflejos, ojos verdes, ropa casual, expresión
#         de liderazgo contenido, fondo transparente.
image kazuki_img = "images/personajes/kazuki.png"

# 🎨 PROMPT IMAGEN — Prof. Kanae
# Archivo: images/personajes/kanae.png
# Prompt: Retrato anime oscuro de Kanae, mujer de 22 años, pelo
#         negro largo, ojos marrones cansados, ropa de profesora
#         formal pero simple, expresión adulta preocupada, fondo
#         transparente.
image kanae_img = "images/personajes/kanae.png"

# 🎨 PROMPT IMAGEN — Prof. Ryō
# Archivo: images/personajes/ryo.png
# Prompt: Retrato anime oscuro de Ryō, hombre de 22 años, pelo
#         negro corto y ordenado, ojos oscuros, camisa y americana
#         informal, expresión seria y protectora, fondo transparente.
image ryo_img = "images/personajes/ryo.png"


# -----------------------------------------------------------------
# 2) CALLBACKS DE DIÁLOGO
# -----------------------------------------------------------------
init python:
    class PersonajeCallback:
        """Muestra la imagen del personaje al empezar su línea y la
        oculta al terminar. La imagen se escala a una altura máxima
        para que no sobresalga de la pantalla."""
        def __init__(self, imagen_name, xpos=0.0, altura_max=400):
            self.imagen_name = imagen_name
            self.xpos = xpos
            self.altura_max = altura_max

        def __call__(self, event, interact=True, **kwargs):
            if event == "begin":
                # Transformación: escalar a altura máxima manteniendo proporción
                transform = Transform(
                    fit="contain",
                    xysize=(None, self.altura_max),
                    xalign=self.xpos,
                    yalign=1.0  # Pegado al suelo (parte inferior)
                )
                renpy.show(
                    self.imagen_name,
                    at_list=[transform],
                    layer="master"
                )
            elif event == "end":
                renpy.hide(self.imagen_name, layer="master")

    def mostrar_imagen_personaje(imagen_name, xpos=0.0, altura_max=400):
        return PersonajeCallback(imagen_name, xpos, altura_max)


# -----------------------------------------------------------------
# 3) DEFINICIÓN DE PERSONAJES (Character)
# -----------------------------------------------------------------
# Convención: xpos 0.0 = izquierda, 1.0 = derecha.
# Los que tienen la misma xpos se superponen si hablan a la vez
# (no suele pasar porque el callback oculta el anterior).
# -----------------------------------------------------------------

# Narrador
define n = Character(
    "Narrador",
    color="#FFD700",
    what_color="#E6E6FA",
    what_size=30
)

# ── Cap 1 ──
define ak = Character(
    "Akira",
    color="#7ec8e3",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("akira_img", xpos=0.0)
)
define re = Character(
    "Ren",
    color="#c1a57b",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("ren_img", xpos=1.0)
)

# ── Cap 2 ──
define yu = Character(
    "Yuki",
    color="#b39ddb",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("yuki_img", xpos=0.0)
)
define so = Character(
    "Sora",
    color="#64b5f6",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("sora_img", xpos=1.0)
)

# ── Cap 3 ──
define ha = Character(
    "Hana",
    color="#f48fb1",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("hana_img", xpos=0.0)
)
define ka = Character(
    "Kaito",
    color="#ef5350",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("kaito_img", xpos=1.0)
)

# ── Cap 4 ──
define me = Character(
    "Mei",
    color="#90a4ae",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("mei_img", xpos=0.0)
)
define da = Character(
    "Daichi",
    color="#a1887f",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("daichi_img", xpos=1.0)
)

# ── Cap 5 ──
define ri = Character(
    "Rin",
    color="#e57373",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("rin_img", xpos=0.0)
)
define tu = Character(
    "Tsubasa",
    color="#b0bec5",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("tsubasa_img", xpos=1.0)
)

# ── Cap 6 ──
define ay = Character(
    "Ayame",
    color="#ce93d8",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("ayame_img", xpos=0.0)
)
define hi = Character(
    "Hiro",
    color="#4fc3f7",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("hiro_img", xpos=1.0)
)

# ── Cap 7 ──
define na = Character(
    "Nao",
    color="#ffcc80",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("nao_img", xpos=0.0)
)
define su = Character(
    "Souta",
    color="#8d6e63",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("souta_img", xpos=1.0)
)

# ── Cap 8 ──
define em = Character(
    "Emi",
    color="#cfd8dc",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("emi_img", xpos=0.0)
)
define kz = Character(
    "Kazuki",
    color="#aed581",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("kazuki_img", xpos=1.0)
)

# ── Pensamientos Cap 8 ──
define em_p = Character(
    "Emi",
    color="#cfd8dc",
    what_color="#e8e0e8",
    what_italic=True,
    what_size=28,
    who=None
)
define kz_p = Character(
    "Kazuki",
    color="#aed581",
    what_color="#d0e8c8",
    what_italic=True,
    what_size=28,
    who=None
)

# ── Cap 9 ──
define kna = Character(
    "Prof. Kanae",
    color="#f06292",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("kanae_img", xpos=0.0)
)
define ryo = Character(
    "Prof. Ryō",
    color="#7986cb",
    what_color="#FFFFFF",
    callback=mostrar_imagen_personaje("ryo_img", xpos=1.0)
)

# ── Voz misteriosa (para la torre) ──
define torre = Character(
    "La Torre",
    color="#8b0000",
    what_color="#FF4444",
    what_italic=True
)