# ═══════════════════════════════════════════════════════════════
#  56cap07_nao_souta.rpy — Capítulo 7: La máscara
#  -----------------------------------------------------------------
#  Pareja: Nao & Souta
#  Posición: Nao (izq) + Souta (der)
#  Finales: bueno / bueno_especial / nao_muere / souta_muere / ambos_quedan / secreto
#  Minijuego: TIMING CON MÚSICA (aplausos del público)
#  Exploración: menú con flechas (3 zonas)
#  Diccionario: mascara_nao, risa_forzada, espejo_deformante, funcion_33
#  Fichas: nao, souta
#  Bestiario: circo, publico_rie
#  Pistas tablón: 6
#  Deducciones: 2
#  Flashbacks: 2
#  Eco El·yon: 3 apariciones
#
#  ⚠️ NOTA: Los labels cap07_nota_*, cap07_flashback_*,
#     cap07_deduccion_*, cap07_eco_*, cap07_pulsar_* están
#     definidos en sus respectivos archivos auxiliares
#     (56cap07_notas.rpy, 56cap07_flashbacks.rpy,
#      56cap07_deducciones.rpy, 56cap07_eco.rpy,
#      56cap07_objetos.rpy). NO se duplican aquí.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES
# ─────────────────────────────────────────────────────────────
# Nao y Souta YA están definidos en 03imagenes_personajes.rpy
# como `na` y `su`. Usamos esos para aprovechar el callback
# automático de imagen.
#
# elyon_voz ya está definido en 55cap06_ayame_hiro.rpy.


# ─────────────────────────────────────────────────────────────
#  IMÁGENES (placeholders temporales)
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Despertar en la carpa
# Archivo: images/fondos/cap07/piso7_despertar.png
# Prompt: Anime dark psychological horror scene: the inside of an
#         abandoned circus tent at night. Massive red-and-white
#         striped canvas, torn in several places, hanging from
#         wooden poles. A single spotlight flickers on, illuminating
#         an empty ring in the center. Sawdust on the floor. Old
#         wooden benches around, empty. Atmosphere: waiting for a
#         show that never starts. Muted palette: deep reds, faded
#         whites, cold shadows. Anime style, 16:9, no text.
image bg_piso7_despertar = Solid("#2a1a1c")

# 🎨 PROMPT IMAGEN — Sala de los espejos deformantes
# Archivo: images/fondos/cap07/piso7_espejos.png
# Prompt: Anime dark psychological horror scene: a circular room
#         lined with dozens of old carnival mirrors, all warped
#         and cracked. Each mirror reflects something slightly
#         different — some show empty air, some show faces that
#         don't belong to anyone present. Floor covered in broken
#         glass and dust. Atmosphere: uncanny, disorienting. 16:9.
image bg_piso7_espejos = Solid("#1a1a22")

# 🎨 PROMPT IMAGEN — Vestuario
# Archivo: images/fondos/cap07/piso7_vestuario.png
# Prompt: Anime dark psychological horror scene: a long backstage
#         dressing room, lined with wooden vanities and mirrors.
#         Dozens of clown masks hang on the walls in neat rows.
#         Old costumes on hangers. A single bulb flickers. On one
#         vanity, a half-written letter. On another, a small music
#         box, closed. Atmosphere: intimate, melancholic, wrong.
#         16:9, no text.
image bg_piso7_vestuario = Solid("#221a1e")

# 🎨 PROMPT IMAGEN — La carpa vacía (centro)
# Archivo: images/fondos/cap07/piso7_carpa.png
# Prompt: Anime dark psychological horror scene: the center of
#         the abandoned circus tent, seen from the audience's
#         point of view. The ring is empty, but the spotlight
#         still shines on it. The wooden benches are full of
#         pale silhouettes — faceless, motionless. They are
#         waiting. They are not breathing. Atmosphere: audience
#         of the dead. 16:9, no text.
image bg_piso7_carpa = Solid("#1e1416")

# 🎨 PROMPT IMAGEN — Puerta al fondo
# Archivo: images/fondos/cap07/piso7_salida.png
# Prompt: Anime dark psychological horror scene: at the far end
#         of the circus tent, behind the ring, a tall wooden door
#         with a faded star painted on it. The door is slightly
#         ajar, revealing soft warm light from the other side.
#         Around it, the canvas is torn, letting in cold blue
#         moonlight. Atmosphere: final threshold, backstage exit.
#         16:9, no text.
image bg_piso7_salida = Solid("#2e2418")

# ── OBJETOS ──

# 🎨 PROMPT IMAGEN — Máscara de payaso
# Archivo: images/objetos/cap07_mascara.png
# Prompt: Anime dark psychological horror close-up: a single
#         porcelain clown mask, cracked down the middle, lying
#         on a wooden vanity. Its painted smile is faded. One
#         eye is missing. The other eye seems to follow the
#         viewer. 16:9, no text.
image cap07_mascara = Solid("#2e1a1e")

# 🎨 PROMPT IMAGEN — Caja de música
# Archivo: images/objetos/cap07_caja_musica.png
# Prompt: Anime dark psychological horror close-up: a small
#         antique music box, made of dark wood, with a tiny
#         ballerina figurine on top. The ballerina is missing
#         her head. The key is half-turned. Dust on the lid.
#         16:9, no text.
image cap07_caja_musica = Solid("#221a10")

# ── IMÁGENES DE FINAL ──

# 🎨 PROMPT IMAGEN — Final bueno
# Archivo: images/finales/cap7_final_bueno.png
# Prompt: Anime dark psychological horror scene: a 16-year-old
#         girl with pale pink hair (Nao) and a 20-year-old boy
#         with dark violet hair (Souta) walking side by side
#         toward the tall wooden door at the back of the circus
#         tent, seen from behind. The benches behind them are
#         empty. The spotlight is off. Soft warm light ahead.
#         16:9, no text.
image cap7_final_bueno = Solid("#e8d0a8")

# 🎨 PROMPT IMAGEN — Final especial (Sin máscara)
# Archivo: images/finales/cap7_final_especial.png
# Prompt: Anime dark psychological horror scene: close-up of
#         Nao's face, no mask. Tears on her cheeks but a real
#         smile. Behind her, blurred, Souta's hand reaching
#         toward her. The masks on the wall behind are all
#         facing away. Warm light. 16:9, no text.
image cap7_final_especial = Solid("#f0d8b0")

# 🎨 PROMPT IMAGEN — Final Nao muere
# Archivo: images/finales/cap7_final_nao_muere.png
# Prompt: Anime dark psychological horror scene: Souta alone at
#         the back door of the circus tent, looking back. In the
#         ring, in the spotlight, a single porcelain mask lies
#         on the sawdust. No one there. 16:9, no text.
image cap7_final_nao_muere = Solid("#1a181c")

# 🎨 PROMPT IMAGEN — Final Souta muere
# Archivo: images/finales/cap7_final_souta_muere.png
# Prompt: Anime dark psychological horror scene: Nao alone in
#         front of the open wooden door, looking back over her
#         shoulder at the empty ring. On the ring's edge, a
#         single object remains: a small music box, playing
#         silently. 16:9, no text.
image cap7_final_souta_muere = Solid("#1a1818")

# 🎨 PROMPT IMAGEN — Final ambos quedan
# Archivo: images/finales/cap7_final_ambos.png
# Prompt: Anime dark psychological horror scene: two silhouettes
#         (a girl and a boy) sitting on the edge of the circus
#         ring, back to back, surrounded by pale motionless
#         audience silhouettes. The door in the distance is
#         closed. The spotlight flickers. 16:9, no text.
image cap7_final_ambos = Solid("#141418")

# 🎨 PROMPT IMAGEN — Final secreto (Función 33)
# Archivo: images/finales/cap7_final_secreto.png
# Prompt: Anime dark psychological horror scene: the circus ring
#         seen from above, but its surface is now full of pale
#         audience faces, all looking up, all smiling. Among
#         them, faintly, the face of Nao, eyes open. She is not
#         dead. She is performing. 16:9, no text.
image cap7_final_secreto = Solid("#0f0f14")


# ═══════════════════════════════════════════════════════════════
#  CAPÍTULO 7
# ═══════════════════════════════════════════════════════════════
label capitulo_7:

    # ── Pantalla de carga ──
    $ _cap_data = capitulos.historias["torre"]["actos"].get(7, {})
    $ _nombre_cap = _cap_data.get("nombre", "La máscara")
    $ _sub_cap = _cap_data.get("sub", "Nao & Souta")
    $ _icono_cap = _cap_data.get("icono", "🎭")
    call mostrar_pantalla_carga("torre", 7, _nombre_cap, _sub_cap, _icono_cap)

    $ gtn_reiniciar_metricas()
    $ gtn_capitulo_actual = 7
    $ capitulos.desbloquear_capitulo("torre", 7)
    $ registrar_capitulo_jugado(7)

    scene black
    with fade

    show screen gtn_notif_screen
    $ musica("torre_ambiente", fade=2.0)

    $ add_achievement_with_popup(achievement_septimo_despertar)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 1 — EL DESPERTAR
    # ═══════════════════════════════════════════════════════════

    n "Lo primero que notas es el olor."
    n "Serrín. Sudor viejo. Algodón de azúcar rancio."
    n "Lo segundo, el sonido."
    n "Un foco que zumba. Solo uno."
    n "Y luego, el silencio."
    n "Un silencio que espera algo."
    n "Abres los ojos."

    scene bg_piso7_despertar
    with fade

    n "Estás tumbada en el suelo de una carpa."
    n "Roja y blanca. Rasgada."
    n "Y al fondo, un círculo iluminado."
    n "El centro del espectáculo."
    n "Vacío."

    show nao_img at left
    with dissolve

    na "..."
    na "¿Dónde está el público?"

    n "Te incorporas despacio. El serrín se te pega a las manos."
    n "El foco no se mueve. Pero tú sí."

    na "(Una carpa.)"
    na "(Pero no hay nadie.)"
    na "(¿Y por qué hay un foco encendido?)"

    $ desbloquear_ficha("torre", "nao")
    $ add_achievement_with_popup(achievement_conoce_nao)

    na "¿Hola?"
    n "Tu voz no hace eco."
    n "La carpa se la traga."
    n "Y entonces, muy bajo, muy lejano..."
    n "Alguien aplaude."
    n "Una sola vez."

    $ desbloquear_pista("torre", "p7_mascara_rota")

    # ── Decisión 1 ──
    menu:
        "¿Qué haces?"

        "Subir al centro. Al círculo iluminado.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("nao_sube", True)
            $ registrar_decision()

            na "Vale. Voy a ver."
            n "Caminas hacia el círculo."
            n "El foco te sigue. Sin moverse."
            n "Y al llegar al centro, algo se mueve bajo el serrín."
            n "Una máscara. Blanca. Rota por la mitad."
            na "..."
            na "(Una máscara de payaso.)"
            na "(¿Y por qué está rota?)"

        "Quedarte quieta. Escuchar la carpa.":
            $ modificar_metrica("miedo", +8)
            $ modificar_metrica("angustia", +10)
            $ gtn_flag("nao_escucha", True)
            $ registrar_decision()

            na "..."
            n "Cierras los ojos. Escuchas."
            n "La lona cruje. El foco zumba."
            n "Y entonces, muy bajo, muy lejos, alguien ríe."
            na "Hay alguien."
            na "Y se está riendo."
            na "(Pero yo no he dicho nada gracioso.)"

        "Llamar. Preguntar si hay alguien.":
            $ modificar_metrica("miedo", +10)
            $ modificar_metrica("angustia", +5)
            $ gtn_flag("nao_llama", True)
            $ registrar_decision()
            $ gtn_flag("grito_alguna_vez", True)

            na "¿Hola? ¿Hay alguien?"
            n "Tu voz rebota en la lona."
            n "Y vuelve. Pero distinta."
            n "Como si varias voces la repitieran a la vez."
            na "Eso no ha sido mi voz."
            na "(Han sido varias.)"
            na "(Y todas se han reído al final.)"

    if estado_minimo("miedo", 40):
        na "(Me tiemblan las manos.)"
        na "(No debería. Solo es una carpa.)"
        na "(Pero está llena de algo.)"
        na "(Y ese algo me mira.)"

    if estado_extremo("angustia"):
        n "Sientes que te falta el aire. Y no hay ninguna razón para ello."
        na "(Respira. Respira.)"
        na "(No estás en peligro. Todavía.)"

    call cap07_eco_1
    $ add_achievement_with_popup(achievement_primera_decision)

    # ── Nota: la carpa ──
    call cap07_nota_carpa

    # ═══════════════════════════════════════════════════════════
    #  ACTO 2 — EL ENCUENTRO
    # ═══════════════════════════════════════════════════════════

    n "Entonces lo oyes."

    $ sonido("pasos_lentos")

    n "Pasos. Lentos. Alguien se acerca."
    n "Pero no viene del círculo."
    n "Viene de detrás de las gradas."

    show souta_img at right
    with dissolve

    su "..."
    su "Hola."
    na "Hola."
    su "No pasa nada, ¿vale?"
    na "¿Qué?"
    su "Que no pasa nada."
    su "Es una carpa. Un poco rara. Pero es una carpa."
    su "Vamos a salir de aquí."

    n "El chico es alto. Delgado. Pelo oscuro con reflejos violeta."
    n "Y no sonríe."
    n "No sonríe nada."

    na "Nao."
    su "Souta."
    na "Vale, Souta."
    su "Vale, Nao."

    $ desbloquear_ficha("torre", "souta")
    $ add_achievement_with_popup(achievement_conoce_souta)

    n "No sabes por qué, pero le crees."
    n "O sí. Pero no del todo."

    if gtn_flag("nao_escucha"):
        su "Te he visto escuchar."
        su "¿Has oído algo?"
        na "Risas."
        su "..."
        su "Ya."
        su "Yo no he oído nada."
        na "Ya."
        na "Yo tampoco las oiría si no supiera escuchar."
        su "..."
        su "Vale."
        na "(No ha cambiado de cara.)"
        na "(Pero ha dejado de mirarme.)"
        na "(Solo un momento.)"

    elif gtn_flag("nao_sube"):
        su "Te he visto subir al círculo."
        su "¿Has encontrado algo?"
        na "Una máscara rota."
        su "..."
        su "¿Una máscara?"
        na "De payaso. Blanca. Partida por la mitad."
        su "¿Y por qué iba a haber una máscara ahí?"
        na "No lo sé."
        su "Eso no me gusta."
        na "A mí tampoco."

    elif gtn_flag("nao_llama"):
        su "Te he oído llamar."
        su "Pero no ha sido tu voz."
        na "¿Qué?"
        su "Tu voz ha rebotado. Pero han sido varias."
        su "Y al final, todas se han reído."
        na "..."
        na "Ya lo he oído yo también."
        su "Entonces no estoy loco."
        na "O estamos los dos."
        su "Peor."

    if estado_minimo("angustia", 50):
        n "Souta te mira. Y por un momento, ves algo en sus ojos."
        n "Cansancio. Cansancio de verdad."
        na "(No es solo la carpa.)"
        na "(Lleva esto dentro desde antes.)"

    if estado_minimo("amor", 30):
        n "Y sin embargo, no sonríe. No puede."
        na "(¿Por qué no sonríe?)"
        na "(Yo sonrío siempre. Aunque no quiera.)"

    if estado_minimo("miedo", 60):
        n "Tú sí sonríes. No puedes evitarlo."
        na "(Me tiembla la boca.)"
        na "(No puedo dejar que lo note.)"

    if peso_tomado("cap6_confio_hiro"):
        na "(En el piso 6, Ayame confió en Hiro.)"
        na "(Y salió bien.)"

    elif peso_tomado("cap6_pregunto_hiro"):
        na "(En el piso 6, Ayame hizo preguntas.)"
        na "(Quizá debería hacer yo también.)"

    # ── Decisión 2 ──
    menu:
        "¿Cómo reaccionas?"

        "Preguntarle por qué no sonríe.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("nao_pregunta", True)
            $ registrar_decision()

            na "¿Por qué no sonríes?"
            su "..."
            su "¿Qué?"
            na "No sonríes. Desde que te he visto."
            su "Es... una costumbre."
            na "¿Una costumbre?"
            su "Sí."
            su "No sonreír ayuda."
            na "¿A quién?"
            su "..."
            su "A mí."
            na "(No me lo cree ni él.)"
            na "(Pero no insisto.)"

        "Contarle que has oído risas.":
            $ modificar_metrica("amor", +10)
            $ modificar_metrica("miedo", +5)
            $ gtn_flag("nao_cuenta", True)
            $ registrar_decision()

            na "He oído risas."
            su "¿El qué?"
            na "Risas. Muchas. Lejanas."
            su "..."
            su "Yo no he oído nada."
            na "Ya lo sé."
            na "No las oirías aunque quisieras."
            su "¿Y por qué tú sí?"
            na "..."
            na "No quiero hablar de eso."
            su "Vale. No hablamos."
            na "(Y por primera vez, me ha mirado de verdad.)"

        "Confiar en él directamente.":
            $ modificar_metrica("amor", +15)
            $ modificar_metrica("miedo", -5)
            $ gtn_flag("nao_confia", True)
            $ registrar_decision()

            na "Vale. Confío en ti."
            su "..."
            su "¿Así, sin más?"
            na "No tengo mucho donde elegir."
            n "Souta no sonríe. Pero algo en su cara se ablanda."
            na "(No sonríe. Pero tampoco huye.)"
            na "(Y eso, para mí, ya es mucho.)"

    if gtn_flag("nao_confia"):
        su "Me alegra que confíes en mí."
        su "Aunque no deberías."
        na "¿Qué?"
        su "Nada. Olvídalo."
        na "(Ha dicho algo importante.)"
        na "(Pero no lo ha dicho.)"

    if estado_minimo("amor", 40) and estado_minimo("miedo", 40):
        na "(Le he dicho que confío en él.)"
        na "(Y es verdad. Pero también me da miedo.)"
        na "(Me da miedo que confiar en alguien salga mal.)"
        na "(Como siempre.)"

    if estado_extremo("odio"):
        na "(No debería odiarlo.)"
        na "(Ni siquiera lo conozco.)"
        na "(Pero hay algo en él que me irrita.)"
        na "(Como si todo le diera igual.)"

    if estado_minimo("angustia", 60):
        na "(Me pesa la cara.)"
        na "(Como si la sonrisa que llevo puesta no fuera mía.)"
        na "(Y no puedo quitármela.)"

    call cap07_flashback_nao_mascara
    call cap07_nota_souta_silencio

    # ═══════════════════════════════════════════════════════════
    #  OBJETO 1 — La máscara rota
    # ═══════════════════════════════════════════════════════════

    n "En el centro del círculo, entre el serrín, algo brilla."
    n "Una máscara. Blanca. Rota."
    n "Y no es una máscara cualquiera."

    call screen cap07_mascara_interactivo
    call cap07_pulsar_mascara

    # ═══════════════════════════════════════════════════════════
    #  ACTO 3 — LA EXPLORACIÓN
    # ═══════════════════════════════════════════════════════════

    n "La carpa es más grande de lo que parecía."
    n "Hay tres zonas."
    n "Y en cada una, algo os espera."

    $ musica("tension_baja", fade=2.0)

    $ zonas_exploradas = []
    call cap07_exploracion
    jump cap07_tras_exploracion


# ═══════════════════════════════════════════════════════════════
#  TRAS LA EXPLORACIÓN
# ═══════════════════════════════════════════════════════════════
label cap07_tras_exploracion:
    scene bg_piso7_carpa
    with fade

    show nao_img at left
    show souta_img at right
    with dissolve

    n "Volvéis al centro de la carpa."
    n "Pero algo ha cambiado."
    n "El foco sigue encendido. Pero ahora hay público."
    n "En las gradas. Silencioso."
    n "Sin cara."
    n "Esperando."

    if peso_tomado("cap6_cogio_mano"):
        n "Y por un momento, recuerdas algo."
        n "Dos figuras cruzaron por aquí. Una chica y un chico."
        n "Juntos. Cogidos de la mano."
        na "(¿Quiénes eran?)"
        na "(No los conozco.)"
        na "(Pero creo que los he visto en algún sitio.)"

    elif peso_tomado("cap6_confio_hiro"):
        n "Y por un momento, recuerdas algo."
        n "Alguien dijo algo importante aquí. Antes."
        n "Y no llegó a terminar la frase."
        na "(¿Qué dijo?)"
        na "(¿Por qué lo recuerdo?)"

    su "Eso no estaba antes."
    na "Ya lo veo."
    su "¿Y ahora qué?"
    na "..."
    na "Ahora sonrío."

    n "Y sonríes. Sin querer."
    n "Y el público, al unísono, aplaude."
    n "Una sola vez."

    $ aprender_palabra("torre", "publico_rie")
    $ desbloquear_pista("torre", "p7_publico_rie")
    call cap07_nota_publico

    call cap07_flashback_souta_huida
    call cap07_nota_huida
    call cap07_deduccion_1

    # ── Sala de los espejos ──
    scene bg_piso7_espejos
    with fade

    show nao_img at left
    show souta_img at right
    with dissolve

    n "Al fondo de la carpa, una sala llena de espejos."
    n "Docenas. Todos deformes."
    n "Y todos reflejando algo distinto."

    su "No me gustan los espejos."
    na "¿Por qué?"
    su "Porque reflejan lo que hay."
    na "..."
    na "¿Y qué hay?"
    su "..."
    su "No lo sé. Por eso no me gustan."

    n "Y entonces, en uno de los espejos, ves algo."
    n "Una figura. Blanca. Con máscara."
    n "Que no eres tú."
    n "Pero que se mueve cuando tú te mueves."

    $ aprender_palabra("torre", "espejo_deformante")
    $ desbloquear_pista("torre", "p7_espejo_nao")
    call cap07_nota_espejos

    if estado_extremo("terror"):
        na "(Son muchos. Demasiados.)"
        na "(Y todos me miran.)"
        n "Te llevas las manos a la cara."
        su "Nao. Nao, mírame."
        na "Estoy bien."
        su "No. No lo estás."
        n "Y por primera vez, no sabes qué contestar."

    if estado_minimo("amor", 50):
        su "Sea lo que sea que veas..."
        su "No estás sola."
        na "..."
        na "(No estoy sola.)"
        na "(Pero tampoco sé qué hacer con eso.)"

    if estado_minimo("odio", 50):
        na "(No quiero que me vea así.)"
        na "(No quiero que nadie me vea así.)"
        n "Te apartas un poco de Souta. Sin darte cuenta."
        su "..."
        n "Souta no dice nada. Pero lo nota."

    na "Souta. ¿Estás viendo eso?"
    su "..."
    su "No."
    na "Mentira."
    su "..."
    su "Sí."
    su "Pero no quiero verlo."

    call cap07_eco_2

    # ═══════════════════════════════════════════════════════════
    #  ACTO 4 — LA VOZ DEL CIRCO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso7_carpa
    with fade

    show nao_img at left
    show souta_img at right
    with dissolve

    n "Y entonces, el público habla."
    n "No aplaude. Habla."
    n "Con una voz que no es de nadie."
    n "Pero que suena como alguien."

    $ sonido("publico_rie")

    n "Y dice:"
    n "«Souta.»"

    su "..."
    na "Souta. ¿Qué pasa?"
    su "Nada."
    na "El público ha dicho tu nombre."
    su "Ya. Pero no pasa nada, ¿vale?"
    na "Souta. No pasa nada."
    su "..."
    su "¿Qué?"
    na "Que no pasa nada."
    na "El público también te ha llamado a ti."
    su "..."
    su "¿Y qué quiere?"
    na "..."
    na "Quiere que le cuentes lo de la huida."

    n "Souta se queda en silencio."
    n "Y por primera vez, no mira al frente."
    n "Mira al suelo."

    call cap07_deduccion_2

    # ── OBJETO 2 — La caja de música ──
    n "En el vestuario, sobre una cómoda, hay una caja de música."
    n "Cerrada. Pero con la llave puesta."
    n "Y con un nombre grabado."

    call screen cap07_caja_interactivo
    call cap07_pulsar_caja

    # ── LOGROS ACUMULATIVOS ──
    if gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido") and gtn_flag("eco_3_oido"):
        $ add_achievement_with_popup(achievement_eco_completo_cap7)

    if gtn_flag("fb_nao_visto") and gtn_flag("fb_souta_visto"):
        $ add_achievement_with_popup(achievement_recuerdos_cap7)

    if notas_descubiertas_cap("torre", 7) >= 5:
        $ add_achievement_with_popup(achievement_notas_completas_cap7)

    if objeto_visto("mascara_rota") and objeto_visto("caja_musica"):
        $ add_achievement_with_popup(achievement_objetos_cap7)

    if deduccion_jugador_acertada("cap07_ded1") and deduccion_jugador_acertada("cap07_ded2"):
        $ add_achievement_with_popup(achievement_deducciones_cap7)

    if not gtn_flag("grito_alguna_vez"):
        $ add_achievement_with_popup(achievement_oculto_no_grito)

    if gtn_ecos_oidos >= 21:
        $ add_achievement_with_popup(achievement_oculto_oyo_todo)

    if gtn_puertas_pulsadas >= 8:
        $ add_achievement_with_popup(achievement_oculto_puertas)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 5 — LA PUERTA AL FONDO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso7_salida    with fade

    show nao_img at left
    show souta_img at right
    with dissolve

    n "Al fondo de la carpa, detrás del círculo, hay una puerta."
    n "De madera. Vieja."
    n "Con una estrella pintada. Descolorida."
    n "Y una luz cálida al otro lado."

    na "Es la salida."
    su "¿Y si no lo es?"
    na "Entonces volvemos. Pero contigo."

    n "Souta se queda quieto un momento."
    n "Mira al público. Que sigue ahí."
    n "Y luego te mira a ti."

    su "Nao."
    na "¿Sí?"
    su "He mentido."
    na "Ya lo sé."
    su "¿Y no me preguntas por qué?"
    na "No hace falta."
    na "Cuando quieras contarlo, lo contarás."

    n "Souta no dice nada."
    n "Pero por primera vez, no aparta la mirada."

    $ desbloquear_pista("torre", "p7_puerta_al_fondo")
    call cap07_nota_puerta
    call cap07_eco_3

    # ═══════════════════════════════════════════════════════════
    #  MINIJUEGO — TIMING CON MÚSICA (aplausos del público)
    # ═══════════════════════════════════════════════════════════

    $ musica("tension_alta", fade=0.5)

    n "La puerta no se abre sola."
    n "Necesita que alguien escuche."
    n "Los aplausos. En orden."
    n "Pulsar en el momento justo."

    su "Nao."
    su "Tú puedes. Yo no puedo oírlos."
    su "Pero tú sí."

    if estado_extremo("miedo"):
        na "(No puedo. No puedo hacerlo.)"
        na "(Voy a fallar. Voy a fallar.)"
        n "Te tiemblan las manos."
        su "Nao. Mírame."
        na "..."
        su "Vas a pulsar en el momento justo. Y yo voy a salir contigo. ¿Vale?"
        na "(¿Por qué confía en mí?)"
        na "(No debería.)"

    if estado_minimo("terror", 60):
        na "(Los aplausos son demasiados.)"
        na "(No voy a oírlos todos.)"
        na "(Lo sé.)"

    # Reutilizamos timing con parámetros distintos
    call lanzar_timing(velocidad=1.5, zona_buena=0.11)

    if gtn_minijuego_resultado:
        $ registrar_minijuego(True)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Pulsas en el momento justo."
        n "Los aplausos suenan en orden."
        n "Y la puerta se abre."
        n "Al otro lado, la luz."
        n "Pero la puerta empieza a cerrarse."

        $ modificar_metrica("amor", +20)
        $ modificar_metrica("miedo", -5)

        na "¡Vamos!"

        menu:
            "¿Qué haces?"

            "Salir juntos, corriendo.":
                $ registrar_decision()
                $ registrar_peso("cap7_cogio_mano")
                jump cap7_final_bueno

            "Sacrificarte tú, para que él salga.":
                $ registrar_decision()
                jump cap7_final_souta_muere

            "Dejar que él se sacrifique, para que salgas tú.":
                $ registrar_decision()
                jump cap7_final_nao_muere

            "Cogerle la mano antes de cruzar." if estado_minimo("amor", 70) and estado_maximo("miedo", 40):
                $ modificar_metrica("amor", +15)
                $ gtn_flag("nao_cogio_mano", True)
                $ registrar_decision()
                $ registrar_peso("cap7_cogio_mano")

                na "Souta."
                su "¿Sí?"
                n "No dices nada. Solo le coges la mano."
                n "Souta no se aparta."
                n "Y los dos cruzáis la puerta juntos."
                jump cap7_final_bueno_especial
    else:
        $ registrar_minijuego(False)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Los aplausos no suenan."
        n "La puerta tiembla."
        n "Y el público se levanta."

        $ musica("final_malo", fade=1.0)
        jump cap7_final_ambos_quedan


# ═══════════════════════════════════════════════════════════════
#  FINALES DEL CAPÍTULO 7
# ═══════════════════════════════════════════════════════════════

label cap7_final_bueno:
    scene bg_piso7_salida
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    na "¡Juntos!"
    su "¡Juntos!"
    n "Corréis los dos hacia la puerta."
    n "La cruzéis al mismo tiempo."

    $ musica("final_bueno", fade=2.0)
    scene cap7_final_bueno
    with Dissolve(1.5)

    n "La luz os traga."
    n "Y luego, silencio."
    n "Detrás de vosotros, el público se desvanece."
    n "Y el foco, por fin, se apaga."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 7 superado."

    $ registrar_final_bueno()
    $ registrar_ruta(7, "bueno")
    $ guardar_estados_capitulo(7, "torre")
    $ unlock_final("torre", 7, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap7)
    $ add_achievement_with_popup(achievement_cap7_completado)
    $ desbloquear_imagen_galeria("cap7_bueno")
    $ capitulos.completar_capitulo("torre", 7)
    call marcar_final_bueno_cap(7, "torre")
    $ desbloquear_invocaciones_hasta(7)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("nao_confia"):
        $ registrar_peso("cap7_confio_souta")
    if gtn_flag("nao_pregunta"):
        $ registrar_peso("cap7_pregunto_souta")

    "Capítulo 7 completado."
    jump volver_al_hub


label cap7_final_bueno_especial:
    scene bg_piso7_salida
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    n "Cruzasteis juntos. Con las manos cogidas."
    n "Y al otro lado, por primera vez, no había silencio."
    n "Había una puerta abierta. Y detrás, luz."

    $ musica("final_bueno", fade=2.0)
    scene cap7_final_especial
    with Dissolve(1.5)

    n "Pero no era la salida."
    n "Era otra cosa."
    n "Era el inicio de algo que ninguno de los dos había previsto."
    n "Y Nao, por primera vez, no llevaba máscara."
    n "Ni siquiera la que siempre lleva puesta."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 7 superado. Pero no del todo."

    $ registrar_final_bueno()
    $ registrar_ruta(7, "bueno_especial")
    $ registrar_peso("cap7_cogio_mano")
    $ guardar_estados_capitulo(7, "torre")
    $ unlock_final("torre", 7, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap7)
    $ add_achievement_with_popup(achievement_cap7_completado)
    $ add_achievement_with_popup(achievement_final_especial_cap7)
    $ desbloquear_imagen_galeria("cap7_bueno")
    $ capitulos.completar_capitulo("torre", 7)
    call marcar_final_bueno_cap(7, "torre")
    $ desbloquear_invocaciones_hasta(7)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("nao_confia"):
        $ registrar_peso("cap7_confio_souta")
    if gtn_flag("nao_pregunta"):
        $ registrar_peso("cap7_pregunto_souta")

    "Capítulo 7 completado (ruta especial)."
    jump volver_al_hub


label cap7_final_nao_muere:
    scene bg_piso7_salida
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    su "Nao, espera—"
    na "Es mi turno."
    n "Souta cruza."
    n "Tú te quedas. Mirando al público."
    n "Que ya no aplaude."
    n "Solo espera."
    na "..."
    na "Vale. Ya voy."
    n "Y la puerta se cierra."

    $ musica("final_malo", fade=1.5)
    scene cap7_final_nao_muere
    with Dissolve(1.0)

    n "Al otro lado, Souta se queda solo."
    n "Al fondo de la carpa."
    n "Con una máscara en la mano."
    n "Que no es suya."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El público se sienta."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(7, "nao_muere")
    $ guardar_estados_capitulo(7, "torre")
    $ unlock_final("torre", 7, "nao_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap7_completado)
    $ desbloquear_imagen_galeria("cap7_nao_muere")
    $ capitulos.completar_capitulo("torre", 7)
    $ desbloquear_invocaciones_hasta(7)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("nao_confia"):
        $ registrar_peso("cap7_confio_souta")
    if gtn_flag("nao_pregunta"):
        $ registrar_peso("cap7_pregunto_souta")

    "Capítulo 7 completado (final malo)."
    jump volver_al_hub


label cap7_final_souta_muere:
    scene bg_piso7_salida
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    na "Ve tú. Yo me quedo."
    su "Ni hablar."
    na "Es una orden."
    su "..."
    su "No eres mi jefa."
    na "Pero soy la que escucha."
    n "Y te sacrificas. Y Souta cruza."

    $ musica("final_malo", fade=1.5)
    scene cap7_final_souta_muere
    with fade

    n "Al otro lado, Nao se queda sola."
    n "Sin sonrisa."
    n "Con una caja de música en la mano."
    n "Que no es suya."
    n "Y con la voz de Souta, muy baja."
    n "Que dice: «No pasa nada, ¿vale?»."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El público se sienta. Pero no del todo."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(7, "souta_muere")
    $ guardar_estados_capitulo(7, "torre")
    $ unlock_final("torre", 7, "souta_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap7_completado)
    $ desbloquear_imagen_galeria("cap7_souta_muere")
    $ capitulos.completar_capitulo("torre", 7)
    $ desbloquear_invocaciones_hasta(7)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("nao_confia"):
        $ registrar_peso("cap7_confio_souta")
    if gtn_flag("nao_pregunta"):
        $ registrar_peso("cap7_pregunto_souta")

    "Capítulo 7 completado (final malo)."
    jump volver_al_hub


label cap7_final_ambos_quedan:
    scene bg_piso7_carpa
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    n "El público se levanta."
    n "Y vosotros os quedáis."
    n "Sentados en el borde del círculo."
    n "Sin hablar."
    n "Solo mirando."
    n "Y el público, por fin, empieza a aplaudir."

    $ musica("final_malo", fade=1.0)
    scene cap7_final_ambos
    with fade

    n "Con las máscaras. Con las risas."
    n "Con los espejos."
    n "Y con vosotros."
    n "Que ya no sois vosotros."
    n "Sois parte del público."
    n "Que alguien verá."
    n "Algún día."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "La carpa se llena."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(7, "ambos_quedan")
    $ guardar_estados_capitulo(7, "torre")
    $ unlock_final("torre", 7, "ambos_quedan")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap7_completado)
    $ desbloquear_imagen_galeria("cap7_ambos")
    $ capitulos.completar_capitulo("torre", 7)
    $ desbloquear_invocaciones_hasta(7)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("nao_confia"):
        $ registrar_peso("cap7_confio_souta")
    if gtn_flag("nao_pregunta"):
        $ registrar_peso("cap7_pregunto_souta")

    "Capítulo 7 completado (final malo)."
    jump volver_al_hub


label cap7_final_secreto:
    scene bg_piso7_carpa
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    na "Ve tú. Yo me quedo."
    su "¡No!"
    na "Confía en mí."
    n "Empujas a Souta hacia la puerta."
    n "Pero no te quedas atrás."
    n "Te acercas al público."
    n "Y te sientas con ellos."

    $ musica("final_malo", fade=1.5)
    scene cap7_final_secreto
    with fade

    n "La puerta se cierra detrás de Souta."
    n "Y tú te quedas."
    n "Pero no muerta."
    n "Te quedas... sonriendo."
    n "Y el público, por primera vez, te responde."
    n "Con una voz que no es de nadie."
    n "Pero que suena como alguien."
    n "Y dice: «Bienvenida»."

    $ sonido("publico_rie")
    elyon_voz "{i}Bienvenida, Nao.{/i}"

    n "Y el público, en el fondo, tiene una cara."
    n "Y la cara es tuya."
    n "Pero no eres tú."
    n "Todavía."

    scene black
    with fade
    $ parar_todo(fade=2.0)

    $ registrar_final_malo()
    $ registrar_ruta(7, "secreto")
    $ guardar_estados_capitulo(7, "torre")
    $ unlock_final("torre", 7, "secreto")
    $ add_achievement_with_popup(achievement_cap7_completado)
    $ add_achievement_with_popup(achievement_primera_ruta)
    $ desbloquear_imagen_galeria("cap7_secreto")
    $ capitulos.completar_capitulo("torre", 7)
    $ desbloquear_invocaciones_hasta(7)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("nao_confia"):
        $ registrar_peso("cap7_confio_souta")
    if gtn_flag("nao_pregunta"):
        $ registrar_peso("cap7_pregunto_souta")

    "Capítulo 7 completado (ruta secreta)."
    jump volver_al_hub


# ═══════════════════════════════════════════════════════════════
#  EXPLORACIÓN CON FLECHAS
# ═══════════════════════════════════════════════════════════════
label cap07_exploracion:

    call screen cap07_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap07_zona1

    call screen cap07_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap07_zona2

    call screen cap07_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap07_zona3

    return


screen cap07_exploracion_screen(zonas):
    modal True
    add "bg_piso7_despertar"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20

        text "EXPLORA LA CARPA" size 30 color "#FFFFFF" xalign 0.5
        text "Zonas exploradas: [len(zonas)] / 3" size 18 color "#AAAAAA" xalign 0.5
        null height 20

        vbox:
            spacing 30
            xalign 0.5

            if 1 not in zonas:
                textbutton "→ Explorar la SALA DE LOS ESPEJOS" action Return(1) style "menu_button" xalign 0.5
            else:
                text "✔ Sala de los espejos (explorado)" size 16 color "#666" xalign 0.5

            if 2 not in zonas:
                textbutton "↑ Explorar el VESTUARIO" action Return(2) style "menu_button" xalign 0.5
            else:
                text "✔ Vestuario (explorado)" size 16 color "#666" xalign 0.5

            if 3 not in zonas:
                textbutton "↓ Volver a la CARPA" action Return(3) style "menu_button" xalign 0.5
            else:
                text "✔ Carpa (explorado)" size 16 color "#666" xalign 0.5


label cap07_zona1:
    scene bg_piso7_espejos
    with fade
    show nao_img at left
    with dissolve

    n "La sala de los espejos es circular."
    n "Y todos los espejos están deformados."
    n "Cada uno refleja algo distinto."

    na "..."
    na "Son muchos."

    show souta_img at right
    with dissolve

    su "¿Qué ves?"
    na "A mí. Pero no soy yo."
    su "¿Y qué eres?"
    na "..."
    na "Alguien que sonríe."
    su "..."
    su "Eso no me gusta."
    na "A mí tampoco."

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    return


label cap07_zona2:
    scene bg_piso7_vestuario
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    n "El vestuario está en silencio."
    n "Docenas de máscaras de payaso."
    n "Todas colgadas. Todas mirando."
    n "Y una está rota. En el suelo."
    n "Con un nombre."

    su "¿Y esa?"
    na "Está rota."
    su "¿Y eso qué significa?"
    na "..."
    na "Que alguien ha dejado de sonreír."
    su "..."
    su "No me gusta eso."

    $ desbloquear_pista("torre", "p7_mascara_rota")
    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("terror", +5)

    return


label cap07_zona3:
    scene bg_piso7_carpa
    with fade
    show nao_img at left
    show souta_img at right
    with dissolve

    n "La carpa está llena."
    n "Pero no de gente."
    n "De público."
    n "Que espera."
    n "Y que no respira."

    su "¿Los ves?"
    na "Sí."
    su "¿Qué son?"
    na "..."
    na "Público."
    su "¿Y qué esperan?"
    na "Que empecemos la función."
    su "..."
    su "¿Y cuándo empieza?"
    na "..."
    na "Cuando yo sonría."
    su "..."
    su "Entonces no sonrías."
    na "..."
    na "No puedo evitarlo."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)

    return