# ═══════════════════════════════════════════════════════════════
#  56cap07_deducciones.rpy — Deducciones del Capítulo 7
#  -----------------------------------------------------------------
#  2 momentos donde el jugador debe deducir algo.
#  Acertar → recompensa (pista al tablón + marca deducción).
#  Fallar → nada.
#
#  ⚠️ Reutilizamos el screen `deduccion_screen` (definido en
#     50cap01_deducciones.rpy).
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 1 — ¿Por qué el público aplaude?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 3, después del flashback de Souta.
#  Pregunta: ¿Por qué crees que el público aplaude?
#  Respuesta correcta: "Porque se alimenta de risas forzadas."
# ═══════════════════════════════════════════════════════════════
label cap07_deduccion_1:

    n "..."

    n "Nao se queda callada un momento."

    n "Y el público, en las gradas, sigue esperando."

    naop "(Aplauden.)"
    naop "(Pero no dicen nada.)"
    naop "(Solo aplauden.)"
    naop "(¿Por qué aplauden?)"

    # ── Deducción interactiva ──
    call screen deduccion_screen(
        pregunta="¿Por qué crees que el público aplaude?",
        opciones=[
            "Porque está encantado. Como la carpa.",
            "Porque se alimenta de risas forzadas.",
            "Porque quiere avisarnos de algo."
        ],
        correcta=1,
        pista_ok="El público no está encantado. Ni avisa de nada. Tiene hambre. Y come risas forzadas. Cada vez que alguien sonríe sin querer, el público se alimenta. Y crece.",
        pista_fallo="No está encantado. Ni avisa. Tiene hambre. Y come risas forzadas. Las risas de todos los que han pasado por aquí.",
        pista_key="p7_publico_rie",
        clave_ded="cap07_ded1"
    )

    if deduccion_jugador_acertada("cap07_ded1"):
        $ add_achievement_with_popup(achievement_primera_deduccion)

    return


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 2 — ¿Por qué Souta no soporta el silencio?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 4, después del eco 2.
#  Pregunta: ¿Por qué crees que Souta no soporta el silencio?
#  Respuesta correcta: "Porque el silencio es lo que dejó atrás."
# ═══════════════════════════════════════════════════════════════
label cap07_deduccion_2:

    n "Souta se queda en silencio."

    n "Y el público, por primera vez, no dice su nombre."

    n "Dice otra cosa."

    n "Dice: «Nadie te llamó»."

    sop "(No.)"
    sop "(Nadie me llamó.)"
    sop "(Yo me fui.)"
    sop "(Yo.)"

    naop "(Dice que nadie le llamó.)"
    naop "(Pero él no lo cree.)"
    naop "(¿Y si el público tiene razón?)"

    # ── Deducción interactiva ──
    call screen deduccion_screen(
        pregunta="¿Por qué crees que Souta no soporta el silencio?",
        opciones=[
            "Porque tiene miedo de la oscuridad. Como todos.",
            "Porque el silencio es lo que dejó atrás.",
            "Porque alguien le hizo daño en el pasado."
        ],
        correcta=1,
        pista_ok="El público no miente. Nadie le llamó. Souta se fue por su cuenta. Pero el silencio de esa casa es lo que se llevó consigo. Y desde entonces, no puede estar en silencio. Porque el silencio es volver.",
        pista_fallo="Souta no tiene miedo de la oscuridad. Tiene miedo del silencio. Porque el silencio es la casa que dejó atrás. Y volver sería reconocer que se equivocó.",
        pista_key="p7_souta_oidos",
        clave_ded="cap07_ded2"
    )

    if deduccion_jugador_acertada("cap07_ded2"):
        $ add_achievement_with_popup(achievement_segunda_deduccion)

    return