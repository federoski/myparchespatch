# Archivo de prueba del updater
# Si ves este archivo después de aplicar el parche, significa que el sistema funciona.

init python:
    print("✅✅✅ UPDATER TEST: Archivo de parche instalado correctamente ✅✅✅")
    renpy.notify("✅ Parche de prueba instalado")