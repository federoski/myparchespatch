# ═══════════════════════════════════════════════════════════════
#  52cap03_notas.rpy — Notas de Hana (Capítulo 3)
#  -----------------------------------------------------------------
#  Apuntes que Hana escribe durante el capítulo.
#  Se añaden al sistema de notas existente (50cap01_notas.rpy).
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Añadir las notas del Cap 3 al catálogo existente ──
    if "torre" not in NOTAS:
        NOTAS["torre"] = {}

    NOTAS["torre"].update({
        "nota3_aplauso": {
            "titulo": "El aplauso sin público",
            "icono": "👏",
            "capitulo": 3,
            "texto": (
                "No hay nadie en las butacas. Solo siluetas que no se mueven. "
                "Y sin embargo, aplauden. No sé de dónde viene el sonido. No sé "
                "si son ellas. Pero cada vez que aplauden, siento que me miran. "
                "Y cada vez que dejan de aplaudir, siento que se preparan para "
                "algo peor."
            ),
        },
        "nota3_programa": {
            "titulo": "El programa de mano",
            "icono": "📄",
            "capitulo": 3,
            "texto": (
                "El programa está arrugado. Amarillento. Dice el nombre de una obra "
                "que nunca existió. Y debajo, escrito a mano, con la misma letra que "
                "las marcas de la torre: «no la dejes sola». "
                "No sé qué significa. Pero lo he leído tres veces. "
                "Y las tres veces me ha dado el mismo escalofrío."
            ),
        },
        "nota3_camerino": {
            "titulo": "El camerino del espejo roto",
            "icono": "🪞",
            "capitulo": 3,
            "texto": (
                "En uno de los camerinos hay un espejo roto. Y una silla vacía. "
                "Y nada más. Pero hay algo en el aire. Un olor a perfume viejo. "
                "A flores secas. Como si alguien hubiera estado aquí hace poco. "
                "Como si todavía estuviera. Y solo se escondiera cuando entro."
            ),
        },
        "nota3_butacas": {
            "titulo": "Las butacas vacías",
            "icono": "🪑",
            "capitulo": 3,
            "texto": (
                "Cuando bajamos al patio de butacas, algunas siluetas habían desaparecido. "
                "No se habían movido. No se habían ido. Simplemente, ya no estaban. "
                "Como si alguien las hubiera borrado. O como si nunca hubieran estado. "
                "No sé qué es peor."
            ),
        },
        "nota3_telon": {
            "titulo": "El telón",
            "icono": "🎭",
            "capitulo": 3,
            "texto": (
                "El telón no se abre. Eso dicen todos los carteles. Pero yo lo he visto "
                "subido. Y Kaito también. Y cuando baja, algo detrás se cierra. Algo que "
                "no debería cerrarse. El telón no es tela. Es una puerta. "
                "Y las puertas se cierran para que no pase algo. O para que no salga algo."
            ),
        },
    })


# ═══════════════════════════════════════════════════════════════
#  LABELS DE LLAMADA — Notas del Cap 3
# ═══════════════════════════════════════════════════════════════

# ── Nota: el aplauso ──
label cap03_nota_aplauso:
    n "..."

    hap "(Debería apuntar esto.)"
    hap "(Antes de que se me olvide.)"

    $ desbloquear_nota("torre", "nota3_aplauso")

    n "Sacas un bolígrafo del bolsillo. No recuerdas tenerlo."

    n "Pero lo tienes. Y escribes en la palma de la mano."

    return


# ── Nota: el programa ──
label cap03_nota_programa:
    $ desbloquear_nota("torre", "nota3_programa")
    return


# ── Nota: el camerino ──
label cap03_nota_camerino:
    $ desbloquear_nota("torre", "nota3_camerino")
    return


# ── Nota: las butacas ──
label cap03_nota_butacas:
    $ desbloquear_nota("torre", "nota3_butacas")
    return


# ── Nota: el telón ──
label cap03_nota_telon:
    $ desbloquear_nota("torre", "nota3_telon")
    return