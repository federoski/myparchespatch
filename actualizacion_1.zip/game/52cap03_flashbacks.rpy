# ═══════════════════════════════════════════════════════════════
#  52cap03_flashbacks.rpy — Flashbacks del Capítulo 3
#  -----------------------------------------------------------------
#  2 escenas del pasado de Hana y Kaito.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES PARA FLASHBACKS
# ─────────────────────────────────────────────────────────────

# Hana en flashback (voz más joven, más frágil)
define hap_old = Character(
    "Hana",
    color="#f48fb1",
    what_color="#f0d8e0",
    what_italic=True,
    what_size=28
)

# Kaito en flashback (voz más joven, antes de la dureza)
define kap_old = Character(
    "Kaito",
    color="#ef5350",
    what_color="#f0d0d0",
    what_italic=True,
    what_size=28
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE FLASHBACK
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Cuarto de Hana y su hermana (flashback)
# Archivo: images/fondos/cap03/flash_hana_cuarto.png
# Prompt: Anime dark psychological horror scene, soft melancholic
#         tone. A children's bedroom with two small beds side by
#         side. On the walls, drawings of flowers and butterflies
#         (childish). A window with soft light coming through,
#         dust floating in the air. On one of the beds, an empty
#         space where someone used to sleep. On the other, a small
#         girl's silhouette sitting alone. Atmosphere: intimate
#         grief, an absence that never leaves. Muted warm palette,
#         sepia tone. 16:9, no text, no watermark.
# image bg_flash_hana_cuarto = "images/fondos/cap03/flash_hana_cuarto.png"
image bg_flash_hana_cuarto = Solid("#4a3028")

# 🎨 PROMPT IMAGEN — Callejón de noche (flashback de Kaito)
# Archivo: images/fondos/cap03/flash_kaito_callejon.png
# Prompt: Anime dark psychological horror scene, melancholic tone.
#         A narrow urban alley at night. Wet asphalt reflecting the
#         dim light of a single broken streetlamp. On the ground,
#         a small object (a pocketknife or a phone) dropped,
#         slightly out of focus. In the background, a dark silhouette
#         walking away, blurred. On the wall, a small graffiti
#         of a name, scratched out. Atmosphere: guilt, silence
#         after something irreversible. Muted desaturated palette,
#         cold greys and deep blacks, one warm yellow light.
#         16:9, no text, no watermark.
# image bg_flash_kaito_callejon = "images/fondos/cap03/flash_kaito_callejon.png"
image bg_flash_kaito_callejon = Solid("#1a1a20")


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 1 — Hana y su hermana gemela
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Hana recuerda a su hermana. La que ya no está.
# ═══════════════════════════════════════════════════════════════
label cap03_flashback_hana_hermana:

    # ── Transición ──
    n "..."

    n "Y por un momento, dejas de estar aquí."

    scene bg_flash_hana_cuarto
    with Dissolve(1.0)

    # ── Indicador visual de flashback ──
    show screen flashback_overlay

    # ── Música de flashback ──
    $ musica("flashback_suave", fade=2.0)

    # ── Ambientación ──
    n "Tu cuarto. De pequeña."

    n "Dos camas. Una al lado de la otra."

    n "En las paredes, dibujos. Flores. Mariposas."

    n "Los hacía tu hermana. Tú los colgabas."

    hap_old "(Se llamaba Hana.)"
    hap_old "(Como yo.)"

    # ── Detalle clave ──
    n "La cama de al lado está vacía."

    n "Hace tiempo que está vacía."

    n "Pero tú todavía la haces todas las mañanas."

    hap_old "(Por si vuelve.)"
    hap_old "(Aunque sé que no va a volver.)"
    hap_old "(Pero si dejo de hacerla, es como si aceptara que no vuelve.)"

    # ── Conexión con el presente ──
    n "Y por eso nunca la dejaste de hacer."

    n "Ni siquiera ahora."

    n "Ni siquiera aquí, en la torre."

    hap_old "(Se llamaba Hana.)"
    hap_old "(Como yo.)"
    hap_old "(Y yo me llamo Hana porque ella ya no puede.)"

    # ── Frase final ──
    n "A veces, cuando te llamas a ti misma, no sabes si te estás llamando a ti."

    n "O la estás llamando a ella."

    # ── Métrica ──
    $ modificar_metrica("angustia", +4)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "hana")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso3_escenario
    with Dissolve(1.0)

    show hana_img at left
    show kaito_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al escenario. A Kaito."

    n "Kaito te está mirando."

    ka "¿Estás bien?"

    ha "Sí."

    ka "No lo parece."

    ha "..."

    ha "Es solo que..."

    ha "Este sitio me recuerda a alguien."

    ka "..."

    ka "A mí también."

    n "Y por un momento, los dos os quedáis en silencio."

    n "Pero es un silencio distinto. Un silencio compartido."

    # ── Flag ──
    $ gtn_flag("fb_hana_visto", True)

    return


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 2 — Kaito antes de la torre (barrio)
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Kaito recuerda la noche antes de la torre. La pelea.
# ═══════════════════════════════════════════════════════════════
label cap03_flashback_kaito_barrio:

    # ── Transición ──
    n "..."

    n "Kaito se ha quedado en silencio."

    n "Y por un momento, ves algo distinto en él."

    # ── Flashback ──
    scene bg_flash_kaito_callejon
    with Dissolve(1.0)

    show screen flashback_overlay

    $ musica("flashback_tension", fade=2.0)

    # ── Ambientación ──
    n "Un callejón. De noche."

    n "La lluvia ha parado hace poco."

    n "El suelo está mojado. Refleja la luz de una farola rota."

    kap_old "(Aquí terminó todo.)"
    kap_old "(O empezó. Ya no sé.)"

    # ── Detalle clave ──
    n "En el suelo, algo tirado."

    n "Un objeto pequeño. Algo que no quieres mirar."

    n "En la pared, un nombre. Arañado."

    n "Como si alguien hubiera querido borrarlo. Y no hubiera podido."

    kap_old "(No era mi intención.)"
    kap_old "(Pero eso da igual.)"
    kap_old "(Porque pasó.)"

    # ── Frase sin terminar ──
    n "Kaito no termina la frase."

    n "Se queda mirando el callejón."

    n "Y por un momento, parece más joven. Mucho más joven."

    kap_old "(Yo no quería ser así.)"
    kap_old "(Pero tuve que serlo.)"
    kap_old "(Porque si no era yo, era otro.)"

    # ── Conexión con el presente ──
    n "Esa fue la última noche antes de la torre."

    n "La última vez que golpeó a alguien sin saber si volvería a levantarse."

    n "Y la primera vez que se dio cuenta de que ya no podía parar."

    # ── Métrica ──
    $ modificar_metrica("angustia", +5)
    $ modificar_metrica("miedo", +3)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "kaito")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso3_camerinos
    with Dissolve(1.0)

    show hana_img at left
    show kaito_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al presente. A los camerinos."

    n "Kaito está mirando su propio reflejo en un espejo roto."

    n "Pero esta vez, su reflejo tarda un poco más en copiarle."

    ha "Kaito."

    ka "¿Sí?"

    ha "Te has quedado en blanco."

    ka "Solo estaba... pensando."

    n "Las mismas palabras que le has dicho tú antes."

    hap "(Ha usado mi frase.)"
    hap "(Como el eco.)"

    # ── Flag ──
    $ gtn_flag("fb_kaito_visto", True)

    return