# ═══════════════════════════════════════════════════════════════
#  50cap01_objetos.rpy — Objetos clicables del Capítulo 1
#  -----------------------------------------------------------------
#  2 objetos adicionales que el jugador puede pulsar.
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Persistencia de objetos vistos ──
    if not hasattr(persistent, "objetos_cap1_vistos") or persistent.objetos_cap1_vistos is None or isinstance(persistent.objetos_cap1_vistos, bool):
        persistent.objetos_cap1_vistos = {}

    def objeto_visto(clave):
        return persistent.objetos_cap1_vistos.get(clave, False)

    def marcar_objeto_visto(clave):
        persistent.objetos_cap1_vistos[clave] = True


# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE OBJETOS
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Símbolo en el suelo
# Archivo: images/objetos/cap01_simbolo_suelo.png
# Prompt: Anime dark psychological horror close-up: a strange symbol
#         carved into a concrete floor, seen from above. The symbol
#         is geometric, symmetrical, made of circular patterns and
#         cross-like marks. Faint traces of dried blood in the
#         grooves. The concrete around it is cracked. Dramatic
#         overhead lighting, deep shadows in the carved lines.
#         Atmosphere: occult, ancient, dreadful. Muted desaturated
#         palette, cold greys and dark reds. Anime style, 16:9
#         no text, no watermark.
image cap01_simbolo_suelo = "images/objetos/cap01_simbolo_suelo.png"

# 🎨 PROMPT IMAGEN — Puerta con grabados
# Archivo: images/objetos/cap01_puerta_grabados.png
# Prompt: Anime dark psychological horror close-up: a heavy metal
#         door seen straight on, covered in the same carved symbols
#         as the wall marks: irregular letters, circular patterns,
#         cross-like marks. The symbols glow faintly with a
#         pale red light from within, as if something behind the
#         door is illuminating them. The door handle is missing.
#         Atmosphere: forbidden, dreadful, the feeling that
#         opening it would be a mistake. Muted desaturated palette,
#         cold metal, faint red glow. Anime style, 16:9, no text.
# image cap01_puerta_grabados = "images/objetos/cap01_puerta_grabados.png"
image cap01_puerta_grabados = Solid("#1f1a1a")   # placeholder


# ═══════════════════════════════════════════════════════════════
#  OBJETO 1 — SÍMBOLO EN EL SUELO
# ═══════════════════════════════════════════════════════════════
#  Aparece en el pasillo, cerca de la sala de la marca.
#  El jugador puede pulsarlo para descubrir una pista.
# ═══════════════════════════════════════════════════════════════
screen cap01_simbolo_suelo():
    modal True

    add "bg_piso1_pasillo"

    # ── Pista visual: pequeño símbolo en el suelo ──
    frame:
        xpos 0.55
        ypos 0.7
        xsize 150
        ysize 150
        background Solid("#222222")

        text "🔯":
            size 80
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.4)

    # ── Zona clicable sobre el símbolo ──
    button:
        xpos 0.55
        ypos 0.7
        xsize 150
        ysize 150
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa el símbolo del suelo":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  OBJETO 2 — PUERTA CON GRABADOS
# ═══════════════════════════════════════════════════════════════
#  Aparece justo antes de la decisión final.
#  El jugador puede pulsarla para descubrir una pista.
# ═══════════════════════════════════════════════════════════════
screen cap01_puerta_grabados():
    modal True

    add "bg_piso1_salida"

    # ── Pista visual: puerta con símbolos ──
    frame:
        xpos 0.35
        ypos 0.25
        xsize 400
        ysize 500
        background Solid("#1a1a1a")

        text "🔑":
            size 120
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.5)

    # ── Zona clicable sobre la puerta ──
    button:
        xpos 0.35
        ypos 0.25
        xsize 400
        ysize 500
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa la puerta":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  LABELS DE EFECTO AL PULSAR LOS OBJETOS
# ═══════════════════════════════════════════════════════════════

# ── Al pulsar el símbolo del suelo ──
label cap01_pulsar_simbolo:
    $ marcar_objeto_visto("simbolo_suelo")

    # Mostrar imagen del símbolo en grande
    show cap01_simbolo_suelo at truecenter
    with dissolve

    n "El símbolo está tallado en el suelo."

    n "Es simétrico. Geométrico. Hecho a propósito."

    # ── Aprender palabra ──
    $ aprender_palabra("torre", "simbolo_suelo")

    ak "..."

    ak "Ren. Mira esto."

    re "¿Otro símbolo?"

    ak "Este es distinto."

    ak "Es el mismo trazo que la marca de la pared. Los mismos arañazos."

    re "Entonces lo hizo la misma persona."

    ak "O la misma cosa."

    n "Ren se queda callado. Y eso, de alguna forma, es peor que si hubiera respondido."

    # ── Pista del tablón ──
    $ desbloquear_pista("torre", "p1_simbolo_suelo")

    # ── Nota ──
    call cap01_nota_simbolo from _call_cap01_nota_simbolo_1

    # ── Métrica ──
    $ modificar_metrica("miedo", +5)
    $ modificar_metrica("angustia", +8)

    hide cap01_simbolo_suelo
    with dissolve

    return


# ── Al pulsar la puerta con grabados ──
label cap01_pulsar_puerta:
    $ marcar_objeto_visto("puerta_grabados")

    # Mostrar imagen de la puerta
    show cap01_puerta_grabados at truecenter
    with dissolve

    n "La puerta tiene símbolos grabados."

    n "Los mismos que la pared. Los mismos que el suelo."

    # ── Aprender palabra ──
    $ aprender_palabra("torre", "puerta_cerrada")

    ak "Está cerrada."

    re "Sí."

    ak "Pero no tiene cerradura."

    re "..."

    ak "No tiene cerradura. ¿Cómo se supone que se abre?"

    re "Quizá no se abre."

    re "Quizá se queda cerrada. Para siempre."

    ak "..."

    ak "No."

    ak "No hemos llegado hasta aquí para quedarnos."

    n "Ren no responde. Pero tampoco discute."

    # ── Pista del tablón ──
    $ desbloquear_pista("torre", "p1_puerta_cerrada_simbolos")

    # ── Nota ──
    call cap01_nota_puerta_grabados from _call_cap01_nota_puerta_grabados_1

    # ── Métrica ──
    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +5)

    hide cap01_puerta_grabados
    with dissolve

    return