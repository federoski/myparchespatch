# ═══════════════════════════════════════════════════════════════
#  52cap03_eco.rpy — Apariciones de El·yon en el Capítulo 3
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  TRANSFORMS
# ─────────────────────────────────────────────────────────────
transform eco_elyon_efecto:
    alpha 0.0
    zoom 0.8
    yoffset 0
    easein 1.0 alpha 0.9 zoom 1.0 yoffset -20
    pause 0.5
    easeout 1.5 alpha 0.0 zoom 1.1 yoffset -60

transform eco_lateral_efecto:
    alpha 0.0
    xoffset -100
    easein 0.8 alpha 0.7 xoffset 0
    pause 1.2
    easeout 0.8 alpha 0.0 xoffset 100


# ─────────────────────────────────────────────────────────────
#  SCREENS
# ─────────────────────────────────────────────────────────────
screen eco_elyon_visual(texto="El·yon"):
    zorder 50

    text "{i}[texto]{/i}":
        size 80
        color "#8b0000"
        outlines [(3, "#000000", 0, 0), (6, "#440000", 0, 0)]
        xalign 0.5
        yalign 0.5
        at eco_elyon_efecto

    timer 3.5 action Hide("eco_elyon_visual")


screen eco_lateral_visual(texto="El·yon...", pos="izq"):
    zorder 50

    if pos == "izq":
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 0.0
            yalign 0.3
            xoffset 40
            at eco_lateral_efecto
    else:
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 1.0
            yalign 0.3
            xoffset -40
            at eco_lateral_efecto

    timer 3.0 action Hide("eco_lateral_visual")


# ═══════════════════════════════════════════════════════════════
#  ECO 1 — Muy sutil
# ═══════════════════════════════════════════════════════════════
label cap03_eco_1:

    n "Y entonces, muy lejos..."

    n "Algo."

    show screen eco_lateral_visual("El·yon...", pos="izq")

    $ sonido("elyon")

    n "Un susurro. Una sola palabra."

    n "Tan baja que casi no la oyes."

    pause 1.5

    hap "(¿Qué ha sido eso?)"
    hap "(Nada. Habrá sido el eco del teatro.)"
    hap "(...Pero este teatro no tiene eco.)"

    $ modificar_metrica("miedo", +3)

    $ desbloquear_relacion_elyon("torre", "hana")

    $ gtn_flag("eco_1_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 2 — Más notoria
# ═══════════════════════════════════════════════════════════════
label cap03_eco_2:

    pause 1.0

    n "..."

    n "El silencio se estira."

    n "Y entonces..."

    show screen eco_elyon_visual("No mires al público")

    $ sonido("elyon")

    n "La voz vuelve."

    n "Pero esta vez dice algo distinto."

    n "Repite lo que tú has pensado antes."

    if gtn_flag("hana_escucha"):
        elyon_voz "{i}...{/i}"
        hap "(Eso es mi silencio.)"
        hap "(Está imitando mi silencio.)"
    elif gtn_flag("hana_camina"):
        elyon_voz "{i}No mires.{/i}"
        hap "(Eso he pensado.)"
        hap "(Pero no lo he dicho.)"
    elif gtn_flag("hana_llama"):
        elyon_voz "{i}¿Hola?{/i}"
        hap "(Esa es mi voz.)"
        hap "(Esa es MI voz.)"

    ka "¿Hana? ¿Estás bien?"

    ha "Sí. Sí, estoy bien."

    ka "Te has quedado quieta."

    ha "Estaba... pensando."

    ka "Ya."

    n "Kaito no insiste. Pero te mira un segundo más de lo necesario."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)
    $ modificar_metrica("terror", +5)

    $ desbloquear_pista("torre", "p3_susurro_elyon")
    $ desbloquear_relacion_elyon("torre", "hana")

    $ gtn_flag("eco_2_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 3 — Clímax
# ═══════════════════════════════════════════════════════════════
label cap03_eco_3:

    if not (gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido")):
        return

    pause 1.5

    n "Antes de que puedas decidir..."

    n "La voz vuelve."

    n "Pero esta vez, no susurra."

    n "Habla."

    show screen eco_elyon_visual("¿Vas a dejarlo atrás?")

    $ sonido("elyon")

    elyon_voz "{i}¿Vas a dejarlo atrás?{/i}"
    elyon_voz "{i}Como hicieron conmigo.{/i}"

    pause 1.0

    n "Y el silencio."

    ha "..."
    ka "¿Hana?"
    ha "Nada. Vamos."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +10)

    $ desbloquear_relacion_elyon("torre", "hana")
    $ desbloquear_relacion_elyon("torre", "kaito")

    $ gtn_flag("eco_3_oido", True)

    # ── Peso: acumulación de ecos ──
    $ _total_ecos = 0
    if gtn_flag("eco_1_oido"):
        $ _total_ecos += 1
    if gtn_flag("eco_2_oido"):
        $ _total_ecos += 1
    if gtn_flag("eco_3_oido"):
        $ _total_ecos += 1

    if _total_ecos >= 3:
        n "Y por un momento, antes de que todo se desvanezca..."

        n "Oyes algo más. Muy bajo."

        elyon_voz "{i}Ya casi me conoces. Solo te falta el nombre.{/i}"

        hap "(¿El nombre?)"
        hap "(¿Qué nombre?)"

    $ gtn_ecos_oidos += 1

    return