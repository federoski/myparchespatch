# ═══════════════════════════════════════════════════════════════
#  51cap02_eco.rpy — Apariciones de El·yon en el Capítulo 2
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  TRANSFORMS
# ─────────────────────────────────────────────────────────────
transform eco_elyon_efecto:
    alpha 0.0
    zoom 0.8
    yoffset 0
    easein 1.0 alpha 0.9 zoom 1.0 yoffset -20
    pause 0.5
    easeout 1.5 alpha 0.0 zoom 1.1 yoffset -60

transform eco_lateral_efecto:
    alpha 0.0
    xoffset -100
    easein 0.8 alpha 0.7 xoffset 0
    pause 1.2
    easeout 0.8 alpha 0.0 xoffset 100


# ─────────────────────────────────────────────────────────────
#  SCREENS
# ─────────────────────────────────────────────────────────────
screen eco_elyon_visual(texto="El·yon"):
    zorder 50

    text "{i}[texto]{/i}":
        size 80
        color "#8b0000"
        outlines [(3, "#000000", 0, 0), (6, "#440000", 0, 0)]
        xalign 0.5
        yalign 0.5
        at eco_elyon_efecto

    timer 3.5 action Hide("eco_elyon_visual")


screen eco_lateral_visual(texto="El·yon...", pos="izq"):
    zorder 50

    if pos == "izq":
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 0.0
            yalign 0.3
            xoffset 40
            at eco_lateral_efecto
    else:
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 1.0
            yalign 0.3
            xoffset -40
            at eco_lateral_efecto

    timer 3.0 action Hide("eco_lateral_visual")


# ═══════════════════════════════════════════════════════════════
#  ECO 1 — Muy sutil
# ═══════════════════════════════════════════════════════════════
label cap02_eco_1:

    n "Y entonces, muy lejos..."

    n "Algo."

    show screen eco_lateral_visual(pos="der")

    $ sonido("elyon")

    n "Un susurro. Una sola palabra."

    n "Tan baja que casi no la oyes."

    pause 1.5

    yup "(¿Qué ha sido eso?)"
    yup "(Nada. Habrá sido el eco de mis propios pasos.)"
    yup "(...Pero yo no he dado ningún paso.)"

    $ modificar_metrica("miedo", +3)

    $ desbloquear_relacion_elyon("torre", "yuki")

    $ gtn_flag("eco_1_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 2 — Más notoria
# ═══════════════════════════════════════════════════════════════
label cap02_eco_2:

    pause 1.0

    n "..."

    n "El silencio se estira."

    n "Y entonces..."

    show screen eco_elyon_visual

    $ sonido("elyon")

    n "La voz vuelve."

    n "Pero esta vez dice algo distinto."

    n "Repite lo que tú has dicho antes."

    if gtn_flag("yuki_grito"):
        elyon_voz "{i}¿Hola?{/i}"
        yup "(Esa es mi voz.)"
        yup "(Esa es MI voz.)"
    elif gtn_flag("yuki_espejo_cerca"):
        elyon_voz "{i}Vale. Vale, tranquila.{/i}"
        yup "(Eso es lo que dije.)"
        yup "(Cuando me acerqué al espejo.)"
    elif gtn_flag("yuki_espejo_lejos"):
        elyon_voz "{i}No me gustan los espejos.{/i}"
        yup "(Eso dije.)"
        yup "(Pero con un tono distinto.)"

    so "¿Yuki? ¿Estás bien?"

    yu "Sí. Sí, estoy bien."

    so "Te has quedado quieta."

    yu "Estaba... pensando."

    so "Ya."

    n "Sora no insiste. Pero te mira un segundo más de lo necesario."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)
    $ modificar_metrica("terror", +5)

    $ desbloquear_pista("torre", "p2_eco_verdadero")
    $ desbloquear_relacion_elyon("torre", "yuki")

    $ gtn_flag("eco_2_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 3 — Clímax
# ═══════════════════════════════════════════════════════════════
label cap02_eco_3:

    if not (gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido")):
        return

    pause 1.5

    n "Antes de que puedas decidir..."

    n "La voz vuelve."

    n "Pero esta vez, no susurra."

    n "Habla."

    show screen eco_elyon_visual

    $ sonido("elyon")

    elyon_voz "{i}¿Vas a dejarla atrás?{/i}"
    elyon_voz "{i}Como hicieron conmigo.{/i}"

    pause 1.0

    n "Y el silencio."

    yu "..."
    so "¿Yuki?"
    yu "Nada. Vamos."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +10)

    $ desbloquear_relacion_elyon("torre", "yuki")
    $ desbloquear_relacion_elyon("torre", "sora")

    $ gtn_flag("eco_3_oido", True)
    $ gtn_ecos_oidos += 1

    return