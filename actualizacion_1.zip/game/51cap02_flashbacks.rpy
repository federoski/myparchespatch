# ═══════════════════════════════════════════════════════════════
#  51cap02_flashbacks.rpy — Flashbacks del Capítulo 2
#  -----------------------------------------------------------------
#  2 escenas del pasado de Yuki y Sora.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES PARA FLASHBACKS
# ─────────────────────────────────────────────────────────────

# Yuki en flashback (voz más joven, más frágil)
define yup_old = Character(
    "Yuki",
    color="#b39ddb",
    what_color="#d8d0e8",
    what_italic=True,
    what_size=28
)

# Sora en flashback (voz más calmada, antes del accidente)
define sop_old = Character(
    "Sora",
    color="#64b5f6",
    what_color="#b8d0e8",
    what_italic=True,
    what_size=28
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE FLASHBACK
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Casa de Yuki (flashback)
# Archivo: images/fondos/cap02/flash_yuki_casa.png
# Prompt: Anime dark psychological horror scene, soft melancholic
#         tone. The inside of a small family house at dusk. A
#         living room with warm but dull lights, family photos on
#         the walls (blurred faces), a dining table with three
#         plates set but only two chairs pulled out. A child's toy
#         on the floor. Atmosphere: intimate loneliness, being the
#         forgotten one. Muted warm palette, sepia tone. Anime
#         style, 16:9, no text, no watermark.
# image bg_flash_yuki_casa = "images/fondos/cap02/flash_yuki_casa.png"
image bg_flash_yuki_casa = Solid("#4a3020")

# 🎨 PROMPT IMAGEN — Piscina / Hospital de Sora (flashback)
# Archivo: images/fondos/cap02/flash_sora_piscina.png
# Prompt: Anime dark psychological horror scene, melancholic tone.
#         An empty swimming pool at night, still water reflecting
#         the ceiling lights. In the water, floating face down,
#         the silhouette of a young man — or the reflection of
#         one. Nobody around. On the edge of the pool, a single
#         towel and a pair of goggles abandoned. Atmosphere:
#         drowning, silence, a moment that never ended. Muted
#         desaturated palette, cold blues and teal. Anime style,
#         16:9, no text, no watermark.
# image bg_flash_sora_piscina = "images/fondos/cap02/flash_sora_piscina.png"
image bg_flash_sora_piscina = Solid("#16202e")


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 1 — Yuki de pequeña con sus hermanos
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Yuki recuerda su infancia. Siempre la última.
# ═══════════════════════════════════════════════════════════════
label cap02_flashback_yuki_hermanos:

    # ── Transición a flashback ──
    n "..."

    n "Y por un momento, dejas de estar aquí."

    scene bg_flash_yuki_casa
    with Dissolve(1.0)

    # ── Indicador visual de flashback ──
    show screen flashback_overlay

    # ── Música de flashback ──
    $ musica("flashback_suave", fade=2.0)

    # ── Ambientación ──
    n "Tu casa. Al atardecer."

    n "Tenías siete años."

    n "Tus hermanos estaban en el salón. Discutiendo por el mando de la tele."

    n "Y tú estabas en la puerta. Mirando."

    yup_old "(Yo también quiero jugar.)"
    yup_old "(Pero si lo digo, se van.)"

    # ── Detalle clave ──
    n "En la mesa había tres platos puestos."

    n "Y solo dos sillas ocupadas."

    n "Nadie te había llamado para cenar."

    yup_old "(Ya están comiendo.)"
    yup_old "(Da igual. No tengo hambre.)"

    # ── Conexión con el presente ──
    n "Y así aprendiste a estar sola."

    n "Sin molestar. Sin ocupar espacio."

    n "Sin que nadie te echara de menos."

    yup_old "(Yo tampoco me eché de menos a mí misma.)"
    yup_old "(Hasta hoy.)"

    # ── Métrica ──
    $ modificar_metrica("angustia", +4)

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso2_pasillo
    with Dissolve(1.0)

    show yuki_img at left
    show sora_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al pasillo. A los espejos."

    n "Sora te está mirando. Lleva un rato mirándote."

    so "¿Estás bien?"

    yu "Sí. Solo..."

    yu "Solo estaba pensando."

    so "Ya."

    n "Y por un momento, su cara hace algo raro. Como si hubiera reconocido lo que acabas de decir."

    so "Yo también me quedo callado cuando tengo miedo."

    yu "No tengo miedo."

    so "Vale."

    n "No insiste. Y eso, de alguna forma, te hace sentir peor."

    # ── Flag ──
    $ gtn_flag("fb_yuki_visto", True)

    return


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 2 — Sora antes de la torre
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Sora recuerda el momento antes del accidente.
# ═══════════════════════════════════════════════════════════════
label cap02_flashback_sora_hospital:

    # ── Transición ──
    n "..."

    n "Sora se ha quedado en silencio."

    n "Y por un momento, ves algo distinto en él."

    # ── Flashback ──
    scene bg_flash_sora_piscina
    with Dissolve(1.0)

    show screen flashback_overlay

    $ musica("flashback_tension", fade=2.0)

    # ── Ambientación ──
    n "Una piscina. De noche."

    n "Las luces del techo reflejadas en el agua."

    n "Y nadie alrededor."

    sop_old "(Aquí estaba tranquilo.)"
    sop_old "(Aquí no había nadie que me preguntara cómo estaba.)"

    # ── Detalle clave ──
    n "En el borde de la piscina, unos goggles."

    n "Y una toalla que nadie había recogido."

    n "En el agua, una silueta flotando boca abajo."

    sop_old "(Estoy cansado.)"
    sop_old "(Solo voy a cerrar los ojos un momento.)"

    n "Cerró los ojos."

    n "Y cuando los volvió a abrir..."

    n "...ya estaba en la torre."

    sop_old "(No me acuerdo de lo que pasó.)"
    sop_old "(Pero no me ahogué.)"
    sop_old "(O eso creo.)"

    # ── Conexión con el presente ──
    n "Sora nunca ha contado esto a nadie."

    n "Ni siquiera a sí mismo."

    sop_old "(No me acuerdo.)"
    sop_old "(No quiero acordarme.)"
    sop_old "(Porque si me acuerdo...)"

    # ── Frase que se corta ──
    n "No termina la frase."

    n "Se queda flotando, como la silueta en la piscina."

    # ── Métrica ──
    $ modificar_metrica("angustia", +5)
    $ modificar_metrica("miedo", +3)

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso2_espejo_grande
    with Dissolve(1.0)

    show yuki_img at left
    show sora_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al presente. A la sala del espejo grande."

    n "Sora sigue mirando su propio reflejo."

    n "Pero esta vez, su reflejo tarda un poco más en copiarle."

    yu "Sora."

    so "¿Sí?"

    yu "Te has quedado en blanco."

    so "Solo estaba... pensando."

    n "Las mismas palabras que le has dicho tú antes."

    yup "(Ha usado mi frase.)"
    yup "(Como la voz.)"

    # ── Flag ──
    $ gtn_flag("fb_sora_visto", True)

    return


# ═══════════════════════════════════════════════════════════════
#  SCREEN: OVERLAY DE FLASHBACK
# ═══════════════════════════════════════════════════════════════
#  (Reutilizamos el mismo overlay que en el Cap 1)
#  Si ya lo tienes en 50cap01_flashbacks.rpy, no hace falta duplicarlo.
#  Pero por si acaso, aquí lo dejo por si lo necesitas aislado.
# ═══════════════════════════════════════════════════════════════

# NOTA: Este screen está definido en 50cap01_flashbacks.rpy.
# Si ya está en tu proyecto, NO LO DUPLIQUES aquí.