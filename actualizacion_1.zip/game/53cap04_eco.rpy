# ═══════════════════════════════════════════════════════════════
#  53cap04_eco.rpy — Apariciones de El·yon en el Capítulo 4
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  TRANSFORMS
# ─────────────────────────────────────────────────────────────
transform eco_elyon_efecto:
    alpha 0.0
    zoom 0.8
    yoffset 0
    easein 1.0 alpha 0.9 zoom 1.0 yoffset -20
    pause 0.5
    easeout 1.5 alpha 0.0 zoom 1.1 yoffset -60

transform eco_lateral_efecto:
    alpha 0.0
    xoffset -100
    easein 0.8 alpha 0.7 xoffset 0
    pause 1.2
    easeout 0.8 alpha 0.0 xoffset 100


# ─────────────────────────────────────────────────────────────
#  SCREENS
# ─────────────────────────────────────────────────────────────
screen eco_elyon_visual(texto="El·yon"):
    zorder 50

    text "{i}[texto]{/i}":
        size 80
        color "#8b0000"
        outlines [(3, "#000000", 0, 0), (6, "#440000", 0, 0)]
        xalign 0.5
        yalign 0.5
        at eco_elyon_efecto

    timer 3.5 action Hide("eco_elyon_visual")


screen eco_lateral_visual(texto="El·yon...", pos="izq"):
    zorder 50

    if pos == "izq":
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 0.0
            yalign 0.3
            xoffset 40
            at eco_lateral_efecto
    else:
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 1.0
            yalign 0.3
            xoffset -40
            at eco_lateral_efecto

    timer 3.0 action Hide("eco_lateral_visual")


# ═══════════════════════════════════════════════════════════════
#  ECO 1 — Muy sutil (Acto 1)
# ═══════════════════════════════════════════════════════════════
label cap04_eco_1:

    n "Y entonces, muy lejos..."

    n "Algo."

    show screen eco_lateral_visual("Mei...", pos="der")

    $ sonido("elyon")

    n "Un susurro. Una sola palabra."

    n "Tan baja que casi no la oyes."

    pause 1.5

    mep "(¿Qué ha sido eso?)"
    mep "(Nada. Habrá sido el viento.)"
    mep "(...Aquí no hay viento.)"

    $ modificar_metrica("miedo", +3)

    $ desbloquear_relacion_elyon("torre", "mei")

    $ gtn_flag("eco_1_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 2 — Más notoria (Acto 4)
# ═══════════════════════════════════════════════════════════════
label cap04_eco_2:

    pause 1.0

    n "..."

    n "El silencio se estira."

    n "Y entonces..."

    show screen eco_elyon_visual("No dibujes")

    $ sonido("elyon")

    n "La voz vuelve."

    n "Pero esta vez dice algo distinto."

    n "Repite lo que tú has pensado antes."

    if gtn_flag("mei_cuaderno_abre"):
        elyon_voz "{i}Esta no la he dibujado.{/i}"
        mep "(Eso he pensado.)"
        mep "(Pero no lo he dicho.)"
    elif gtn_flag("mei_mira_puertas"):
        elyon_voz "{i}Alguien los puso ahí.{/i}"
        mep "(Eso es lo que pensé.)"
        mep "(Lo ha copiado. Palabra por palabra.)"
    elif gtn_flag("mei_llama"):
        elyon_voz "{i}No estoy sola.{/i}"
        mep "(Esa es mi voz.)"
        mep "(Esa es MI voz.)"
        mep "(Pero con otro tono.)"

    da "¿Mei? ¿Estás bien?"

    me "Sí. Sí, estoy bien."

    da "Te has quedado quieta."

    me "Estaba... pensando."

    da "Ya."

    n "Daichi no insiste. Pero te mira un segundo más de lo necesario."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)
    $ modificar_metrica("terror", +5)

    $ desbloquear_pista("torre", "p4_susurro_mei")
    $ desbloquear_relacion_elyon("torre", "mei")

    $ gtn_flag("eco_2_oido", True)
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  ECO 3 — Clímax (Acto 5)
# ═══════════════════════════════════════════════════════════════
label cap04_eco_3:

    if not (gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido")):
        return

    pause 1.5

    n "Antes de que puedas decidir..."

    n "La voz vuelve."

    n "Pero esta vez, no susurra."

    n "Habla."

    show screen eco_elyon_visual("La puerta 19 no existía")

    pause 2.0

    show screen eco_elyon_visual("Hasta ahora")

    pause 1.5

    $ sonido("elyon")

    elyon_voz "{i}Y tú la has creado.{/i}"

    pause 1.0

    n "Y el silencio."

    me "..."
    da "¿Mei?"
    me "Nada. Vamos."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +10)

    $ desbloquear_relacion_elyon("torre", "mei")
    $ desbloquear_relacion_elyon("torre", "daichi")

    $ gtn_flag("eco_3_oido", True)
    $ gtn_ecos_oidos += 1

    return