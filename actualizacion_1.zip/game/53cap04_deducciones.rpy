# ═══════════════════════════════════════════════════════════════
#  53cap04_deducciones.rpy — Deducciones del Capítulo 4
#  -----------------------------------------------------------------
#  2 momentos donde el jugador debe deducir algo.
#  Acertar → recompensa (pista al tablón + marca deducción).
#  Fallar → nada.
#
#  ⚠️ Reutilizamos el screen `deduccion_screen` (definido en
#     50cap01_deducciones.rpy, parche 4).
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 1 — ¿Por qué las puertas tienen nombres?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 2, después del flashback de Mei con el cuaderno.
#  Pregunta: ¿Por qué crees que las puertas tienen nombres?
#  Respuesta correcta: "Porque alguien las está contando. Una a una."
# ═══════════════════════════════════════════════════════════════
label cap04_deduccion_1:

    n "..."

    n "Mei se queda callada un momento."

    n "Y tú miras otra vez las puertas."

    mep "(Todas tienen nombres.)"
    mep "(Nombres de gente.)"
    mep "(¿Por qué nombres?)"

    # ── Deducción interactiva ──
    call screen deduccion_screen(
        pregunta="¿Por qué crees que las puertas tienen nombres?",
        opciones=[
            "Porque son puertas de casas. Cada una de un dueño.",
            "Porque alguien las está contando. Una a una.",
            "Porque alguien quería recordarlas."
        ],
        correcta=1,
        pista_ok="Cada puerta es una persona. Y quien graba los nombres no quiere olvidarse de ninguna. Pero tampoco quiere dejar que se vayan.",
        pista_fallo="No son puertas de casas. Ni simples recuerdos. Alguien las está contando. Y todavía no ha terminado.",
        pista_key="p4_puertas_nombres",
        clave_ded="cap04_ded1"
    )

    if deduccion_jugador_acertada("cap04_ded1"):
        $ add_achievement_with_popup(achievement_primera_deduccion)

    return


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 2 — ¿Qué hay detrás de la puerta 19?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 4, después del flashback de Daichi en la morgue.
#  Pregunta: ¿Qué crees que hay detrás de la puerta 19?
#  Respuesta correcta: "Nada. Todavía. Pero Mei lo va a crear."
# ═══════════════════════════════════════════════════════════════
label cap04_deduccion_2:

    n "Daichi se queda callado."

    n "Mei mira el cuaderno."

    n "Y en la última página, la puerta 19."

    mep "(Yo dibujé esta puerta.)"
    mep "(Pero no existe.)"
    mep "(¿O sí?)"
    mep "(¿Y si la puerta existe porque yo la he dibujado?)"

    # ── Deducción interactiva ──
    call screen deduccion_screen(
        pregunta="¿Qué crees que hay detrás de la puerta 19?",
        opciones=[
            "La salida. El final.",
            "Nada. Todavía. Pero Mei lo va a crear.",
            "Alguien que lleva mucho tiempo esperando."
        ],
        correcta=1,
        pista_ok="La puerta 19 no existía antes. Pero ahora sí. Porque Mei la ha dibujado. Y las cosas que Mei dibuja, existen.",
        pista_fallo="La puerta 19 no lleva a la salida. Ni espera a nadie. Todavía no existe. Pero va a existir. Porque Mei la va a crear.",
        pista_key="p4_puerta_19",
        clave_ded="cap04_ded2"
    )

    if deduccion_jugador_acertada("cap04_ded2"):
        $ add_achievement_with_popup(achievement_segunda_deduccion)

    return