# ═══════════════════════════════════════════════════════════════
#  50cap01_eco.rpy — Sistema de eco de El·yon (Capítulo 1)
# ═══════════════════════════════════════════════════════════════

transform eco_elyon_efecto:
    alpha 0.0
    zoom 0.8
    yoffset 0
    easein 1.0 alpha 0.9 zoom 1.0 yoffset -20
    pause 0.5
    easeout 1.5 alpha 0.0 zoom 1.1 yoffset -60

transform eco_lateral_efecto:
    alpha 0.0
    xoffset -100
    easein 0.8 alpha 0.7 xoffset 0
    pause 1.2
    easeout 0.8 alpha 0.0 xoffset 100


# ── Screen con texto parametrizado ──
screen eco_elyon_visual(texto="El·yon"):
    zorder 50

    text "{i}[texto]{/i}":
        size 80
        color "#8b0000"
        outlines [(3, "#000000", 0, 0), (6, "#440000", 0, 0)]
        xalign 0.5
        yalign 0.5
        at eco_elyon_efecto

    timer 3.5 action Hide("eco_elyon_visual")


screen eco_lateral_visual(texto="El·yon...", pos="izq"):
    zorder 50

    if pos == "izq":
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 0.0
            yalign 0.3
            xoffset 40
            at eco_lateral_efecto
    else:
        text "{i}[texto]{/i}":
            size 40
            color "#7a0000"
            outlines [(2, "#000000", 0, 0)]
            xalign 1.0
            yalign 0.3
            xoffset -40
            at eco_lateral_efecto

    timer 3.0 action Hide("eco_lateral_visual")


# ═══════════════════════════════════════════════════════════════
#  APARICIÓN 1 — Muy sutil (Acto 1)
# ═══════════════════════════════════════════════════════════════
label cap01_eco_elyon_1:

    n "Y entonces, muy lejos..."

    n "Algo."

    show screen eco_lateral_visual("El·yon...", pos="der")

    $ sonido("elyon")

    n "Un susurro. Una sola palabra."

    n "Tan baja que casi no la oyes."

    pause 1.5

    akp "(¿Qué ha sido eso?)"
    akp "(Nada. Habrá sido el viento.)"
    akp "(...Aquí no hay viento.)"

    $ modificar_metrica("miedo", +3)
    $ gtn_flag("eco_1_oido", True)
    $ desbloquear_relacion_elyon("torre", "akira")
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  APARICIÓN 2 — Más notoria (Acto 3)
# ═══════════════════════════════════════════════════════════════
label cap01_eco_elyon_2:

    pause 1.0

    n "..."

    n "El silencio se estira."

    n "Y entonces..."

    show screen eco_elyon_visual("No confíes en él.")

    $ sonido("elyon")

    n "La voz vuelve."

    n "Pero esta vez dice algo distinto."

    n "Repite lo que tú has dicho antes."

    if gtn_flag("grito_inicial"):
        elyon_voz "{i}¿Hola...?{/i}"
        akp "(Esa es mi voz.)"
        akp "(Esa es MI voz.)"
    elif gtn_flag("silencio_inicial"):
        elyon_voz "{i}...{/i}"
        n "No dice nada. Solo el silencio de tu voz."
        akp "(Está imitando mi silencio.)"
    elif gtn_flag("puerta_inicial"):
        elyon_voz "{i}Vamos a ver...{/i}"
        akp "(Eso es lo que dije.)"
        akp "(Lo ha copiado. Palabra por palabra.)"

    re "¿Akira? ¿Estás bien?"
    ak "Sí. Sí, estoy bien."
    re "Te has quedado quieto."
    ak "Estaba... pensando."
    re "Ya."
    n "Ren no insiste. Pero te mira un segundo más de lo necesario."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)
    $ modificar_metrica("terror", +5)

    $ desbloquear_pista("torre", "p1_susurro_elyon")
    $ gtn_flag("eco_2_oido", True)
    $ desbloquear_relacion_elyon("torre", "akira")
    $ gtn_ecos_oidos += 1

    return


# ═══════════════════════════════════════════════════════════════
#  APARICIÓN 3 — Clímax
# ═══════════════════════════════════════════════════════════════
label cap01_eco_elyon_3:

    if not (gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido")):
        return

    pause 1.5

    n "Antes de que puedas decidir..."

    n "La voz vuelve."

    n "Pero esta vez, no susurra."

    n "Habla."

    show screen eco_elyon_visual("Déjalo atrás...")

    pause 2.0

    show screen eco_elyon_visual("...como ya hiciste antes.")

    pause 1.5

    $ sonido("elyon")

    pause 1.0

    n "Y el silencio."

    ak "..."
    re "¿Akira?"
    ak "Nada. Vamos."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +10)

    $ gtn_flag("eco_3_oido", True)
    $ desbloquear_relacion_elyon("torre", "akira")
    $ gtn_ecos_oidos += 1

    return