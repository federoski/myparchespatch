# ═══════════════════════════════════════════════════════════════
#  53cap04_objetos.rpy — Objetos clicables del Capítulo 4
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE OBJETOS
# ─────────────────────────────────────────────────────────────
image cap04_cuaderno = Solid("#2a2620")
image cap04_llave = Solid("#2e2820")


# ═══════════════════════════════════════════════════════════════
#  OBJETO 1 — CUADERNO DE MEI
# ═══════════════════════════════════════════════════════════════
screen cap04_cuaderno_interactivo():
    modal True

    add "bg_piso4_despertar"

    # ── Pista visual: cuaderno en el suelo ──
    frame:
        xpos 0.4
        ypos 0.6
        xsize 250
        ysize 250
        background Solid("#2a2620")

        text "📓":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.6)

    # ── Zona clicable ──
    button:
        xpos 0.4
        ypos 0.6
        xsize 250
        ysize 250
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa el cuaderno":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  OBJETO 2 — LLAVE COLGADA
# ═══════════════════════════════════════════════════════════════
screen cap04_llave_interactivo():
    modal True

    add "bg_piso4_llaves"

    # ── Pista visual: llave colgada ──
    frame:
        xpos 0.5
        ypos 0.4
        xsize 200
        ysize 200
        background Solid("#3a2f20")

        text "🔑":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.6)

    # ── Zona clicable ──
    button:
        xpos 0.5
        ypos 0.4
        xsize 200
        ysize 200
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa la llave":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  LABELS DE EFECTO
# ═══════════════════════════════════════════════════════════════

# ── Al pulsar el cuaderno ──
label cap04_pulsar_cuaderno:
    $ marcar_objeto_visto("cuaderno_mei")

    show cap04_cuaderno at truecenter
    with dissolve

    n "El cuaderno está abierto en el suelo."

    n "Mei lo mira. No lo toca."

    n "Pero las páginas se pasan solas."

    $ aprender_palabra("torre", "puerta_19")

    me "..."

    me "Se están pasando solas."

    da "¿Qué?"

    me "Las páginas. Se pasan solas."

    n "Y al llegar a la última, se detienen."

    n "En la página hay un dibujo de una puerta."

    n "Con un número debajo: 19."

    da "¿Tú has dibujado eso?"

    me "No."

    me "O sí."

    me "No me acuerdo."

    n "Pero el trazo es suyo."

    n "Idéntico al resto de los dibujos del cuaderno."

    da "..."

    da "Entonces lo has dibujado."

    me "Entonces lo he dibujado."

    n "Y por un momento, los dos os quedáis en silencio."

    n "Y el cuaderno sigue abierto."

    n "Con la puerta 19 mirándoos."

    hide cap04_cuaderno
    with dissolve

    $ desbloquear_pista("torre", "p4_puerta_19")
    call cap04_nota_puerta_19

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    return


# ── Al pulsar la llave ──
label cap04_pulsar_llave:
    $ marcar_objeto_visto("llave_colgada")
    $ gtn_puertas_pulsadas += 1

    show cap04_llave at truecenter
    with dissolve

    n "La llave cuelga un poco más baja que las demás."

    n "Como si pesara más."

    n "La etiqueta tiene un nombre."

    n "Legible. Y cercano."

    $ aprender_palabra("torre", "llaves_peso")

    me "Daichi."

    da "¿Qué?"

    me "Esta llave."

    me "Tiene mi nombre."

    da "..."

    da "No la toques."

    me "¿Por qué?"

    da "Porque si la coges, se abre."

    me "¿Qué se abre?"

    da "Lo que sea que esté detrás de tu puerta."

    n "Mei retira la mano."

    n "Despacio."

    n "Y la llave sigue ahí."

    n "Colgada."

    n "Pesando más que las demás."

    hide cap04_llave
    with dissolve

    $ desbloquear_pista("torre", "p4_llaves_colgadas")
    call cap04_nota_llaves

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)

    return