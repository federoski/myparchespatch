# ═══════════════════════════════════════════════════════════════
#  51cap02_objetos.rpy — Objetos clicables del Capítulo 2
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE OBJETOS
# ─────────────────────────────────────────────────────────────
image cap02_simbolo_espejo = Solid("#1e1a1a")
image cap02_puerta_espejo = Solid("#1a1a20")


# ═══════════════════════════════════════════════════════════════
#  OBJETO 1 — SÍMBOLO EN EL ESPEJO
# ═══════════════════════════════════════════════════════════════
screen cap02_simbolo_espejo_interactivo():
    modal True

    add "bg_piso2_pasillo"

    frame:
        xpos 0.55
        ypos 0.35
        xsize 200
        ysize 200
        background Solid("#222222")

        text "🔯":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.4)

    button:
        xpos 0.55
        ypos 0.35
        xsize 200
        ysize 200
        background None
        hover_background "#FFAA0033"
        action Return()

    text "Pulsa el símbolo del espejo":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  OBJETO 2 — PUERTA-ESPEJO
# ═══════════════════════════════════════════════════════════════
screen cap02_puerta_espejo_interactivo():
    modal True

    add "bg_piso2_salida"

    frame:
        xpos 0.35
        ypos 0.25
        xsize 400
        ysize 500
        background Solid("#1a1a20")

        text "🚪":
            size 120
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.5)

    button:
        xpos 0.35
        ypos 0.25
        xsize 400
        ysize 500
        background None
        hover_background "#FFAA0033"
        action Return()

    text "Pulsa la puerta-espejo":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  LABELS DE EFECTO
# ═══════════════════════════════════════════════════════════════

# ── Al pulsar el símbolo del espejo ──
label cap02_pulsar_simbolo:
    $ marcar_objeto_visto("simbolo_espejo")
    $ gtn_espejo_pulsado += 1
    if gtn_espejo_pulsado >= 3:
        $ add_achievement_with_popup(achievement_oculto_reflejo)

    show cap02_simbolo_espejo at truecenter
    with dissolve

    n "El símbolo está grabado en el revés del espejo."

    n "Solo se ve por transparencia. Solo cuando la luz cae de cierta manera."

    $ aprender_palabra("torre", "simbolo_espejo")

    yu "Sora. Mira esto."

    so "¿Otro símbolo?"

    yu "Sí. Como los de la torre."

    so "Entonces los espejos tienen algo que ver con esto."

    yu "O esto tiene algo que ver con los espejos."

    so "..."

    so "¿Y si los espejos los pusieron para vernos?"

    yu "No. Los espejos ya estaban aquí."

    so "¿Cómo lo sabes?"

    yu "No lo sé. Lo siento."

    hide cap02_simbolo_espejo
    with dissolve

    $ desbloquear_pista("torre", "p2_todos_en_el_espejo")
    call cap02_nota_simbolo

    $ modificar_metrica("miedo", +5)
    $ modificar_metrica("angustia", +8)

    return


# ── Al pulsar la puerta-espejo ──
label cap02_pulsar_puerta:
    $ marcar_objeto_visto("puerta_espejo")
    $ gtn_puertas_pulsadas += 1

    show cap02_puerta_espejo at truecenter
    with dissolve

    n "La puerta está hecha de fragmentos de espejos."

    n "Cada fragmento refleja algo distinto."

    n "En algunos, Yuki está sola."

    n "En otros, está con Sora."

    n "En uno muy pequeño, está con más gente. Con dieciséis más."

    $ aprender_palabra("torre", "puerta_espejo")

    yu "Está cerrada."

    so "Sí."

    yu "Pero no tiene cerradura."

    so "..."

    yu "No tiene cerradura. ¿Cómo se supone que se abre?"

    so "Quizá no se abre."

    so "Quizá se queda cerrada. Para siempre."

    yu "..."

    yu "No."

    yu "No hemos llegado hasta aquí para quedarnos."

    n "Sora no responde. Pero tampoco discute."

    hide cap02_puerta_espejo
    with dissolve

    $ desbloquear_pista("torre", "p2_puerta_sin_cerradura")
    call cap02_nota_puerta

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +5)

    return



# ═══════════════════════════════════════════════════════════════
#  SCREEN: LA MARCA EN EL MARCO (Cap 2)
#  -----------------------------------------------------------------
#  El Cap 2 llama a este screen cuando Yuki y Sora encuentran la
#  inscripción «El reflejo no miente» grabada en el marco de un
#  espejo, al principio del capítulo.
# ═══════════════════════════════════════════════════════════════
screen cap02_marca_interactiva():
    modal True

    add "bg_piso2_pasillo"

    # ── Zona clicable sobre el marco del espejo ──
    frame:
        xpos 0.4
        ypos 0.35
        xsize 350
        ysize 350
        background Solid("#1a1a1a")

        text "🪞":
            size 120
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.4)

    button:
        xpos 0.4
        ypos 0.35
        xsize 350
        ysize 350
        background None
        hover_background "#FFAA0033"
        action Return()

    # ── Texto indicativo pulsante ──
    text "Pulsa la inscripción del espejo":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint