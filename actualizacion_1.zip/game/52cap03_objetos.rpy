# ═══════════════════════════════════════════════════════════════
#  52cap03_objetos.rpy — Objetos clicables del Capítulo 3
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE OBJETOS
# ─────────────────────────────────────────────────────────────
image cap03_programa = Solid("#26201a")
image cap03_puerta_teatro = Solid("#1a1814")


# ═══════════════════════════════════════════════════════════════
#  OBJETO 1 — PROGRAMA DE MANO
# ═══════════════════════════════════════════════════════════════
screen cap03_programa_interactivo():
    modal True

    add "bg_piso3_despertar"

    frame:
        xpos 0.4
        ypos 0.75
        xsize 300
        ysize 200
        background Solid("#3a3028")

        text "📄":
            size 100
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.6)

    button:
        xpos 0.4
        ypos 0.75
        xsize 300
        ysize 200
        background None
        hover_background "#FFAA0033"
        action Return()

    text "Pulsa el programa":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  OBJETO 2 — PUERTA DETRÁS DEL TELÓN
# ═══════════════════════════════════════════════════════════════
screen cap03_puerta_teatro_interactivo():
    modal True

    add "bg_piso3_telon"

    frame:
        xpos 0.4
        ypos 0.3
        xsize 350
        ysize 450
        background Solid("#1a1814")

        text "🚪":
            size 120
            xalign 0.5
            yalign 0.5
            at Transform(alpha=0.5)

    button:
        xpos 0.4
        ypos 0.3
        xsize 350
        ysize 450
        background None
        hover_background "#FFAA0033"
        action Return()

    text "Pulsa la puerta":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# ═══════════════════════════════════════════════════════════════
#  LABELS DE EFECTO
# ═══════════════════════════════════════════════════════════════

# ── Al pulsar el programa ──
label cap03_pulsar_programa:
    $ marcar_objeto_visto("programa_teatro")

    show cap03_programa at truecenter
    with dissolve

    n "Es un programa de mano. De una obra."

    n "El título está borroso. No lo puedes leer."

    n "Pero hay algo subrayado. Una frase."

    $ aprender_palabra("torre", "telon_no_abre")

    ha "«El telón no se abre...»"

    ka "¿Qué?"

    ha "El programa. Dice «El telón no se abre»."

    ka "..."

    ka "Pues yo lo he visto subido."

    ha "Entonces alguien lo ha subido después."

    ka "O algo."

    n "Y debajo, más pequeña, casi borrada, hay una nota escrita a mano."

    n "«No la dejes sola.»"

    ha "«No la dejes sola»."

    ka "¿A quién?"

    ha "No lo sé."

    ha "Pero quien lo escribió, no quería que esa persona estuviera sola."

    ka "..."

    hap "(¿A quién no debo dejar sola?)"
    hap "(¿A Kaito?)"
    hap "(¿A mí misma?)"

    hide cap03_programa
    with dissolve

    $ desbloquear_pista("torre", "p3_programa_mano")
    call cap03_nota_programa

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +5)

    # ── Decisión con opción extra ──
    menu:
        "¿Qué haces con el programa?"

        "Guardarlo en el bolsillo.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +5)
            $ gtn_flag("hana_programa_guarda", True)
            $ registrar_decision()

            ha "Me lo llevo."

            ka "¿Para qué?"

            ha "No lo sé. Pero no quiero dejarlo aquí."

            n "Lo guardas. El papel pesa más de lo que debería."

        "Dejarlo donde estaba.":
            $ modificar_metrica("miedo", +3)
            $ modificar_metrica("amor", +5)
            $ gtn_flag("hana_programa_deja", True)
            $ registrar_decision()

            ha "No. No quiero llevármelo."

            ka "Vale."

            n "Lo dejas con cuidado. Como si fuera a romperse."

            n "Kaito no dice nada. Pero te mira con algo que no sabes leer."

        "Respirar hondo. Intentar calmarte." if estado_minimo("miedo", 60):
            $ modificar_metrica("miedo", -10)
            $ modificar_metrica("angustia", -5)
            $ gtn_flag("hana_respiro", True)
            $ registrar_decision()

            ha "..."

            n "Cierras los ojos. Respiras."

            n "Cuando los abres, el programa sigue ahí. Pero ya no parece tan importante."

            ka "¿Estás bien?"

            ha "Sí. Ahora sí."

            hap "(Un momento. Solo necesitaba un momento.)"

    return


# ── Al pulsar la puerta detrás del telón ──
label cap03_pulsar_puerta_teatro:
    $ marcar_objeto_visto("puerta_teatro")
    $ gtn_puertas_pulsadas += 1

    show cap03_puerta_teatro at truecenter
    with dissolve

    n "Detrás del telón, hay una puerta."

    n "Hecha de madera vieja. Con símbolos grabados."

    n "Los mismos símbolos que la torre."

    $ aprender_palabra("torre", "puerta_teatro")

    ha "Kaito. Mira esto."

    ka "Una puerta."

    ha "Pero no tiene cerradura."

    ka "Sí."

    ha "No tiene cerradura. ¿Cómo se supone que se abre?"

    ka "Quizá no se abre."

    ka "Quizá se queda cerrada. Para siempre."

    ha "..."

    ha "No."

    ha "No hemos llegado hasta aquí para quedarnos."

    n "Kaito no responde. Pero tampoco discute."

    $ desbloquear_pista("torre", "p3_puerta_sin_cerradura")
    call cap03_nota_telon

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +5)

    hide cap03_puerta_teatro
    with dissolve

    return