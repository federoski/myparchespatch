# ═══════════════════════════════════════════════════════════════
#  50cap01_flashbacks.rpy — Flashbacks del Capítulo 1
#  -----------------------------------------------------------------
#  2 escenas del pasado de Akira y Ren.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES PARA FLASHBACKS
# ─────────────────────────────────────────────────────────────
#  Akira en flashback (voz más joven, sin el peso del presente).
#  Ren en flashback (igual, pero sin la sonrisa forzada).
# ─────────────────────────────────────────────────────────────

# Voz de Akira en el pasado (monólogo interior)
define akp_old = Character(
    "Akira",
    color="#7ec8e3",
    what_color="#c8d8e8",
    what_italic=True,
    what_size=28
)

# Voz de Ren en el pasado
define rep_old = Character(
    "Ren",
    color="#c1a57b",
    what_color="#d8c8a8",
    what_italic=True,
    what_size=28
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE FLASHBACK
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Azotea del instituto (flashback Akira)
# Archivo: images/fondos/cap01/flash_azotea.png
# Prompt: Anime dark psychological horror scene, soft melancholic tone.
#         A school rooftop at sunset, seen from a low angle. Chain-link
#         fence around the edge, distant city skyline in warm orange
#         light. A single empty plastic chair in the foreground.
#         Long shadows. Atmosphere: lonely, nostalgic, quiet.
#         Muted warm palette: oranges, browns, soft greys. Slight
#         sepia tone. Anime style, 16:9, no text, no watermark.
image bg_flash_azotea = "images/fondos/cap01/flash_azotea.png"


# 🎨 PROMPT IMAGEN — Habitación de Ren de noche (flashback Ren)
# Archivo: images/fondos/cap01/flash_habitacion_ren.png
# Prompt: Anime dark psychological horror scene, melancholic tone.
#         A teenager's bedroom at night, seen from a corner. A single
#         small lamp on a desk, casting long shadows. Bed unmade, a
#         clock on the wall showing 3:47 AM. A half-empty glass of
#         water and a small bottle of pills on the desk. Window with
#         curtains closed. Atmosphere: intimate insomnia, quiet dread.
#         Muted desaturated palette, cold blues, one warm lamp light.
#         Anime style, 16:9, no text, no watermark.
image bg_flash_habitacion_ren = "images/fondos/cap01/flash_habitacion_ren.png"



# ─────────────────────────────────────────────────────────────
#  TRANSFORMS PARA FLASHBACKS
# ─────────────────────────────────────────────────────────────
#  Efecto sepia + viñeta + ligero desenfoque al entrar/salir.
# ─────────────────────────────────────────────────────────────

transform flashback_in:
    alpha 0.0
    matrixcolor SepiaMatrix() * BrightnessMatrix(-0.1)
    easein 1.0 alpha 1.0

transform flashback_out:
    alpha 1.0
    easeout 1.0 alpha 0.0


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 1 — Akira en la azotea
# ═══════════════════════════════════════════════════════════════
#  Duración: ~20-30 segundos.
#  Contexto: Akira recuerda los días antes de la torre.
# ═══════════════════════════════════════════════════════════════
label cap01_flashback_akira_azotea:

    # ── Transición a flashback ──
    n "..."

    n "Y por un momento, dejas de estar aquí."

    scene bg_flash_azotea
    with Dissolve(1.0)

    # ── Indicador visual de flashback ──
    show screen flashback_overlay

    # ── Música de flashback (si existe) ──
    $ musica("flashback_suave", fade=2.0)

    # ── Ambientación ──
    n "La azotea del instituto."

    n "El sol se estaba poniendo. Como siempre."

    n "Y como siempre, tú estabas solo."

    akp_old "(Aquí nadie me molesta.)"
    akp_old "(Aquí puedo pensar.)"
    akp_old "(Aunque no haya nada que pensar.)"

    # ── Detalle concreto ──
    n "Había una silla de plástico junto a la valla."

    n "Alguien la había dejado ahí hacía meses. Nadie la había movido."

    n "Tú tampoco."

    akp_old "(A veces me siento en ella.)"
    akp_old "(Y miro el horizonte.)"
    akp_old "(Y pienso en por qué no me importa nada.)"

    # ── Conexión con el presente ──
    n "Y entonces, un día, dejaste de subir."

    n "No recuerdas por qué."

    n "Pero dejaste de subir."

    akp_old "(¿Cuándo fue la última vez que subí?)"
    akp_old "(...No me acuerdo.)"

    # ── Métrica ──
    $ modificar_metrica("angustia", +3)

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso1_pasillo
    with Dissolve(1.0)

    show akira_img at left
    show ren_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al pasillo."

    n "Ren sigue andando. No se ha dado cuenta de que te has quedado atrás."

    re "¿Akira?"

    ak "Ya voy."

    akp "(¿Por qué he pensado en eso ahora?)"
    akp "(¿Por qué me acuerdo de esa silla y no de nada más?)"

    # ── Pista del tablón (opcional) ──
    # Si quieres, esto puede desbloquear una pista.

    # ── Flag ──
    $ gtn_flag("fb_akira_visto", True)
    $ desbloquear_trauma("torre", "akira")
    return


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 2 — Ren en su habitación
# ═══════════════════════════════════════════════════════════════
#  Duración: ~20-30 segundos.
#  Contexto: Ren antes de la torre. Insomnio. Algo que oculta.
# ═══════════════════════════════════════════════════════════════
label cap01_flashback_ren_noche:

    # ── Transición ──
    n "..."

    n "Ren se ha quedado en silencio."

    n "Y por un momento, ves algo distinto en él."

    # ── Flashback ──
    scene bg_flash_habitacion_ren
    with Dissolve(1.0)

    show screen flashback_overlay

    $ musica("flashback_tension", fade=2.0)

    # ── Ambientación ──
    n "Una habitación pequeña."

    n "Un reloj en la pared. Las 2:18 de la madrugada."

    n "Un chico sentado en la cama, mirando la pared."

    rep_old "(No puedo dormir.)"
    rep_old "(Otra vez.)"

    # ── Detalle concreto ──
    n "En la mesa, un vaso de agua a medias."

    n "Y un frasco pequeño."

    n "Casi vacío."

    rep_old "(No debería tomarlas.)"
    rep_old "(Pero si no las tomo, no duermo.)"
    rep_old "(Y si no duermo, veo cosas.)"

    # ── Tensión ──
    n "Se levanta."

    n "Va al baño. Se mira al espejo."

    n "Y durante un momento, muy corto, ve algo detrás de él en el reflejo."

    n "Se gira."

    n "Nada."

    rep_old "(Estoy cansado.)"
    rep_old "(Solo estoy cansado.)"

    # ── Conexión con el presente ──
    n "Esa fue la última noche antes de la torre."

    n "La última vez que se miró al espejo y no se reconoció."

    # ── Métrica ──
    $ modificar_metrica("angustia", +5)
    $ modificar_metrica("miedo", +3)

    # ── Salida ──
    hide screen flashback_overlay
    scene bg_piso1_hueco
    with Dissolve(1.0)

    show akira_img at left
    show ren_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al presente. Al borde del hueco."

    n "Ren sigue mirando la distancia. Como si calculara algo."

    ak "¿Ren?"

    re "¿Sí?"

    ak "Te has quedado en blanco."

    re "Solo estaba... pensando."

    n "Las mismas palabras que le dijiste tú antes."

    akp "(Ha usado mi frase.)"
    akp "(Como la voz.)"

    # ── Pista del tablón (opcional) ──
    # Si quieres, esto puede desbloquear una pista.

    # ── Flag ──
    $ gtn_flag("fb_ren_visto", True)
    $ desbloquear_trauma("torre", "ren")   
    $ desbloquear_secreto("torre", "ren")

    return


# ═══════════════════════════════════════════════════════════════
#  SCREEN: OVERLAY DE FLASHBACK
# ═══════════════════════════════════════════════════════════════
#  Se muestra durante los flashbacks para dar la sensación
#  de estar en un recuerdo.
# ═══════════════════════════════════════════════════════════════
screen flashback_overlay():
    zorder 40

    # ── Viñeta oscura alrededor ──
    add Solid("#000000") alpha 0.0

    # ── Marco de color sepia ──
    frame:
        xfill True
        yfill True
        background None

        # Borde sepia alrededor (4 lados)
        # Arriba
        add Solid("#3a2410") xsize 1920 ysize 20 yalign 0.0 alpha 0.6
        # Abajo
        add Solid("#3a2410") xsize 1920 ysize 20 yalign 1.0 alpha 0.6
        # Izquierda
        add Solid("#3a2410") xsize 20 ysize 1080 xalign 0.0 alpha 0.6
        # Derecha
        add Solid("#3a2410") xsize 20 ysize 1080 xalign 1.0 alpha 0.6

    # ── Indicador de "flashback" arriba a la derecha ──
    text "RECUERDO":
        size 14
        color "#a08050"
        outlines [(2, "#000000", 0, 0)]
        xalign 0.98
        yalign 0.02
        italic True
        at Transform(alpha=0.7)


# ═══════════════════════════════════════════════════════════════
#  BONUS: composición de matrices de color
# ═══════════════════════════════════════════════════════════════
#  Matrices usadas en los transforms para efecto sepia.
# ═══════════════════════════════════════════════════════════════
init python:
    def SepiaMatrix():
        """Devuelve una matriz de color para efecto sepia."""
        return ColorizeMatrix("#8b6a3a", "#3a2410") if hasattr(renpy, "display") else None