# ═══════════════════════════════════════════════════════════════
#  53cap04_mei_daichi.rpy — Capítulo 4: El susurro
#  -----------------------------------------------------------------
#  Pareja: Mei & Daichi
#  Posición: Mei (izq) + Daichi (der)
#  Finales: bueno / bueno_especial / mei_muere / daichi_muere / ambos_quedan / secreto
#  Minijuego: PUZZLE DE PUERTAS
#  Exploración: menú con flechas (3 zonas)
#  Diccionario: puertas_nombres, llaves_peso, susurro_nombre, puerta_19
#  Fichas: mei, daichi
#  Bestiario: puertas, morgue
#  Pistas tablón: 6
#  Deducciones: 2
#  Flashbacks: 2
#  Eco El·yon: 3 apariciones
#
#  ⚠️ NOTA: Los labels cap04_nota_*, cap04_flashback_*,
#     cap04_deduccion_*, cap04_eco_*, cap04_pulsar_* están
#     definidos en sus respectivos archivos auxiliares
#     (53cap04_notas.rpy, 53cap04_flashbacks.rpy,
#      53cap04_deducciones.rpy, 53cap04_eco.rpy,
#      53cap04_objetos.rpy). NO se duplican aquí.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES
# ─────────────────────────────────────────────────────────────
define mep = Character(
    "Mei",
    color="#90a4ae",
    what_color="#c8d0d8",
    what_italic=True,
    what_size=28
)

define dap = Character(
    "Daichi",
    color="#a1887f",
    what_color="#d8c8b8",
    what_italic=True,
    what_size=28
)

define elyon_voz = Character(
    "???",
    color="#8b0000",
    what_color="#CC4444",
    what_italic=True,
    what_size=32
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES (placeholders temporales)
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Despertar en el pasillo de puertas
# Archivo: images/fondos/cap04/piso4_despertar.png
# Prompt: Anime dark psychological horror scene: a narrow corridor
#         lined floor to ceiling with old wooden doors, dozens of
#         them, each slightly different, some with names carved
#         into the wood. The floor is dark, stained, wet in places.
#         A single dying light bulb overhead. No windows. The
#         corridor extends impossibly far, vanishing into shadow.
#         Atmosphere: claustrophobic, silent, waiting. Muted
#         desaturated palette: cold greys, dark browns, faint red
#         stains. Anime style, 16:9, no text, no watermark.
image bg_piso4_despertar = Solid("#2a2622")

# 🎨 PROMPT IMAGEN — Pasillo de puertas (vista completa)
# Archivo: images/fondos/cap04/piso4_pasillo.png
# Prompt: Anime dark psychological horror scene: same corridor of
#         doors, seen from a slight angle, showing dozens more doors
#         extending into the distance. Some doors are ajar. Some
#         have handprints in dried blood on them. The floor reflects
#         a faint red glow. Atmosphere: dread, endless. 16:9.
image bg_piso4_pasillo = Solid("#262220")

# 🎨 PROMPT IMAGEN — Cuarto de las llaves
# Archivo: images/fondos/cap04/piso4_llaves.png
# Prompt: Anime dark psychological horror scene: a small room with
#         hundreds of keys hanging from hooks on every wall. Each
#         key has a small tag with a name written on it. Some tags
#         are faded, some are new, some have blood on them. A single
#         wooden table in the center with a large open ledger. 
#         Atmosphere: archival, forbidden, a book of the dead.
#         Muted palette: dark wood, dull brass, one warm lamp. 16:9.
image bg_piso4_llaves = Solid("#2e2820")

# 🎨 PROMPT IMAGEN — La morgue
# Archivo: images/fondos/cap04/piso4_morgue.png
# Prompt: Anime dark psychological horror scene: an old hospital
#         morgue at night. Rows of metal cabinets with sliding
#         drawers on the wall. Some drawers are open, some are
#         closed. A single cold fluorescent light flickers. On the
#         central steel table, a white sheet covering something
#         the size of a person. But the shape under the sheet is
#         wrong: too small, or too many bumps. Atmosphere: cold,
#         clinical dread, the dead are listening. Cold blue palette,
#         one flickering light. Anime style, 16:9, no text.
image bg_piso4_morgue = Solid("#1e2228")

# 🎨 PROMPT IMAGEN — Puerta final
# Archivo: images/fondos/cap04/piso4_salida.png
# Prompt: Anime dark psychological horror scene: a heavy door at
#         the end of a long corridor of doors. This one is
#         different: it has no name carved into it. It is slightly
#         ajar, and a soft white light filters through the gap.
#         On the floor in front of it, a small sketchbook with a
#         pencil next to it. Atmosphere: final threshold, quiet.
#         Cold desaturated palette, one warm light. 16:9, no text.
image bg_piso4_salida = Solid("#3a3228")

# ── OBJETOS ──

# 🎨 PROMPT IMAGEN — Cuaderno de Mei
# Archivo: images/objetos/cap04_cuaderno.png
# Prompt: Anime dark psychological horror close-up: a small
#         sketchbook open to a page filled with hand-drawn doors.
#         Dozens of doors. Each slightly different. In the bottom
#         right corner, a door with the number "19" written under
#         it in shaky handwriting. The paper is worn, edges frayed.
#         16:9, no text except the number.
image cap04_cuaderno = Solid("#2a2620")

# 🎨 PROMPT IMAGEN — Llave colgada con nombre
# Archivo: images/objetos/cap04_llave.png
# Prompt: Anime dark psychological horror close-up: a single old
#         brass key hanging from a nail. A small paper tag is tied
#         to it with a name written in faded ink. The name is
#         partially readable. The key seems slightly warm, as if
#         recently held. 16:9, no text beyond the tag.
image cap04_llave = Solid("#2e2820")

# ── IMÁGENES DE FINAL ──

# 🎨 PROMPT IMAGEN — Final bueno
# Archivo: images/finales/cap4_final_bueno.png
# Prompt: Anime dark psychological horror scene: a 16-year-old girl
#         with short black hair and a white streak (Mei) and a
#         20-year-old tall young man with dark brown hair (Daichi)
#         walking side by side through a door at the end of a
#         corridor, seen from behind. The door behind them closes
#         silently. Soft warm light ahead. 16:9, no text.
image cap4_final_bueno = Solid("#e8d0a8")

# 🎨 PROMPT IMAGEN — Final especial (Sin miedo)
# Archivo: images/finales/cap4_final_especial.png
# Prompt: Anime dark psychological horror scene: Mei's hand holding
#         Daichi's hand, seen close-up, crossing through a doorway
#         of light. Mei's hand is small, trembling slightly but
#         holding firm. Daichi's hand is large, calloused, stable.
#         Warm golden light around them. 16:9, no text.
image cap4_final_especial = Solid("#f0d8b0")

# 🎨 PROMPT IMAGEN — Final Mei muere
# Archivo: images/finales/cap4_final_mei_muere.png
# Prompt: Anime dark psychological horror scene: a young man
#         (Daichi) alone in a corridor of doors, holding a small
#         sketchbook open in his hands. In the book, the last
#         page shows a newly drawn door — this one is OPEN, with
#         light coming through. Daichi stares at it. His face
#         shows grief. Cold desaturated palette. 16:9, no text.
image cap4_final_mei_muere = Solid("#201c18")

# 🎨 PROMPT IMAGEN — Final Daichi muere
# Archivo: images/finales/cap4_final_daichi_muere.png
# Prompt: Anime dark psychological horror scene: a young girl (Mei)
#         alone in a morgue, standing in front of an open metal
#         drawer. Inside the drawer, a single working wristwatch
#         lies on white cloth. The watch still ticks. In the
#         background, other drawers slowly slide open. Cold blue
#         palette, one flickering light. 16:9, no text.
image cap4_final_daichi_muere = Solid("#1a1e26")

# 🎨 PROMPT IMAGEN — Final ambos quedan
# Archivo: images/finales/cap4_final_ambos.png
# Prompt: Anime dark psychological horror scene: two silhouettes
#         (a young girl and a tall young man) sitting on the floor
#         against the door at the end of the corridor. The door
#         is closed. The corridor of doors extends forever behind
#         them. Both are holding hands. The girl's sketchbook is
#         open on the floor between them. 16:9, no text.
image cap4_final_ambos = Solid("#181818")

# 🎨 PROMPT IMAGEN — Final secreto (Puerta 19)
# Archivo: images/finales/cap4_final_secreto.png
# Prompt: Anime dark psychological horror scene: a young girl (Mei)
#         sitting alone in a corridor, drawing in a sketchbook.
#         The page she is drawing on shows a door — the door 19.
#         But the door she is drawing is not on the page: it is
#         appearing, faintly, at the end of the corridor, glowing
#         softly. The other doors are all closed. 16:9, no text.
image cap4_final_secreto = Solid("#26201c")


# ═══════════════════════════════════════════════════════════════
#  CAPÍTULO 4
# ═══════════════════════════════════════════════════════════════
label capitulo_4:

    # ── Pantalla de carga ──
    $ _cap_data = capitulos.historias["torre"]["actos"].get(4, {})
    $ _nombre_cap = _cap_data.get("nombre", "El susurro")
    $ _sub_cap = _cap_data.get("sub", "Mei & Daichi")
    $ _icono_cap = _cap_data.get("icono", "🩸")
    call mostrar_pantalla_carga("torre", 4, _nombre_cap, _sub_cap, _icono_cap)

    $ gtn_reiniciar_metricas()
    $ gtn_capitulo_actual = 4
    $ capitulos.desbloquear_capitulo("torre", 4)
    $ registrar_capitulo_jugado(4)

    scene black
    with fade

    show screen gtn_notif_screen
    $ musica("torre_ambiente", fade=2.0)

    $ add_achievement_with_popup(achievement_cuarto_despertar)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 1 — EL DESPERTAR
    # ═══════════════════════════════════════════════════════════

    n "Lo primero que notas es el silencio."
    n "Un silencio denso. Como si el aire estuviera quieto."
    n "Lo segundo, el olor."
    n "Madera vieja. Metal frío. Y algo más."
    n "Algo que prefieres no identificar."
    n "Abres los ojos."

    scene bg_piso4_despertar
    with fade

    n "Estás en un pasillo."
    n "Pero no es un pasillo normal."
    n "Las paredes están cubiertas de puertas. Decenas. Cientos."
    n "Todas cerradas. Todas viejas. Todas con nombres grabados."

    show mei_img at left
    with dissolve

    me "..."
    me "¿Qué es este sitio?"

    n "Te incorporas con cuidado. El suelo está húmedo."
    n "En algunas puertas hay manchas oscuras. Que prefieres no mirar."

    mep "(Puertas.)"
    mep "(Todas cerradas.)"
    mep "(Todas con nombres.)"
    mep "(Como en mi cuaderno.)"

    n "Instintivamente, llevas la mano al bolsillo."
    n "Y lo encuentras."
    n "Tu cuaderno."
    n "El mismo cuaderno que dibujabas desde niña."

    $ desbloquear_ficha("torre", "mei")
    $ add_achievement_with_popup(achievement_conoce_mei)

    $ aprender_palabra("torre", "puertas_nombres")

    me "Está aquí."
    me "El cuaderno está aquí."
    me "No debería estar aquí."

    $ desbloquear_pista("torre", "p4_puertas_nombres")

    # ── Decisión 1 ──
    menu:
        "¿Qué haces?"

        "Abrir el cuaderno.":
            $ modificar_metrica("miedo", +8)
            $ modificar_metrica("angustia", +10)
            $ gtn_flag("mei_cuaderno_abre", True)
            $ registrar_decision()

            n "Abres el cuaderno."
            n "En la primera página, un dibujo de una puerta."
            n "En la segunda, otra. En la tercera, otra."
            n "Todas distintas. Todas cerradas."
            me "..."
            me "Las dibujé yo."
            me "Todas las dibujé yo."
            n "Pasas las páginas."
            n "Y en la última, hay una puerta más."
            n "Pero esta no la recuerdas."
            me "Esta no la he dibujado."
            mep "(¿O sí?)"
            mep "(¿Por qué no me acuerdo?)"

        "Mirar las puertas del pasillo.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +12)
            $ gtn_flag("mei_mira_puertas", True)
            $ registrar_decision()

            me "..."
            n "Caminas hacia la puerta más cercana."
            n "Tiene un nombre grabado. Arañado en la madera."
            n "«Hiroshi.»"
            me "Hiroshi."
            me "No conozco a ningún Hiroshi."
            n "Pero la puerta sí."
            n "O la persona que la grabó."
            mep "(Los nombres no son aleatorios.)"
            mep "(Alguien los puso ahí.)"

        "Llamar a alguien.":
            $ modificar_metrica("miedo", +8)
            $ modificar_metrica("angustia", +5)
            $ gtn_flag("mei_llama", True)
            $ registrar_decision()
            $ gtn_flag("grito_alguna_vez", True)

            me "¿Hola?"
            n "Tu voz no hace eco."
            n "Las puertas se la tragan."
            me "¿Hay alguien?"
            n "Silencio."
            n "Y entonces, muy bajo, muy lejano..."
            n "Un susurro."
            me "..."
            mep "(No estoy sola.)"
            mep "(O sí. Pero hay algo más.)"

    if estado_minimo("miedo", 40):
        mep "(Me tiemblan las manos.)"
        mep "(No debería. Son solo puertas.)"
        mep "(Pero hay demasiadas.)"

    if estado_extremo("angustia"):
        n "Sientes que te falta el aire. Y no hay ninguna razón para ello."
        mep "(Respira. Respira. Respira.)"
        mep "(No estás en peligro. Todavía.)"

    call cap04_eco_1
    $ add_achievement_with_popup(achievement_primera_decision)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 2 — EL ENCUENTRO
    # ═══════════════════════════════════════════════════════════

    n "Entonces lo oyes."

    $ sonido("pasos_pesados")

    n "Pasos. Lentos. Al final del pasillo."
    n "Alguien se acerca."
    n "Y no es pequeño."

    show daichi_img at right
    with dissolve

    da "..."
    da "¿Quién anda ahí?"
    me "¡No te acerques!"
    da "Vale. Vale, tranquila."
    da "No voy a hacerte daño."
    da "Me llamo Daichi."

    n "El chico es alto. Ancho. Serio."
    n "Pero sus ojos no parecen peligrosos."
    n "Parecen cansados."

    me "...Mei."
    da "Mei."
    da "Vale, Mei. Vamos a salir de aquí."

    $ desbloquear_ficha("torre", "daichi")
    $ add_achievement_with_popup(achievement_conoce_daichi)

    n "No sabes por qué, pero le crees."
    n "O quizá solo quieres creerle."

    if gtn_flag("mei_cuaderno_abre"):
        da "¿Qué tienes ahí?"
        me "Un cuaderno."
        da "¿Tuyo?"
        me "...Creo que sí."
        da "«Creo»."
        me "No recuerdo haberlo traído."
        da "..."
        da "Vale. Guárdalo. Puede servir."

    elif gtn_flag("mei_mira_puertas"):
        da "¿Qué mirabas?"
        me "Las puertas."
        da "¿Tienen algo?"
        me "Tienen nombres."
        da "..."
        da "¿Nombres?"
        me "Sí. Como si alguien las hubiera grabado."
        da "..."
        da "Eso no me gusta."
        me "A mí tampoco."

    elif gtn_flag("mei_llama"):
        da "Te he oído llamar."
        me "No ha venido nadie."
        da "Ya. Pero yo también he oído algo."
        me "¿El qué?"
        da "Un susurro."
        me "..."
        da "Pero no he entendido qué decía."
        mep "(Él también lo ha oído.)"
        mep "(Entonces no estoy loca.)"

    if estado_minimo("angustia", 50):
        n "Daichi te mira. Y por un momento, ves algo en sus ojos que no habías visto."
        n "Cansancio. Cansancio de verdad."
        mep "(No es solo el pasillo.)"
        mep "(Lleva esto dentro desde antes de llegar.)"

    if estado_minimo("amor", 30):
        n "Y sin embargo, sonríe. Como si, a pesar de todo, estuviera bien."
        mep "(¿Por qué sonríe?)"
        mep "(No hay nada que sonreír.)"

    if estado_minimo("miedo", 60):
        n "Tú no sonríes. No puedes."
        mep "(Me tiembla la voz.)"
        mep "(No puedo dejar que lo note.)"

    if peso_tomado("cap3_confio_kaito"):
        mep "(En el piso 3, confiaron el uno en el otro.)"
        mep "(Y salió bien.)"

    elif peso_tomado("cap3_pregunto_kaito"):
        mep "(En el piso 3, hicieron preguntas.)"
        mep "(Quizá debería hacer yo también.)"

    # ── Decisión 2 ──
    menu:
        "¿Cómo reaccionas?"

        "Preguntarle por qué está aquí.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("mei_pregunta", True)
            $ registrar_decision()

            me "¿Por qué estás aquí?"
            da "No lo sé."
            da "Me desperté. Estaba en el suelo. Con las puertas."
            me "¿Y no te dio miedo?"
            da "..."
            da "Sí."
            da "Pero no por las puertas."
            me "¿Por qué entonces?"
            da "No quiero hablar de eso."
            mep "(Hay algo más.)"
            mep "(Y no me lo va a decir.)"

        "Contarle lo del susurro.":
            $ modificar_metrica("amor", +10)
            $ modificar_metrica("miedo", +5)
            $ gtn_flag("mei_cuenta", True)
            $ registrar_decision()

            me "He oído un susurro."
            da "¿El qué?"
            me "No sé. No lo he entendido."
            me "Pero decía algo. Muy bajo."
            da "..."
            da "Yo también."
            da "Pero no quería decirlo."
            me "Entonces no estamos locos."
            da "O estamos los dos."
            me "Peor."

        "Confiar en él directamente.":
            $ modificar_metrica("amor", +15)
            $ modificar_metrica("miedo", -5)
            $ gtn_flag("mei_confia", True)
            $ registrar_decision()

            me "Vale. Confío en ti."
            da "...¿Así, sin más?"
            me "No tengo mucho donde elegir."
            n "Daichi asiente. No dice nada."
            n "Pero sus hombros se relajan un poco."
            mep "(Se ha relajado.)"
            mep "(Como si estuviera esperando que le dijera eso.)"

    if gtn_flag("mei_confia"):
        da "Me alegra que confíes en mí."
        da "Aunque no deberías."
        me "¿Qué?"
        da "Nada. Olvídalo."
        mep "(Ha dicho algo importante.)"
        mep "(Pero no lo ha dicho.)"

    if estado_minimo("amor", 40) and estado_minimo("miedo", 40):
        mep "(Le he dicho que confío en él.)"
        mep "(Y es verdad. Pero también me da miedo.)"
        mep "(Me da miedo que confiar en alguien salga mal.)"
        mep "(Como siempre.)"

    if estado_extremo("odio"):
        mep "(No debería odiarlo.)"
        mep "(Ni siquiera lo conozco.)"
        mep "(Pero hay algo en él que me irrita.)"
        mep "(Y no sé qué es.)"

    if estado_minimo("angustia", 60):
        mep "(Me pesa la cabeza.)"
        mep "(Como si tuviera algo dentro que quiere salir.)"
        mep "(Y no puedo dejar que salga.)"

    call cap04_flashback_mei_cuaderno

    # ═══════════════════════════════════════════════════════════
    #  OBJETO 1 — El cuaderno de Mei
    # ═══════════════════════════════════════════════════════════

    n "Mei se sienta un momento en el suelo."
    n "Abre el cuaderno. Y empieza a dibujar."
    n "Sin darse cuenta. Sin querer."
    n "Su mano se mueve sola."

    call screen cap04_cuaderno_interactivo
    call cap04_pulsar_cuaderno

    # ═══════════════════════════════════════════════════════════
    #  ACTO 3 — LA EXPLORACIÓN
    # ═══════════════════════════════════════════════════════════

    n "El pasillo se divide."
    n "A un lado, más puertas."
    n "Al otro, una puerta distinta. Sin nombre."
    n "Daichi te mira. Espera."

    $ musica("tension_baja", fade=2.0)

    $ zonas_exploradas = []
    call cap04_exploracion
    jump cap04_tras_exploracion


# ═══════════════════════════════════════════════════════════════
#  TRAS LA EXPLORACIÓN
# ═══════════════════════════════════════════════════════════════
label cap04_tras_exploracion:
    scene bg_piso4_pasillo
    with fade

    show mei_img at left
    show daichi_img at right
    with dissolve

    n "Volvéis al centro del pasillo."
    n "Daichi está pálido."
    n "Más de lo que estaba."

    if peso_tomado("cap3_cogio_mano"):
        n "Y por un momento, recuerdas algo."
        n "Dos figuras cruzaron por aquí. Una chica y un chico."
        n "Juntos. Cogidos de la mano."
        mep "(¿Quiénes eran?)"
        mep "(No los conozco.)"
        mep "(Pero creo que los he visto en algún sitio.)"

    elif peso_tomado("cap3_confiesa"):
        n "Y por un momento, recuerdas algo."
        n "Alguien dijo algo importante aquí. Antes."
        n "Y no llegó a terminar la frase."
        mep "(¿Qué dijo?)"
        mep "(¿Por qué lo recuerdo?)"

    da "Mei."
    me "¿Sí?"
    da "Tengo que decirte algo."
    me "¿Qué?"
    da "..."
    da "Esta morgue."
    da "La conozco."

    n "Daichi se queda callado."
    n "Y por primera vez, ves miedo en sus ojos."
    n "Miedo de verdad."

    da "Trabajé aquí."
    da "De noche."
    da "Durante dos años."

    call cap04_flashback_daichi_morgue
    call cap04_deduccion_1

    # ── CAMERINOS — Cuarto de las llaves ──
    scene bg_piso4_llaves
    with fade

    show mei_img at left
    show daichi_img at right
    with dissolve

    n "En el fondo del pasillo, hay una puerta distinta."
    n "Sin nombre. Sin cerradura."
    n "Pero se abre."
    n "Detrás, una sala llena de llaves colgadas."
    n "Cientos. Miles."
    n "Cada una con un nombre en una etiqueta."

    da "Mei. No entres."
    me "¿Por qué?"
    da "Porque esas llaves no son de este sitio."
    me "¿De qué son entonces?"
    da "..."
    da "No quiero saberlo."

    $ aprender_palabra("torre", "llaves_peso")
    $ desbloquear_pista("torre", "p4_llaves_colgadas")
    call cap04_nota_llaves

    # ── OBJETO 2 — Una llave colgada ──
    n "Una de las llaves cuelga un poco más baja que las demás."
    n "Como si pesara más."
    n "La etiqueta tiene un nombre legible."

    call screen cap04_llave_interactivo
    call cap04_pulsar_llave

    if estado_minimo("angustia", 60):
        mep "(Me pesa la cabeza.)"
        mep "(Como si tuviera algo dentro que quiere salir.)"
        mep "(Y no puedo dejar que salga.)"

    # ── EL SUSURRO ──
    n "Y entonces lo oís."

    $ sonido("susurro_nombre")

    n "Un susurro."
    n "Muy cerca. Muy bajo."
    n "Y esta vez, dice un nombre."

    $ aprender_palabra("torre", "susurro_nombre")
    $ desbloquear_bestiario("torre", "puertas")
    $ desbloquear_pista("torre", "p4_susurro_mei")
    call cap04_nota_susurro

    if estado_extremo("terror"):
        mep "(Lo he oído. Lo he oído de verdad.)"
        mep "(No estoy loca. No estoy loca.)"
        mep "(¿O sí?)"
        n "Te llevas las manos a las orejas. Como si quisieras tapar algo."
        da "Mei. Mei, mírame."
        me "Estoy bien."
        da "No. No lo estás."
        n "Y por primera vez, no sabes qué contestar."

    if estado_minimo("amor", 50):
        da "Sea lo que sea que has oído..."
        da "No estás sola."
        me "..."
        mep "(No estoy sola.)"
        mep "(Nunca había pensado eso.)"
        mep "(Y ahora que lo pienso, no sé qué hacer con ello.)"

    if estado_minimo("odio", 50):
        mep "(No quiero que me vea así.)"
        mep "(No quiero que nadie me vea así.)"
        n "Te apartas un poco de Daichi. Sin darte cuenta."
        da "..."
        n "Daichi no dice nada. Pero lo nota."

    me "Daichi. ¿Estás oyendo eso?"
    da "Sí."

    call cap04_eco_2

    # ═══════════════════════════════════════════════════════════
    #  ACTO 4 — LA MORGUE
    # ═══════════════════════════════════════════════════════════

    scene bg_piso4_morgue
    with fade

    show mei_img at left
    show daichi_img at right
    with dissolve

    n "Al fondo del pasillo, una puerta doble."
    n "Metálica. Fría."
    n "Con un cartel que pone «MORGUE»."
    n "Daichi se queda quieto delante."
    n "No quiere entrar."
    n "Pero entra."

    da "..."
    da "Aquí trabajé."
    da "Aquí vi cosas que no debería haber visto."
    da "Y aquí conocí a gente que ya no está."

    n "Dentro, hileras de cajones metálicos."
    n "Algunos abiertos. Algunos cerrados."
    n "Y en el centro, una mesa."
    n "Con una sábana encima."
    n "Cubriendo algo."

    me "Daichi..."
    da "No mires."
    me "¿Por qué?"
    da "Porque si miras, te va a mirar."
    me "¿El qué?"
    da "..."
    da "Lo que hay debajo."

    $ desbloquear_pista("torre", "p4_morgue_daichi")
    $ desbloquear_bestiario("torre", "morgue")

    call cap04_deduccion_2

    # ── Un cajón abierto ──
    n "Uno de los cajones está abierto. Y vacío."
    n "Pero hay algo dentro."
    n "Un reloj de pulsera."
    n "Que funciona."
    n "Y que no es de Daichi."
    n "Pero se parece."

    $ desbloquear_pista("torre", "p4_cajon_abierto")
    call cap04_nota_morgue

    if peso_tomado("cap1_respiro") or peso_tomado("cap2_respiro") or peso_tomado("cap3_respiro"):
        mep "(He aprendido a calmarme cuando tengo miedo.)"
        mep "(Respirar. Como en los pisos anteriores.)"
        mep "(Eso me ayudó antes. Puede ayudarme ahora.)"
        $ modificar_metrica("miedo", -5)

    # ── LOGROS ACUMULATIVOS ──
    if gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido") and gtn_flag("eco_3_oido"):
        $ add_achievement_with_popup(achievement_eco_completo_cap4)

    if gtn_flag("fb_mei_visto") and gtn_flag("fb_daichi_visto"):
        $ add_achievement_with_popup(achievement_recuerdos_cap4)

    if notas_descubiertas_cap("torre", 4) >= 5:
        $ add_achievement_with_popup(achievement_notas_completas_cap4)

    if objeto_visto("cuaderno_mei") and objeto_visto("llave_colgada"):
        $ add_achievement_with_popup(achievement_objetos_cap4)

    if deduccion_jugador_acertada("cap04_ded1") and deduccion_jugador_acertada("cap04_ded2"):
        $ add_achievement_with_popup(achievement_deducciones_cap4)

    if not gtn_flag("grito_alguna_vez"):
        $ add_achievement_with_popup(achievement_oculto_no_grito)

    if gtn_ecos_oidos >= 12:
        $ add_achievement_with_popup(achievement_oculto_oyo_todo)

    $ _especiales = 0
    if peso_tomado("cap1_cogio_mano"):
        $ _especiales += 1
    if peso_tomado("cap2_cogio_mano"):
        $ _especiales += 1
    if peso_tomado("cap3_cogio_mano"):
        $ _especiales += 1
    if _especiales >= 3:
        $ add_achievement_with_popup(achievement_oculto_vio_todo)

    if gtn_puertas_pulsadas >= 4:
        $ add_achievement_with_popup(achievement_oculto_puertas)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 5 — LA PUERTA FINAL
    # ═══════════════════════════════════════════════════════════

    scene bg_piso4_salida
    with fade

    show mei_img at left
    show daichi_img at right
    with dissolve

    n "Al final de la morgue, hay una puerta."
    n "Distinta a todas las demás."
    n "Sin nombre. Sin símbolos."
    n "Entreabierta. Con luz blanca al otro lado."

    n "En el suelo, delante de la puerta, hay algo."
    n "Un cuaderno."
    n "Y un lápiz."
    n "Pero no es el cuaderno de Mei."
    n "Es otro."

    $ aprender_palabra("torre", "puerta_19")

    da "Es la salida."
    me "¿Y si no lo es?"
    da "Entonces volvemos. Pero contigo."

    n "Mei se agacha."
    n "Coge el cuaderno."
    n "Lo abre."
    n "Y en la última página, hay un dibujo."
    n "Una puerta."
    n "La puerta 19."
    n "La misma que ella dibujó sin darse cuenta."

    me "..."
    me "Yo dibujé esta puerta."
    da "¿Qué?"
    me "Esta puerta. La dibujé yo."
    me "Pero no la he visto nunca."
    me "Y sin embargo, está ahí."
    me "Al final del pasillo."
    me "Como si la hubiera creado yo."

    $ desbloquear_pista("torre", "p4_puerta_19")
    call cap04_nota_puerta_19

    call cap04_eco_3

    # ═══════════════════════════════════════════════════════════
    #  MINIJUEGO — PUZZLE DE PUERTAS
    # ═══════════════════════════════════════════════════════════

    $ musica("tension_alta", fade=0.5)

    n "La puerta tiembla."
    n "Y en la pared, junto a ella, aparecen cinco puertas más."
    n "Pequeñas. Con números."
    n "Hay que abrirlas en el orden correcto."
    n "O no se abre la puerta grande."

    if estado_extremo("miedo"):
        mep "(No puedo. No puedo hacerlo.)"
        mep "(Voy a fallar. Voy a fallar.)"
        mep "(Como siempre.)"
        n "Te tiemblan las manos."
        da "Mei. Mírame."
        me "..."
        da "Vas a abrirlas en orden. Y yo voy a salir contigo. ¿Vale?"
        mep "(¿Por qué confía en mí?)"
        mep "(No debería.)"

    if estado_minimo("terror", 60):
        mep "(Son demasiadas puertas.)"
        mep "(No voy a acertar todas.)"
        mep "(Lo sé.)"

    # ── Minijuego: pulsar teclas en el orden correcto ──
    # Usamos el sistema de QTE que ya existe
    call lanzar_qte(["↑", "→", "↓", "←", "↑", "→"])

    if gtn_minijuego_resultado:
        $ registrar_minijuego(True)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Las puertas se abren en orden."
        n "Una a una."
        n "Y la puerta grande se abre del todo."
        n "Al otro lado, la luz."

        $ modificar_metrica("amor", +20)
        $ modificar_metrica("miedo", -5)

        da "¡Vamos!"

        menu:
            "¿Qué haces?"

            "Salir juntos, corriendo.":
                $ registrar_decision()
                $ registrar_peso("cap4_cogio_mano")
                jump cap4_final_bueno

            "Empujar a Daichi primero.":
                $ registrar_decision()
                jump cap4_final_daichi_muere

            "Quedarte tú atrás, dibujando la puerta.":
                $ registrar_decision()
                jump cap4_final_mei_muere

            "Cogerle la mano antes de cruzar." if estado_minimo("amor", 70) and estado_maximo("miedo", 40):
                $ modificar_metrica("amor", +15)
                $ gtn_flag("mei_cogio_mano", True)
                $ registrar_decision()
                $ registrar_peso("cap4_cogio_mano")

                me "Daichi."
                da "¿Sí?"
                n "No dices nada. Solo le coges la mano."
                n "Daichi no se aparta."
                n "Y por primera vez, tu mano no tiembla."
                n "Y los dos cruzáis la puerta juntos."
                jump cap4_final_bueno_especial
    else:
        $ registrar_minijuego(False)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Falláis."
        n "Las puertas se cierran de golpe."
        n "Todas a la vez."
        n "Y la puerta grande también."
        n "La luz se apaga."

        $ musica("final_malo", fade=1.0)
        jump cap4_final_ambos_quedan


# ═══════════════════════════════════════════════════════════════
#  FINALES DEL CAPÍTULO 4
# ═══════════════════════════════════════════════════════════════

label cap4_final_bueno:
    scene bg_piso4_salida
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    me "¡Juntos!"
    da "¡Juntos!"
    n "Corréis los dos hacia la puerta."
    n "La cruzéis al mismo tiempo."

    $ musica("final_bueno", fade=2.0)
    scene cap4_final_bueno
    with Dissolve(1.5)

    n "La luz os traga."
    n "Y luego, silencio."
    n "Detrás de vosotros, la puerta se cierra."
    n "Sin ruido."
    n "Como si nunca hubiera estado abierta."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 4 superado."

    $ registrar_final_bueno()
    $ registrar_ruta(4, "bueno")
    $ guardar_estados_capitulo(4, "torre")
    $ unlock_final("torre", 4, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap4)
    $ add_achievement_with_popup(achievement_cap4_completado)
    $ desbloquear_imagen_galeria("cap4_bueno")
    $ capitulos.completar_capitulo("torre", 4)
    call marcar_final_bueno_cap(4, "torre")
    $ desbloquear_invocaciones_hasta(4)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("mei_confia"):
        $ registrar_peso("cap4_confio_daichi")
    if gtn_flag("mei_pregunta"):
        $ registrar_peso("cap4_pregunto_daichi")
    if gtn_flag("mei_respiro"):
        $ registrar_peso("cap4_respiro")

    "Capítulo 4 completado."
    jump volver_al_hub


label cap4_final_bueno_especial:
    scene bg_piso4_salida
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    n "Cruzasteis juntos. Con las manos cogidas."
    n "Y al otro lado, por primera vez, no había silencio."
    n "Había una puerta abierta. Y detrás, luz."

    $ musica("final_bueno", fade=2.0)
    scene cap4_final_especial
    with Dissolve(1.5)

    n "Pero no era la salida."
    n "Era otra cosa."
    n "Era el inicio de algo que ninguno de los dos había previsto."
    n "Y tu mano, por primera vez en años, no temblaba."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 4 superado. Pero no del todo."

    $ registrar_final_bueno()
    $ registrar_ruta(4, "bueno_especial")
    $ registrar_peso("cap4_cogio_mano")
    $ guardar_estados_capitulo(4, "torre")
    $ unlock_final("torre", 4, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap4)
    $ add_achievement_with_popup(achievement_cap4_completado)
    $ add_achievement_with_popup(achievement_final_especial_cap4)
    $ desbloquear_imagen_galeria("cap4_bueno")
    $ capitulos.completar_capitulo("torre", 4)
    call marcar_final_bueno_cap(4, "torre")
    $ desbloquear_invocaciones_hasta(4)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("mei_confia"):
        $ registrar_peso("cap4_confio_daichi")
    if gtn_flag("mei_pregunta"):
        $ registrar_peso("cap4_pregunto_daichi")
    if gtn_flag("mei_respiro"):
        $ registrar_peso("cap4_respiro")

    "Capítulo 4 completado (ruta especial)."
    jump volver_al_hub


label cap4_final_mei_muere:
    scene bg_piso4_salida
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    n "Te quedas atrás."
    n "Con el cuaderno abierto."
    n "Dibujando la puerta 19."
    da "¡MEI!"
    me "¡VE!"
    n "Daichi cruza."
    n "Tú te quedas un momento más."
    n "Terminando el dibujo."
    n "Y la puerta se cierra."

    $ musica("final_malo", fade=1.5)
    scene cap4_final_mei_muere
    with Dissolve(1.0)

    n "Al otro lado, Daichi se queda solo."
    n "Con el cuaderno en la mano."
    n "Y en la última página, la puerta 19."
    n "Pero esta vez, está abierta."
    n "Y por ella, entra luz."
    n "Y en la luz, una silueta."
    n "Pequeña."
    n "Que no se mueve."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El susurro cesa."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(4, "mei_muere")
    $ guardar_estados_capitulo(4, "torre")
    $ unlock_final("torre", 4, "mei_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap4_completado)
    $ desbloquear_imagen_galeria("cap4_mei_muere")
    $ capitulos.completar_capitulo("torre", 4)
    $ desbloquear_invocaciones_hasta(4)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("mei_confia"):
        $ registrar_peso("cap4_confio_daichi")
    if gtn_flag("mei_pregunta"):
        $ registrar_peso("cap4_pregunto_daichi")
    if gtn_flag("mei_respiro"):
        $ registrar_peso("cap4_respiro")

    "Capítulo 4 completado (final malo)."
    jump volver_al_hub


label cap4_final_daichi_muere:
    scene bg_piso4_salida
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    n "Empujas a Daichi hacia la puerta."
    da "¡Mei, no!"
    me "¡VE!"
    n "Daichi cruza."
    n "Pero antes de cerrarse, la puerta se detiene."
    n "Y algo sale de la morgue."
    n "Algo que no debería salir."

    $ musica("final_malo", fade=1.5)
    scene cap4_final_daichi_muere
    with fade

    n "Daichi se queda atrás."
    n "Con los cajones abriéndose."
    n "Uno a uno."
    n "Todos a la vez."
    n "Y en cada uno, un cuerpo."
    n "Que se levanta."
    n "Que lo mira."
    n "Que lo reconoce."
    da "..."
    da "Vosotros."
    da "Os conozco."
    da "A todos."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Y la puerta se cierra."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(4, "daichi_muere")
    $ guardar_estados_capitulo(4, "torre")
    $ unlock_final("torre", 4, "daichi_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap4_completado)
    $ desbloquear_imagen_galeria("cap4_daichi_muere")
    $ capitulos.completar_capitulo("torre", 4)
    $ desbloquear_invocaciones_hasta(4)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("mei_confia"):
        $ registrar_peso("cap4_confio_daichi")
    if gtn_flag("mei_pregunta"):
        $ registrar_peso("cap4_pregunto_daichi")
    if gtn_flag("mei_respiro"):
        $ registrar_peso("cap4_respiro")

    "Capítulo 4 completado (final malo)."
    jump volver_al_hub


label cap4_final_ambos_quedan:
    scene bg_piso4_pasillo
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    n "Las puertas se cierran."
    n "Todas."
    n "La grande también."
    n "Y la luz se apaga."

    $ musica("final_malo", fade=1.0)
    scene cap4_final_ambos
    with fade

    n "Os sentáis en el suelo."
    n "Contra la puerta grande."
    n "Sin abrir."
    n "Sin cerrar."
    n "Solo sentados."
    n "Y Mei abre el cuaderno."
    n "Y empieza a dibujar."
    n "Una puerta nueva."
    n "La puerta 20."
    n "Porque si va a quedarse aquí..."
    n "Al menos, que sea con una puerta más."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El susurro no cesa."
    n "Pero ahora, susurra dos nombres."
    n "En lugar de uno."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(4, "ambos_quedan")
    $ guardar_estados_capitulo(4, "torre")
    $ unlock_final("torre", 4, "ambos_quedan")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap4_completado)
    $ desbloquear_imagen_galeria("cap4_ambos")
    $ capitulos.completar_capitulo("torre", 4)
    $ desbloquear_invocaciones_hasta(4)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("mei_confia"):
        $ registrar_peso("cap4_confio_daichi")
    if gtn_flag("mei_pregunta"):
        $ registrar_peso("cap4_pregunto_daichi")
    if gtn_flag("mei_respiro"):
        $ registrar_peso("cap4_respiro")

    "Capítulo 4 completado (final malo)."
    jump volver_al_hub


label cap4_final_secreto:
    scene bg_piso4_pasillo
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    me "Ve tú. Yo me quedo."
    da "¡No!"
    me "Confía en mí."
    n "Empujas a Daichi hacia la puerta."
    n "Pero no te quedas atrás."
    n "Te quedas de pie, al lado de la puerta, con el cuaderno abierto."
    n "Y empiezas a dibujar."
    n "Otra vez."
    n "La puerta 19."

    $ musica("final_malo", fade=1.5)
    scene cap4_final_secreto
    with fade

    n "La puerta se cierra detrás de Daichi."
    n "Y tú te quedas."
    n "Sola."
    n "En el pasillo."
    n "Con tu cuaderno."
    n "Y con la puerta 19, que estás dibujando."
    n "Y que, mientras la dibujas, aparece."
    n "En la pared del fondo."
    n "Pequeña. Al principio."
    n "Luego más grande."
    n "Y luego, se abre."

    $ sonido("susurro_nombre")
    elyon_voz "{i}La puerta 19 no existía. Hasta ahora.{/i}"
    elyon_voz "{i}Y tú la has creado.{/i}"

    n "Detrás de la puerta 19, hay un pasillo."
    n "Con más puertas."
    n "Con más nombres."
    n "Con más gente."
    n "Y en el centro, tú."
    n "Pero no eres tú."
    n "Todavía."

    scene black
    with fade
    $ parar_todo(fade=2.0)

    $ registrar_final_malo()
    $ registrar_ruta(4, "secreto")
    $ guardar_estados_capitulo(4, "torre")
    $ unlock_final("torre", 4, "secreto")
    $ add_achievement_with_popup(achievement_cap4_completado)
    $ add_achievement_with_popup(achievement_primera_ruta)
    $ desbloquear_imagen_galeria("cap4_secreto")
    $ capitulos.completar_capitulo("torre", 4)
    $ desbloquear_invocaciones_hasta(4)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("mei_confia"):
        $ registrar_peso("cap4_confio_daichi")
    if gtn_flag("mei_pregunta"):
        $ registrar_peso("cap4_pregunto_daichi")
    if gtn_flag("mei_respiro"):
        $ registrar_peso("cap4_respiro")

    "Capítulo 4 completado (ruta secreta)."
    jump volver_al_hub


# ═══════════════════════════════════════════════════════════════
#  EXPLORACIÓN CON FLECHAS
# ═══════════════════════════════════════════════════════════════
label cap04_exploracion:

    call screen cap04_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap04_zona1

    call screen cap04_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap04_zona2

    call screen cap04_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap04_zona3

    return


screen cap04_exploracion_screen(zonas):
    modal True
    add "bg_piso4_despertar"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20

        text "EXPLORA EL PASILLO" size 30 color "#FFFFFF" xalign 0.5
        text "Zonas exploradas: [len(zonas)] / 3" size 18 color "#AAAAAA" xalign 0.5
        null height 20

        vbox:
            spacing 30
            xalign 0.5

            if 1 not in zonas:
                textbutton "→ Recorrer el PASILLO DE PUERTAS" action Return(1) style "menu_button" xalign 0.5
            else:
                text "✔ Pasillo de puertas (explorado)" size 16 color "#666" xalign 0.5

            if 2 not in zonas:
                textbutton "↑ Entrar al CUARTO DE LAS LLAVES" action Return(2) style "menu_button" xalign 0.5
            else:
                text "✔ Cuarto de las llaves (explorado)" size 16 color "#666" xalign 0.5

            if 3 not in zonas:
                textbutton "↓ Bajar a la MORGUE" action Return(3) style "menu_button" xalign 0.5
            else:
                text "✔ Morgue (explorado)" size 16 color "#666" xalign 0.5


label cap04_zona1:
    scene bg_piso4_pasillo
    with fade
    show mei_img at left
    with dissolve

    n "El pasillo se extiende. Interminable."
    n "Las puertas a los lados. Todas cerradas."
    n "Todas con nombres grabados."
    n "Caminas despacio. Leyendo los nombres."
    n "Algunos te suenan. Otros no."
    n "Pero todos te miran."

    show daichi_img at right
    with dissolve

    da "¿Reconoces alguno?"
    me "..."
    me "Uno."
    da "¿Cuál?"
    me "El de la puerta del fondo."
    me "«Mei.»"
    da "..."
    da "¿Tu nombre?"
    me "Sí."
    da "Eso no me gusta."
    me "A mí tampoco."

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    return


label cap04_zona2:
    scene bg_piso4_llaves
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    n "El cuarto de las llaves está en silencio."
    n "Cientos de llaves. Miles."
    n "Cada una con un nombre."
    n "Daichi se queda en la puerta. No entra."
    da "Mei. No toques nada."
    me "¿Por qué?"
    da "Porque esas llaves no son nuestras."
    me "¿De quién son?"
    da "..."
    da "De los que ya no están."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("terror", +5)

    $ desbloquear_pista("torre", "p4_llaves_colgadas")
    return


label cap04_zona3:
    scene bg_piso4_morgue
    with fade
    show mei_img at left
    show daichi_img at right
    with dissolve

    n "La morgue está fría."
    n "Más de lo normal."
    n "Los cajones metálicos brillan bajo la luz."
    n "Daichi camina despacio. Muy despacio."
    n "Como si cada paso le costara."

    da "Aquí trabajé."
    da "Dos años."
    da "Todas las noches."
    me "¿Y no te daba miedo?"
    da "No. Al principio no."
    da "Después sí."
    me "¿Por qué?"
    da "..."
    da "Porque un día llegó alguien que conocía."
    da "Y desde entonces, todos los cuerpos me parecen él."

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("angustia", +8)

    $ desbloquear_pista("torre", "p4_morgue_daichi")
    return


# ═══════════════════════════════════════════════════════════════
#  SCREENS INTERACTIVOS
# ═══════════════════════════════════════════════════════════════

screen cap04_cuaderno_interactivo():
    modal True
    add "bg_piso4_despertar"
    button:
        xpos 0.45
        ypos 0.55
        xsize 300
        ysize 300
        background None
        hover_background "#FFAA0033"
        action Return()
    text "Pulsa el cuaderno":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


screen cap04_llave_interactivo():
    modal True
    add "bg_piso4_llaves"
    button:
        xpos 0.5
        ypos 0.4
        xsize 200
        ysize 200
        background None
        hover_background "#FFAA0033"
        action Return()
    text "Pulsa la llave":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint