# ═══════════════════════════════════════════════════════════════
#  51cap02_notas.rpy — Notas de Yuki (Capítulo 2)
#  -----------------------------------------------------------------
#  Apuntes que Yuki escribe durante el capítulo.
#  Se añaden al sistema de notas existente (50cap01_notas.rpy).
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Añadir las notas del Cap 2 al catálogo existente ──
    # Si el catálogo NOTAS ya existe, añadimos las nuevas entradas.
    if "torre" not in NOTAS:
        NOTAS["torre"] = {}

    NOTAS["torre"].update({
        "nota2_reflejo_retrasado": {
            "titulo": "El reflejo con retraso",
            "icono": "🪞",
            "capitulo": 2,
            "texto": (
                "Los espejos de este piso tardan medio segundo en copiarme. "
                "Al principio pensé que era cosa mía. Que estaba cansada, o que "
                "me lo imaginaba. Pero no. Lo he cronometrado. Siempre es medio "
                "segundo. Siempre. Como si los espejos pensaran antes de moverse."
            ),
        },
        "nota2_inscripcion": {
            "titulo": "«El reflejo no miente»",
            "icono": "📜",
            "capitulo": 2,
            "texto": (
                "Está grabado en tres marcos de espejo distintos. La misma letra. "
                "Las mismas uñas. La misma desesperación que las marcas de arriba. "
                "Alguien escribió esto antes que yo. Y lo escribió tres veces para "
                "que no se me olvidara. Pero no me dice qué es lo que no miente."
            ),
        },
        "nota2_eco": {
            "titulo": "El eco que no repite",
            "icono": "🗣️",
            "capitulo": 2,
            "texto": (
                "Ha dicho «no confíes en el eco» con mi voz. Pero yo no he dicho eso. "
                "Y Sora ha oído otra cosa. Algo distinto. Algo que no quiere contarme. "
                "Si el eco no repite lo que decimos, sino lo que pensamos, entonces "
                "el eco de Sora ha dicho lo que Sora piensa de mí."
            ),
        },
        "nota2_simbolo_espejo": {
            "titulo": "El símbolo del espejo",
            "icono": "🔯",
            "capitulo": 2,
            "texto": (
                "El símbolo está grabado en el revés del espejo. No en la superficie. "
                "En el revés. Solo se ve por transparencia cuando la luz cae de cierta "
                "manera. Es el mismo símbolo de la torre. Los mismos arañazos. "
                "Los mismos círculos. Los mismos trazos cruzados. "
                "Estoy empezando a pensar que los espejos no son un decorado. "
                "Son parte del sitio."
            ),
        },
        "nota2_puerta_espejo": {
            "titulo": "La puerta sin cerradura",
            "icono": "🔑",
            "capitulo": 2,
            "texto": (
                "La última puerta del pasillo es un espejo disfrazado. No refleja. "
                "Solo está ahí, con símbolos grabados en cada fragmento. "
                "Y no tiene cerradura. Ni manilla. Ni nada. "
                "¿Cómo se supone que se abre? ¿Con qué? "
                "Sora dice que quizá no se abre. Que quizá se queda cerrada para siempre. "
                "Pero eso no puede ser. Porque entonces, ¿para qué estamos aquí?"
            ),
        },
    })


# ═══════════════════════════════════════════════════════════════
#  LABELS DE LLAMADA — Notas del Cap 2
# ═══════════════════════════════════════════════════════════════

# ── Nota: el reflejo con retraso ──
label cap02_nota_reflejo:
    n "..."

    yup "(Debería apuntar esto.)"
    yup "(Antes de que se me olvide.)"

    $ desbloquear_nota("torre", "nota2_reflejo_retrasado")

    n "Sacas un bolígrafo del bolsillo. No recuerdas tenerlo."

    n "Pero lo tienes. Y escribes en la palma de la mano."

    return


# ── Nota: la inscripción «el reflejo no miente» ──
label cap02_nota_inscripcion:
    $ desbloquear_nota("torre", "nota2_inscripcion")
    return


# ── Nota: el eco que no repite ──
label cap02_nota_eco:
    $ desbloquear_nota("torre", "nota2_eco")
    return


# ── Nota: el símbolo del espejo ──
label cap02_nota_simbolo:
    $ desbloquear_nota("torre", "nota2_simbolo_espejo")
    return


# ── Nota: la puerta sin cerradura ──
label cap02_nota_puerta:
    $ desbloquear_nota("torre", "nota2_puerta_espejo")
    return