# ═══════════════════════════════════════════════════════════════
#  50cap01_deducciones.rpy — Deducciones del jugador
#  -----------------------------------------------------------------
#  2 momentos donde el jugador debe deducir algo.
#  Acertar → recompensa. Fallar → nada.
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Persistencia de deducciones del jugador ──
    if not hasattr(persistent, "deducciones_jugador") or persistent.deducciones_jugador is None or isinstance(persistent.deducciones_jugador, bool):
        persistent.deducciones_jugador = {}

    def deduccion_jugador_acertada(clave):
        return persistent.deducciones_jugador.get(clave, False)

    def marcar_deduccion_jugador_acertada(clave):
        persistent.deducciones_jugador[clave] = True

    def total_deducciones_jugador_acertadas():
        return sum(1 for v in persistent.deducciones_jugador.values() if v)


# ═══════════════════════════════════════════════════════════════
#  SCREEN: DEDUCCIÓN INTERACTIVA
# ═══════════════════════════════════════════════════════════════
#  Screen reutilizable para todas las deducciones.
#  Parámetros:
#    pregunta   → texto de la pregunta
#    opciones   → lista de tuplas (texto, es_correcta)
#    pista_ok   → pista que se desbloquea al acertar
# ═══════════════════════════════════════════════════════════════
screen deduccion_interactiva(pregunta, opciones, pista_ok="", pista_key=""):
    modal True
    zorder 150

    default elegida = -1
    default acertada = False

    add "#000000cc"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 900
        ysize 600
        background Solid("#1a1408")
        padding (40, 30)

        has vbox spacing 20 xfill True

        # ── Cabecera ──
        hbox:
            spacing 15
            xalign 0.5

            text "🧠":
                size 42

            text "DEDUCCIÓN":
                size 32
                bold True
                color "#E8C06A"

        # ── Pregunta ──
        frame:
            xfill True
            background Solid("#2a1f0c")
            padding (20, 16)
            text "[pregunta]":
                size 19
                color "#fff"
                xalign 0.5
                text_align 0.5

        null height 10

        # ── Opciones o resultado ──
        if elegida == -1:
            vbox:
                spacing 12
                xfill True

                for i, op in enumerate(opciones):
                    textbutton "▸ [op[0]]":
                        style "menu_button"
                        xfill True
                        action [
                            SetScreenVariable("elegida", i),
                            SetScreenVariable("acertada", op[1]),
                            If(op[1] and pista_key != "", 
                                Function(desbloquear_pista, "torre", pista_key),
                                NullAction()
                            )
                        ]
        else:
            vbox:
                spacing 15
                xfill True

                if acertada:
                    frame:
                        xfill True
                        background Solid("#0f2010")
                        padding (20, 16)
                        has vbox spacing 8
                        text "✅ ¡Correcto!":
                            size 24
                            bold True
                            color "#4CAF50"
                            xalign 0.5
                        text "Has deducido algo importante.":
                            size 15
                            color "#ccc"
                            xalign 0.5
                            text_align 0.5

                    if pista_ok:
                        frame:
                            xfill True
                            background Solid("#1a1408")
                            padding (14, 10)
                            has hbox spacing 10
                            text "🔍" size 20
                            text "Pista añadida al tablón: [pista_ok]":
                                size 14
                                color "#E8C06A"
                                yalign 0.5

                    textbutton "Continuar":
                        style "menu_button"
                        xalign 0.5
                        action Return()

                else:
                    frame:
                        xfill True
                        background Solid("#200a0a")
                        padding (20, 16)
                        has vbox spacing 8
                        text "❌ No del todo...":
                            size 24
                            bold True
                            color "#CC4444"
                            xalign 0.5
                        text "Quizá te hayas precipitado.":
                            size 15
                            color "#ccc"
                            xalign 0.5
                            text_align 0.5

                    textbutton "Reintentar":
                        style "menu_button"
                        xalign 0.5
                        action [
                            SetScreenVariable("elegida", -1),
                            SetScreenVariable("acertada", False)
                        ]

                    textbutton "Continuar sin deducir":
                        style "menu_button"
                        xalign 0.5
                        action Return()

# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 1 — ¿Por qué estás aquí?
# ═══════════════════════════════════════════════════════════════
#  Momento: después de ver la marca y antes del susurro.
#  Pregunta: ¿Por qué crees que estás aquí?
#  Respuesta correcta: "Alguien me trajo. O algo."
# ═══════════════════════════════════════════════════════════════
label cap01_deduccion_1:

    n "..."

    n "Ren se queda callado un momento."

    n "Tú también."

    n "Y en ese silencio, empiezas a pensar."

    akp "(Estoy aquí por algo.)"
    akp "(Pero no sé por qué.)"
    akp "(Y eso me molesta más que no recordar cómo he llegado.)"

    # ── Deducción interactiva ──
    $ opciones_ded1 = [
        ("He venido yo solo. Me perdí y ya está.", False),
        ("Alguien me trajo. O algo. No fue casualidad.", True),
        ("Es un sueño. Todo esto es un sueño.", False),
        ("No importa cómo he llegado. Solo importa salir.", False),
    ]

    call screen deduccion_interactiva(
        pregunta="¿Por qué crees que estás aquí?",
        opciones=opciones_ded1,
        pista_ok="Nadie llega a la torre por casualidad"
    )

    # ── Resultado (según si acertó o no) ──
    if persistent.deducciones_jugador.get("cap01_ded1", False):
        pass

    # ── Comprobar si acertó ──
    # Como el screen no devuelve si acertó o no, comprobamos por el estado.
    # Si el jugador NO acertó, no marcamos nada.
    # Si acertó, el propio screen ya lo marcó.

    return


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 2 — ¿Qué hay al otro lado?
# ═══════════════════════════════════════════════════════════════
#  Momento: antes de la decisión final.
#  Pregunta: ¿Qué crees que hay al otro lado de la puerta?
#  Respuesta correcta: "Otro sitio. Otro piso. Otra prueba."
# ═══════════════════════════════════════════════════════════════
label cap01_deduccion_2:

    n "Ren te mira. Y luego mira la puerta."

    n "Y por un momento, los dos pensáis lo mismo."

    akp "(¿Qué hay al otro lado?)"
    akp "(¿Y si no es la salida?)"
    akp "(¿Y si es otra cosa?)"

    # ── Deducción interactiva ──
    $ opciones_ded2 = [
        ("La salida. El final. La libertad.", False),
        ("Otro sitio. Otro piso. Otra prueba.", True),
        ("Nada. Solo oscuridad.", False),
        ("A alguien que lleva mucho tiempo esperándonos.", False),
    ]

    call screen deduccion_interactiva(
        pregunta="¿Qué crees que hay al otro lado de la puerta?",
        opciones=opciones_ded2,
        pista_ok="La torre no termina en el piso 1"
    )

    return


# ═══════════════════════════════════════════════════════════════
#  SISTEMA INTERNO DE COMPROBACIÓN DE DEDUCCIONES
# ═══════════════════════════════════════════════════════════════
#  Cuando el jugador acierta, se marca la deducción y se
#  desbloquea la pista correspondiente.
# ═══════════════════════════════════════════════════════════════
init python:
    def comprobar_deduccion_1():
        """Se llama si el jugador acertó la deducción 1."""
        marcar_deduccion_jugador_acertada("cap01_ded1")
        # La pista se desbloquea desde el propio screen
        # (aquí solo se marca el flag)

    def comprobar_deduccion_2():
        """Se llama si el jugador acertó la deducción 2."""
        marcar_deduccion_jugador_acertada("cap01_ded2")



# ═══════════════════════════════════════════════════════════════
#  SCREEN: DEDUCCIÓN INTERACTIVA (versión ampliada)
#  -----------------------------------------------------------------
#  Versión alternativa de `deduccion_interactiva` con firma
#  diferente. Se usa desde los capítulos 2 y 3.
#
#  Parámetros:
#    pregunta       → texto de la pregunta
#    opciones       → lista de strings (las respuestas)
#    correcta       → índice de la respuesta correcta (0-based)
#    pista_ok       → texto que se muestra al acertar
#    pista_fallo    → texto que se muestra al fallar (opcional)
#    pista_key      → clave de pista del tablón a desbloquear (opcional)
#    clave_ded      → clave de deducción a marcar como acertada (opcional)
# ═══════════════════════════════════════════════════════════════
screen deduccion_screen(pregunta, opciones, correcta=0, pista_ok="", pista_fallo="", pista_key="", clave_ded=""):
    modal True
    zorder 150

    default elegida = -1
    default acertada = False

    add "#000000cc"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 900
        ysize 600
        background Solid("#1a1408")
        padding (40, 30)

        has vbox spacing 20 xfill True

        # ── Cabecera ──
        hbox:
            spacing 15
            xalign 0.5

            text "🧠":
                size 42

            text "DEDUCCIÓN":
                size 32
                bold True
                color "#E8C06A"

        # ── Pregunta ──
        frame:
            xfill True
            background Solid("#2a1f0c")
            padding (20, 16)
            text "[pregunta]":
                size 19
                color "#fff"
                xalign 0.5
                text_align 0.5

        null height 10

        # ── Opciones o resultado ──
        if elegida == -1:
            vbox:
                spacing 12
                xfill True

                for i, op in enumerate(opciones):
                    textbutton "▸ [op]":
                        style "menu_button"
                        xfill True
                        action [
                            SetScreenVariable("elegida", i),
                            SetScreenVariable("acertada", i == correcta),
                            If(
                                i == correcta,
                                If(
                                    clave_ded != "",
                                    Function(marcar_deduccion_jugador_acertada, clave_ded),
                                    NullAction()
                                ),
                                NullAction()
                            ),
                            If(
                                i == correcta and pista_key != "",
                                Function(desbloquear_pista, "torre", pista_key),
                                NullAction()
                            )
                        ]
        else:
            vbox:
                spacing 15
                xfill True

                if acertada:
                    frame:
                        xfill True
                        background Solid("#0f2010")
                        padding (20, 16)
                        has vbox spacing 8
                        text "✅ ¡Correcto!":
                            size 24
                            bold True
                            color "#4CAF50"
                            xalign 0.5
                        if pista_ok:
                            text "[pista_ok]":
                                size 15
                                color "#ccc"
                                xalign 0.5
                                text_align 0.5
                        else:
                            text "Has deducido algo importante.":
                                size 15
                                color "#ccc"
                                xalign 0.5
                                text_align 0.5

                    if pista_key != "":
                        frame:
                            xfill True
                            background Solid("#1a1408")
                            padding (14, 10)
                            has hbox spacing 10
                            text "🔍" size 20
                            text "Pista añadida al tablón.":
                                size 14
                                color "#E8C06A"
                                yalign 0.5

                    textbutton "Continuar":
                        style "menu_button"
                        xalign 0.5
                        action Return()

                else:
                    frame:
                        xfill True
                        background Solid("#200a0a")
                        padding (20, 16)
                        has vbox spacing 8
                        text "❌ No del todo...":
                            size 24
                            bold True
                            color "#CC4444"
                            xalign 0.5
                        if pista_fallo:
                            text "[pista_fallo]":
                                size 15
                                color "#ccc"
                                xalign 0.5
                                text_align 0.5
                        else:
                            text "Quizá te hayas precipitado.":
                                size 15
                                color "#ccc"
                                xalign 0.5
                                text_align 0.5

                    textbutton "Reintentar":
                        style "menu_button"
                        xalign 0.5
                        action [
                            SetScreenVariable("elegida", -1),
                            SetScreenVariable("acertada", False)
                        ]

                    textbutton "Continuar sin deducir":
                        style "menu_button"
                        xalign 0.5
                        action Return()