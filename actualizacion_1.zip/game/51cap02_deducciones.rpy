# ═══════════════════════════════════════════════════════════════
#  51cap02_deducciones.rpy — Deducciones del Capítulo 2
#  -----------------------------------------------------------------
#  2 momentos donde el jugador debe deducir algo.
#  Acertar → recompensa (pista al tablón). Fallar → nada.
#
#  ⚠️ Reutilizamos el screen `deduccion_interactiva` del Cap 1
#     (definido en 50cap01_deducciones.rpy).
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 1 — ¿Por qué se retrasa el reflejo?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 4, después del flashback de Sora.
#  Pregunta: ¿Por qué crees que el reflejo tarda medio segundo?
#  Respuesta correcta: "Está decidiendo qué copiar."
# ═══════════════════════════════════════════════════════════════
label cap02_deduccion_1:

    n "..."

    n "Sora se queda callado un momento."

    n "Y tú miras otra vez los espejos."

    yup "(Se retrasa medio segundo.)"
    yup "(Siempre el mismo retraso.)"
    yup "(Eso no es un error.)"

    # ── Deducción interactiva ──
    $ opciones_ded2_1 = [
        ("Es un fallo de la torre. Está mal hecha.", False),
        ("Está decidiendo qué copiar. Elige imitarme.", True),
        ("Estoy imaginándomelo. Es cansancio.", False),
        ("Los espejos están rotos por dentro.", False),
    ]

    call screen deduccion_interactiva(
        pregunta="¿Por qué crees que el reflejo tarda medio segundo en copiarte?",
        opciones=opciones_ded2_1,
        pista_ok="El reflejo elige qué copiar",
        pista_key="p2_reflejo_elige"
    )

    # ── Si acertó, la deducción se marca automáticamente ──
    # (El screen `deduccion_interactiva` ya llama a marcar_deduccion_jugador_acertada)

    return


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 2 — ¿Qué dice el eco de verdad?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 4, después del espejo roto.
#  Pregunta: ¿Qué crees que dice realmente el eco?
#  Respuesta correcta: "Lo que uno piensa. No lo que dice."
# ═══════════════════════════════════════════════════════════════
label cap02_deduccion_2:

    n "Yuki y Sora se quedan callados."

    n "El eco acaba de decirle algo distinto a cada uno."

    n "Y Sora no ha querido contarte qué le ha dicho."

    yup "(El eco de Sora ha dicho algo.)"
    yup "(Algo que él no quiere repetir.)"
    yup "(¿Qué tipo de mensaje es ese?)"

    # ── Deducción interactiva ──
    $ opciones_ded2_2 = [
        ("El eco repite lo que decimos, pero al revés.", False),
        ("El eco dice lo que pensamos. No lo que decimos.", True),
        ("El eco está roto. Dice cosas al azar.", False),
        ("El eco es la torre hablándonos.", False),
    ]

    call screen deduccion_interactiva(
        pregunta="¿Qué crees que dice realmente el eco?",
        opciones=opciones_ded2_2,
        pista_ok="El eco dice lo que piensas",
        pista_key="p2_eco_dice_pensamientos"
    )

    return