# ═══════════════════════════════════════════════════════════════
#  50cap01_notas.rpy — Notas de Akira
#  -----------------------------------------------------------------
#  Apuntes que Akira escribe durante el capítulo.
#  Se pueden releer desde un menú.
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Persistencia ──
    if not hasattr(persistent, "notas_descubiertas") or persistent.notas_descubiertas is None or isinstance(persistent.notas_descubiertas, bool):
        persistent.notas_descubiertas = {}

    # ── Catálogo de notas ──
    # Formato: NOTAS[historia][clave] = { "titulo", "icono", "capitulo", "texto" }
    NOTAS = {
        "torre": {
            "nota_puerta": {
                "titulo": "La puerta que se cierra",
                "icono": "🚪",
                "capitulo": 1,
                "texto": (
                    "Lo único que recuerdo es una puerta cerrándose. Nada más. Ni el sitio, "
                    "ni el momento, ni por qué estaba allí. Solo el ruido. Y luego, esto. "
                    "Puede que sea un recuerdo inventado. Puede que mi cabeza esté rellenando "
                    "los huecos. O puede que sea real."
                ),
            },
            "nota_marca": {
                "titulo": "«Ayúdame...»",
                "icono": "🩸",
                "capitulo": 1,
                "texto": (
                    "La marca en la pared está hecha con las uñas. Y con sangre seca. "
                    "Dice «ayúdame...» con puntos suspensivos. Eso es lo que más me inquieta. "
                    "Los puntos suspensivos. Como si quien lo escribió no hubiera terminado. "
                    "O como si alguien le hubiera tapado la boca antes."
                ),
            },
            "nota_ren_confianza": {
                "titulo": "Ren",
                "icono": "👤",
                "capitulo": 1,
                "texto": (
                    "Le he dicho que confío en él. Y no sé por qué. No lo conozco de nada. "
                    "Pero hay algo en su forma de hablar que me hace querer creerle. "
                    "No sé si es bueno o malo. Solo sé que no quiero estar aquí solo."
                ),
            },
            "nota_ren_distancia": {
                "titulo": "Ren (distancia)",
                "icono": "👤",
                "capitulo": 1,
                "texto": (
                    "No le he dicho que confío en él. Y me alegro. No lo conozco. "
                    "No sé quién es. No sé qué hace aquí. Puede ser cualquiera. "
                    "Puede ser alguien que no debería estar aquí. Pero por algún motivo, "
                    "cuando no insiste, me molesta. Como si quisiera que insistiera."
                ),
            },
            "nota_simbolo": {
                "titulo": "El símbolo del suelo",
                "icono": "🔯",
                "capitulo": 1,
                "texto": (
                    "Hay un símbolo tallado en el suelo del pasillo. Es simétrico. "
                    "No es un grafiti. No es un rayón. Es algo hecho a propósito. "
                    "Y tiene el mismo trazo que las letras de la pared. Los mismos "
                    "arañazos. La misma desesperación. Estoy empezando a pensar que "
                    "todo esto lo hizo la misma persona. O la misma cosa."
                ),
            },
            "nota_susurro": {
                "titulo": "El·yon",
                "icono": "👁️",
                "capitulo": 1,
                "texto": (
                    "Solo yo lo he oído. Ren no. Y la voz ha dicho una palabra que "
                    "no conozco: El·yon. No sé si es un nombre, un sitio o una cosa. "
                    "Pero lo he oído antes. Y no debería. Porque no he estado aquí nunca. "
                    "¿Verdad?"
                ),
            },
            "nota_puerta_grabados": {
                "titulo": "La puerta con grabados",
                "icono": "🔑",
                "capitulo": 1,
                "texto": (
                    "La puerta de salida tiene símbolos grabados. Los mismos que los "
                    "de la pared. Los mismos que los del suelo. Es como si la puerta "
                    "estuviera cerrada con una contraseña. O como si estuviera cerrada "
                    "para alguien en concreto. Para mí. Para él. Para alguien que no "
                    "fuéramos nosotros."
                ),
            },
        },
    }


    # ── Funciones ──
    def desbloquear_nota(historia, clave, titulo_override=None, texto_override=None):
        """
        Desbloquea una nota del catálogo.
        Acepta DOS firmas:
          - desbloquear_nota("torre", "nota_puerta")
          - desbloquear_nota("torre", "nota_espejo_no_imita", "El espejo que no imita", "Hay un espejo...")

        Si la nota NO existe en NOTAS[historia][clave] y se pasan
        titulo_override + texto_override, se crea una entrada nueva
        al vuelo con esos datos (para que funcione aunque el catálogo
        no la tenga definida todavía).

        :param historia: id de historia (ej. "torre")
        :param clave: clave de la nota
        :param titulo_override: (opcional) título si la nota no existe en el catálogo
        :param texto_override: (opcional) texto si la nota no existe en el catálogo
        """
        # Asegurar que el diccionario NOTAS tiene la historia
        if historia not in NOTAS:
            NOTAS[historia] = {}

        # Si la nota no existe en el catálogo y nos pasan los datos, la creamos
        if clave not in NOTAS[historia]:
            if titulo_override is not None and texto_override is not None:
                NOTAS[historia][clave] = {
                    "titulo": titulo_override,
                    "icono": "📝",
                    "capitulo": 0,
                    "texto": texto_override,
                }
            else:
                # No existe y no nos dan datos → no se puede desbloquear
                return False

        # Si ya estaba desbloqueada, no hacemos nada
        if nota_desbloqueada(historia, clave):
            return False

        # Desbloquear
        persistent.notas_descubiertas.setdefault(historia, {})[clave] = True

        # ── Sonido de pluma escribiendo ──
        try:
            renpy.sound.play("audio/sfx/escribir.ogg", channel="sound")
        except Exception:
            pass

        notificar("📝", "Nota añadida", NOTAS[historia][clave]["titulo"], "#E8C06A")
        return True

    def nota_desbloqueada(historia, clave):
        return persistent.notas_descubiertas.get(historia, {}).get(clave, False)

    def notas_descubiertas_cap(historia, cap):
        """Cuenta notas descubiertas de un capítulo concreto."""
        if historia not in NOTAS:
            return 0
        return sum(1 for k, v in NOTAS[historia].items() if v.get("capitulo") == cap and nota_desbloqueada(historia, k))

    def notas_totales(historia):
        if historia not in NOTAS:
            return 0
        return len(NOTAS[historia])

    def notas_de_capitulo(historia, cap):
        if historia not in NOTAS:
            return []
        return [k for k, v in NOTAS[historia].items() if v.get("capitulo") == cap]

    def notas_descubiertas(historia):
        """Cuenta notas descubiertas de una historia."""
        if historia not in NOTAS:
            return 0
        return sum(1 for k in NOTAS[historia].keys() if nota_desbloqueada(historia, k))

    def notas_descubiertas_cap(historia, cap):
        """Cuenta notas descubiertas de un capítulo concreto."""
        if historia not in NOTAS:
            return 0
        return sum(1 for k, v in NOTAS[historia].items() if v.get("capitulo") == cap and nota_desbloqueada(historia, k))


# ═══════════════════════════════════════════════════════════════
#  SCREEN: NOTAS DE AKIRA
# ═══════════════════════════════════════════════════════════════
screen notas_menu():
    tag menu
    modal True

    default historia_actual = "torre"
    default nota_seleccionada = None

    add "#00000000"

    frame:
        xalign 0.5
        yalign 0.5
        xsize 1100
        ysize 800
        background Solid("#1a1408")
        padding (30, 25)

        has vbox spacing 14 xfill True

        # ── Cabecera ──
        hbox:
            spacing 15
            xalign 0.5
            yalign 0.5

            text "📝":
                size 42
                yalign 0.5

            vbox:
                spacing 2
                yalign 0.5

                text "NOTAS DE AKIRA":
                    size 32
                    bold True
                    color "#E8C06A"

                text "Apuntes escritos durante la historia":
                    size 14
                    color "#A08050"

        text "Notas descubiertas: [notas_descubiertas(historia_actual)] / [notas_totales(historia_actual)]":
            size 14
            color "#888"
            xalign 0.5

        null height 5

        # ── Contenido en 2 columnas ──
        hbox:
            spacing 20
            xfill True
            yfill True

            # ── Columna izquierda: lista de notas ──
            frame:
                xsize 380
                yfill True
                background Solid("#0f0a04")
                padding (15, 15)

                has vbox spacing 8

                text "▸ Notas" size 16 bold True color "#E8C06A"

                viewport:
                    xfill True
                    yfill True
                    mousewheel True
                    scrollbars "vertical"

                    has vbox spacing 6

                    $ claves = list(NOTAS[historia_actual].keys())
                    if claves:
                        for nkey in claves:
                            $ ndata = NOTAS[historia_actual][nkey]
                            $ unlocked = nota_desbloqueada(historia_actual, nkey)
                            $ es_actual = (nota_seleccionada == nkey)

                            button:
                                xfill True
                                background (Solid("#3a2a10") if es_actual else Solid("#1a1408"))
                                hover_background Solid("#2a1f0c")
                                padding (12, 10)
                                sensitive unlocked
                                action SetScreenVariable("nota_seleccionada", nkey)

                                has hbox spacing 10

                                text ("[ndata['icono']]" if unlocked else "🔒") size 22 yalign 0.5

                                vbox:
                                    spacing 2
                                    yalign 0.5
                                    xfill True

                                    text (("[ndata['titulo']]") if unlocked else "Nota bloqueada"):
                                        size 14
                                        bold True
                                        color ("#E8C06A" if unlocked else "#444")

                                    if not unlocked:
                                        text "Encuéntrala durante la historia" size 11 color "#555" italic True
                    else:
                        text "No hay notas todavía." size 13 color "#555" italic True

            # ── Columna derecha: contenido de la nota seleccionada ──
            frame:
                xfill True
                yfill True
                background Solid("#0f0a04")
                padding (20, 20)

                if nota_seleccionada and nota_desbloqueada(historia_actual, nota_seleccionada):
                    $ ndata = NOTAS[historia_actual][nota_seleccionada]

                    vbox:
                        spacing 15

                        # Cabecera
                        hbox:
                            spacing 15
                            text "[ndata['icono']]" size 60 yalign 0.5
                            vbox:
                                spacing 4
                                yalign 0.5
                                text "[ndata['titulo']]":
                                    size 26
                                    bold True
                                    color "#E8C06A"
                                text "Capítulo [ndata['capitulo']]":
                                    size 13
                                    color "#A08050"
                                    italic True

                        # Separador
                        frame:
                            xfill True
                            ysize 2
                            background Solid("#3a2a10")

                        # Texto de la nota
                        viewport:
                            xfill True
                            yfill True
                            mousewheel True
                            scrollbars "vertical"

                            text "[ndata['texto']]":
                                size 15
                                color "#d8c8a8"
                                xmaximum 580
                else:
                    vbox:
                        spacing 15
                        xalign 0.5
                        yalign 0.5

                        text "📝" size 80 xalign 0.5
                        text "Selecciona una nota" size 22 color "#A08050" xalign 0.5
                        text "Elige una nota de la izquierda para leerla." size 14 color "#666" xalign 0.5

        # ── Botón Volver ──
        textbutton "← Volver":
            style "menu_button"
            xalign 0.5
            action ShowMenu("extras_menu")


# ═══════════════════════════════════════════════════════════════
#  LABELS DE LLAMADA
# ═══════════════════════════════════════════════════════════════

# ── Nota: la puerta que se cierra ──
label cap01_nota_puerta:
    $ desbloquear_nota("torre", "nota_puerta")
    return


# ── Nota: la marca en la pared ──
label cap01_nota_marca:
    n "..."

    akp "(Debería apuntar esto.)"
    akp "(Antes de que se me olvide.)"

    $ desbloquear_nota("torre", "nota_marca")

    n "Sacas un bolígrafo del bolsillo. No recuerdas tenerlo."

    n "Pero lo tienes. Y escribes en la palma de la mano."

    return


# ── Nota: Ren (confianza) ──
label cap01_nota_ren_confianza:
    $ desbloquear_nota("torre", "nota_ren_confianza")
    return


# ── Nota: Ren (distancia) ──
label cap01_nota_ren_distancia:
    $ desbloquear_nota("torre", "nota_ren_distancia")
    return


# ── Nota: el símbolo del suelo ──
label cap01_nota_simbolo:
    $ desbloquear_nota("torre", "nota_simbolo")
    return


# ── Nota: El·yon ──
label cap01_nota_susurro:
    $ desbloquear_nota("torre", "nota_susurro")
    return


# ── Nota: la puerta con grabados ──
label cap01_nota_puerta_grabados:
    $ desbloquear_nota("torre", "nota_puerta_grabados")
    return