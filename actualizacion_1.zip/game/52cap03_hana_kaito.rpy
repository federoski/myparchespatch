# ═══════════════════════════════════════════════════════════════
#  52cap03_hana_kaito.rpy — Capítulo 3: La grieta
#  -----------------------------------------------------------------
#  Pareja: Hana & Kaito
#  Posición: Hana (izq) + Kaito (der)
#  Finales: bueno / bueno_especial / kaito_muere / hana_muere / ambos_quedan
#  Minijuego: TIMING
#  Exploración: menú con flechas (3 zonas)
#  Diccionario: telon_no_abre, aplauso_vacio, puerta_teatro, cinta_rosa
#  Fichas: hana, kaito
#  Bestiario: telon, voces
#  Pistas tablón: 6
#  Deducciones: 2
#  Flashbacks: 2
#  Eco El·yon: 3 apariciones
#
#  ⚠️ NOTA: Los labels cap03_nota_*, cap03_flashback_*,
#     cap03_deduccion_*, cap03_eco_*, cap03_pulsar_* están
#     definidos en sus respectivos archivos auxiliares
#     (52cap03_notas.rpy, 52cap03_flashbacks.rpy,
#      52cap03_deducciones.rpy, 52cap03_eco.rpy,
#      52cap03_objetos.rpy). NO se duplican aquí.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES
# ─────────────────────────────────────────────────────────────
define hap = Character(
    "Hana",
    color="#f48fb1",
    what_color="#f0d0d8",
    what_italic=True,
    what_size=28
)

define kap = Character(
    "Kaito",
    color="#ef5350",
    what_color="#f0c0c0",
    what_italic=True,
    what_size=28
)

define elyon_voz = Character(
    "???",
    color="#8b0000",
    what_color="#CC4444",
    what_italic=True,
    what_size=32
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES (placeholders temporales)
# ─────────────────────────────────────────────────────────────
image bg_piso3_despertar = Solid("#261818")
image bg_piso3_escenario = Solid("#2a1e18")
image bg_piso3_camerinos = Solid("#221c1a")
image bg_piso3_telon = Solid("#2a1818")
image bg_piso3_salida = Solid("#3a2e1c")

image cap03_programa = Solid("#26201a")
image cap03_puerta_teatro = Solid("#1a1814")

image cap3_final_bueno = Solid("#e0b878")
image cap3_final_kaito_muere = Solid("#221820")
image cap3_final_hana_muere = Solid("#1e1622")
image cap3_final_ambos_quedan = Solid("#1a1418")


# ═══════════════════════════════════════════════════════════════
#  CAPÍTULO 3
# ═══════════════════════════════════════════════════════════════
label capitulo_3:

    # ── Pantalla de carga ──
    $ _cap_data = capitulos.historias["torre"]["actos"].get(3, {})
    $ _nombre_cap = _cap_data.get("nombre", "La grieta")
    $ _sub_cap = _cap_data.get("sub", "Hana & Kaito")
    $ _icono_cap = _cap_data.get("icono", "🕯️")
    call mostrar_pantalla_carga("torre", 3, _nombre_cap, _sub_cap, _icono_cap)

    $ gtn_reiniciar_metricas()
    $ gtn_capitulo_actual = 3
    $ capitulos.desbloquear_capitulo("torre", 3)
    $ registrar_capitulo_jugado(3)

    scene black
    with fade

    show screen gtn_notif_screen
    $ musica("torre_ambiente", fade=2.0)

    $ add_achievement_with_popup(achievement_tercer_despertar)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 1 — EL DESPERTAR
    # ═══════════════════════════════════════════════════════════

    n "Lo primero que notas es el polvo."
    n "En la nariz. En la garganta. En los ojos."
    n "Lo segundo, el silencio."
    n "Pero un silencio que no está vacío."
    n "Un silencio que está esperando."

    scene bg_piso3_despertar
    with fade

    n "Abres los ojos."
    n "Estás sentada en la última fila de un teatro."
    n "Las butacas a tu alrededor están cubiertas de polvo."
    n "Algunas están ocupadas."
    n "Por siluetas. Que no se mueven."

    show hana_img at left
    with dissolve

    ha "...¿Dónde...?"
    ha "¿Qué es este sitio?"

    n "Te incorporas con cuidado. No quieres hacer ruido."
    n "No sabes por qué, pero sientes que si haces ruido, algo va a despertar."

    hap "(Hay alguien sentado. En las butacas del medio.)"
    hap "(Pero no se mueve. No respira. No es nadie.)"

    $ desbloquear_ficha("torre", "hana")
    $ add_achievement_with_popup(achievement_conoce_hana)

    ha "No estabas aquí antes. Esto no estaba aquí antes."
    ha "Papá siempre decía que los sitios abandonados se quedan con algo."
    ha "Espero que este no se haya quedado conmigo."

    $ desbloquear_pista("torre", "p3_telon_subido")

    # ── Decisión 1 ──
    menu:
        "¿Qué haces?"

        "Quedarte quieta. Escuchar.":
            $ modificar_metrica("miedo", +8)
            $ modificar_metrica("angustia", +10)
            $ gtn_flag("hana_escucha", True)
            $ registrar_decision()

            ha "..."
            n "Escuchas. Durante mucho tiempo. Sin moverte."
            n "Y entonces lo oyes."
            n "Un aplauso. Muy lento. Muy lejano."
            n "Como si viniera de dentro del telón."
            n "Y luego se apaga."
            ha "Eso no ha sido una grabación."
            hap "(No ha sido una grabación.)"
            hap "(Ha sido... alguien.)"

        "Levantarte y caminar hacia el escenario.":
            $ modificar_metrica("miedo", +10)
            $ modificar_metrica("angustia", +5)
            $ gtn_flag("hana_camina", True)
            $ registrar_decision()

            ha "Vale. Vale, tranquilita."
            n "Te levantas. Caminas por el pasillo central."
            n "Las butacas a los lados. Algunas con siluetas."
            n "Al pasar junto a una, juras haber visto moverse algo."
            n "Pero cuando te giras, está quieta."
            ha "No mires. No mires. No mires."
            n "Miras. Está quieta."
            hap "(O eso creo.)"
            hap "(No estoy segura.)"

        "Llamar a alguien. A quien sea.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +12)
            $ gtn_flag("hana_llama", True)
            $ registrar_decision()
            $ gtn_flag("grito_alguna_vez", True)

            ha "¿Hola? ¿Hay alguien?"
            n "Tu voz no hace eco."
            n "El teatro se la traga."
            n "Como si no hubiera estado nunca."
            ha "..."
            ha "Vale. Pues no vuelvo a hablar."
            hap "(Pero necesito hablar con alguien.)"
            hap "(Necesito saber que no estoy sola.)"

    if estado_minimo("miedo", 40):
        hap "(Me tiemblan las manos.)"
        hap "(No debería. Solo son butacas.)"
        hap "(Pero hay alguien sentado. Y no se mueve.)"

    if estado_extremo("angustia"):
        n "Sientes que te falta el aire. Y no hay ninguna razón para ello."
        hap "(Respira. Respira. Respira.)"
        hap "(No estás en peligro. Todavía.)"

    call cap03_eco_1
    $ add_achievement_with_popup(achievement_primera_decision)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 2 — EL TEATRO
    # ═══════════════════════════════════════════════════════════

    n "Entonces lo ves."
    n "En una de las filas del medio. Un chico. Sentado. Con los ojos cerrados."
    n "Como si estuviera dormido."
    n "Pero no está dormido. Está conteniendo la respiración."

    show kaito_img at right
    with dissolve

    ka "...Ya te he oído."
    ha "¿Qué?"
    ka "Que ya te he oído. Llevas cinco minutos hablando sola."
    ka "¿Estás bien?"
    ha "Sí. Creo."
    ka "Yo también. Creo."

    n "El chico abre los ojos. Son rojizos. Y cansados."

    ka "Kaito."
    ha "Hana."
    ka "Vale, Hana. Vamos a salir de aquí."

    $ desbloquear_ficha("torre", "kaito")
    $ add_achievement_with_popup(achievement_conoce_kaito)

    n "Hay algo en su forma de hablar que te resulta familiar."
    n "Y no sabes por qué."

    if gtn_flag("hana_escucha"):
        ka "Te has quedado muy quieta."
        ka "¿Has oído algo?"
        ha "Un aplauso. Muy lejano."
        ka "..."
        ka "Yo también lo he oído."
        hap "(Él también.)"
        hap "(Entonces no estoy loca.)"

    elif gtn_flag("hana_camina"):
        ka "Te he visto caminar por el pasillo."
        ka "Has pasado al lado de una silueta. Y no te has dado cuenta."
        ha "¿Qué?"
        ka "La silueta se ha girado cuando has pasado."
        ha "..."
        hap "(¿Se ha girado?)"
        hap "(No he visto nada.)"

    elif gtn_flag("hana_llama"):
        ka "Te he oído gritar."
        ka "Pero tu voz no hacía eco."
        ha "¿Y eso qué significa?"
        ka "Que este sitio se queda con las voces."
        ka "Y no las devuelve."
        hap "(Se queda con las voces.)"
        hap "(Con las palabras.)"
        hap "(Con las personas.)"

    if estado_minimo("angustia", 50):
        n "Kaito te mira. Y por un momento, ves algo en sus ojos que no habías visto."
        n "Cansancio. Cansancio de verdad."
        hap "(No es solo el teatro.)"
        hap "(Lleva esto dentro desde antes de llegar.)"

    if estado_minimo("amor", 30):
        n "Y sin embargo, sonríe. Como si, a pesar de todo, estuviera bien."
        hap "(¿Por qué sonríe?)"
        hap "(No hay nada que sonreír.)"

    if estado_minimo("miedo", 60):
        n "Tú no sonríes. No puedes."
        hap "(Me tiembla la voz.)"
        hap "(No puedo dejar que lo note.)"

    # ── Decisión 2 ──
    menu:
        "¿Cómo reaccionas?"

        "Preguntarle por qué estaba aquí.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("hana_pregunta", True)
            $ registrar_decision()

            ha "¿Por qué estabas aquí?"
            ka "No lo sé."
            ka "Me desperté. Estaba en una butaca. Con el telón subido."
            ha "¿El telón?"
            ka "Sí. Cuando me desperté, el telón estaba subido. Y había alguien en el escenario."
            ka "Pero cuando me acerqué, ya no."
            ha "..."
            ka "Prefiero no hablar de eso."
            hap "(Alguien en el escenario.)"
            hap "(¿Quién?)"

        "Contarle que has oído un aplauso.":
            $ modificar_metrica("amor", +10)
            $ modificar_metrica("miedo", +5)
            $ gtn_flag("hana_cuenta", True)
            $ registrar_decision()

            ha "Yo he oído algo."
            ka "¿El qué?"
            ha "Un aplauso. Muy lento. Muy lejano."
            ka "..."
            ka "Yo también."
            ka "Pero no quería decirlo."
            ha "Entonces no estamos locos."
            ka "O estamos los dos."
            ha "Peor."

        "Confiar en él directamente.":
            $ modificar_metrica("amor", +15)
            $ modificar_metrica("miedo", -5)
            $ gtn_flag("hana_confia", True)
            $ registrar_decision()

            ha "Vale. Confío en ti."
            ka "...¿Así, sin más?"
            ha "No tengo mucho donde elegir."
            n "Kaito sonríe de lado. Pero la sonrisa no le llega a los ojos."
            hap "(Sonríe como si supiera algo.)"
            hap "(Pero no lo dice.)"

    if gtn_flag("hana_confia"):
        ka "Me alegra que confíes en mí."
        ka "Aunque no deberías."
        ha "¿Qué?"
        ka "Nada. Olvídalo."
        hap "(Ha dicho algo importante.)"
        hap "(Pero no lo ha dicho.)"

    if peso_tomado("cap2_confio_sora"):
        hap "(En el piso 2, confiaron el uno en el otro.)"
        hap "(Y salió bien.)"

    elif peso_tomado("cap2_pregunto_sora"):
        hap "(En el piso 2, hicieron preguntas.)"
        hap "(Quizá debería hacer yo también.)"

    call cap03_flashback_hana_hermana

    # ═══════════════════════════════════════════════════════════
    #  OBJETO 1 — El programa de mano
    # ═══════════════════════════════════════════════════════════

    n "En el suelo, junto a tu butaca, hay un papel."
    n "Amarillento. Arrugado."
    n "Como si alguien lo hubiera tirado hace mucho tiempo."

    call screen cap03_programa_interactivo
    call cap03_pulsar_programa

    # ═══════════════════════════════════════════════════════════
    #  ACTO 3 — LA EXPLORACIÓN
    # ═══════════════════════════════════════════════════════════

    n "Recorréis el teatro juntos."
    n "Kaito va delante. Tú, detrás."
    n "En las paredes, hay carteles de obras antiguas. Todos con la misma frase subrayada."
    n "«El telón no se abre»."

    $ musica("tension_baja", fade=2.0)

    $ zonas_exploradas = []
    call cap03_exploracion
    jump cap03_tras_exploracion


# ═══════════════════════════════════════════════════════════════
#  TRAS LA EXPLORACIÓN
# ═══════════════════════════════════════════════════════════════
label cap03_tras_exploracion:
    scene bg_piso3_escenario
    with fade

    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Subís al escenario."
    n "Desde aquí, el teatro se ve entero."
    n "Las butacas. Las siluetas. El silencio."

    if peso_tomado("cap2_cogio_mano"):
        n "Y por un momento, ves algo más que el telón."
        n "Dos figuras cruzaron por aquí. Una chica y un chico."
        n "Juntos. Cogidos de la mano."
        hap "(¿Quiénes eran?)"
        hap "(No los conozco.)"
        hap "(Pero creo que los he visto en algún sitio.)"

    elif peso_tomado("cap2_leyo_inscripcion"):
        n "Y por un momento, ves algo más que el telón."
        n "Hay un símbolo tallado en la madera del escenario."
        n "El mismo símbolo de los espejos del piso 2."
        hap "(No.)"
        hap "(El mismo símbolo que Yuki vio allí.)"

    ka "Esto es un teatro de verdad."
    ha "¿Cómo lo sabes?"
    ka "Porque esto es un escenario. Y yo he estado en muchos."
    ha "¿Actuabas?"
    ka "..."
    ka "Algo así."

    n "Kaito no dice más. No insistes."
    n "Pero en la forma en que mira las luces, entiendes que no te ha mentido."

    call cap03_flashback_kaito_barrio
    call cap03_deduccion_1

    # ── CAMERINOS ──
    scene bg_piso3_camerinos
    with fade

    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Detrás del escenario, un pasillo con camerinos."
    n "Las puertas están entreabiertas."
    n "En las paredes, fotos de actores. Todos con la cara arañada."

    ka "Aquí ha pasado algo."
    ha "¿Qué te hace pensar eso?"
    ka "Todo."

    n "Kaito abre uno de los camerinos."
    n "Dentro, un espejo roto. Y una silla. Y nada más."

    ka "Aquí tampoco."

    if estado_minimo("angustia", 60):
        hap "(Me pesa la cabeza.)"
        hap "(Como si tuviera algo dentro que quiere salir.)"
        hap "(Y no puedo dejar que salga.)"

    # ── EL APLAUSO ──
    n "Y entonces lo oís."

    $ sonido("aplauso_vacio")

    n "Un aplauso."
    n "Lento. Muy lento."
    n "Viene del patio de butacas."
    n "Y ahora no se apaga."

    $ aprender_palabra("torre", "aplauso_vacio")
    $ desbloquear_bestiario("torre", "voces")
    $ desbloquear_pista("torre", "p3_aplauso_vacio")
    call cap03_nota_aplauso

    if estado_extremo("terror"):
        hap "(Lo he oído. Lo he oído de verdad.)"
        hap "(No estoy loca. No estoy loca.)"
        hap "(¿O sí?)"
        n "Te llevas las manos a las orejas. Como si quisieras tapar algo."
        ka "Hana. Hana, mírame."
        ha "Estoy bien."
        ka "No. No lo estás."
        n "Y por primera vez, no sabes qué contestar."

    if estado_minimo("amor", 50):
        ka "Sea lo que sea que has oído..."
        ka "No estás sola."
        ha "..."
        hap "(No estoy sola.)"
        hap "(Nunca había pensado eso.)"
        hap "(Y ahora que lo pienso, no sé qué hacer con ello.)"

    if estado_minimo("odio", 50):
        hap "(No quiero que me vea así.)"
        hap "(No quiero que nadie me vea así.)"
        n "Te apartas un poco de Kaito. Sin darte cuenta."
        ka "..."
        n "Kaito no dice nada. Pero lo nota."

    ha "Kaito. ¿Estás oyendo eso?"
    ka "Sí."

    call cap03_eco_2

    # ═══════════════════════════════════════════════════════════
    #  ACTO 4 — EL TELÓN
    # ═══════════════════════════════════════════════════════════

    scene bg_piso3_telon
    with fade

    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Volvéis al escenario."
    n "El telón está empezando a bajarse."
    n "Muy despacio. Muy lento."
    n "Pero se está bajando."

    ka "¡Por aquí!"
    ha "¡Kaito, espera!"
    n "El telón baja más rápido."

    call screen cap03_puerta_teatro_interactivo
    call cap03_pulsar_puerta_teatro

    ka "¡No hay tiempo! ¡Corre!"

    call cap03_deduccion_2

    if peso_tomado("cap1_respiro"):
        hap "(He aprendido a calmarme cuando tengo miedo.)"
        hap "(Respirar. Como en el piso 1.)"
        hap "(Eso me ayudó antes. Puede ayudarme ahora.)"
        $ modificar_metrica("miedo", -5)

    # ── LOGROS ACUMULATIVOS ──
    if gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido") and gtn_flag("eco_3_oido"):
        $ add_achievement_with_popup(achievement_eco_completo_cap3)

    if gtn_flag("fb_hana_visto") and gtn_flag("fb_kaito_visto"):
        $ add_achievement_with_popup(achievement_recuerdos_cap3)

    if notas_descubiertas_cap("torre", 3) >= 5:
        $ add_achievement_with_popup(achievement_notas_completas_cap3)

    if objeto_visto("programa_teatro") and objeto_visto("puerta_teatro"):
        $ add_achievement_with_popup(achievement_objetos_cap3)

    if deduccion_jugador_acertada("cap03_ded1") and deduccion_jugador_acertada("cap03_ded2"):
        $ add_achievement_with_popup(achievement_deducciones_cap3)

    if not gtn_flag("grito_alguna_vez"):
        $ add_achievement_with_popup(achievement_oculto_no_grito)

    if gtn_ecos_oidos >= 9:
        $ add_achievement_with_popup(achievement_oculto_oyo_todo)

    $ _especiales = 0
    if peso_tomado("cap1_cogio_mano"):
        $ _especiales += 1
    if peso_tomado("cap2_cogio_mano"):
        $ _especiales += 1
    if peso_tomado("cap3_confiesa"):
        $ _especiales += 1
    if _especiales >= 3:
        $ add_achievement_with_popup(achievement_oculto_vio_todo)

    if gtn_puertas_pulsadas >= 3:
        $ add_achievement_with_popup(achievement_oculto_puertas)

    # ═══════════════════════════════════════════════════════════
    #  MINIJUEGO — TIMING
    # ═══════════════════════════════════════════════════════════

    $ musica("tension_alta", fade=0.5)

    if estado_extremo("miedo"):
        hap "(No puedo. No puedo hacerlo.)"
        hap "(Voy a fallar. Voy a fallar.)"
        hap "(Como siempre.)"
        n "Te tiemblan las manos."
        ka "Hana. Mírame."
        ha "..."
        ka "Vas a pulsar en el momento justo. Y yo voy a salir contigo. ¿Vale?"
        hap "(¿Por qué confía en mí?)"
        hap "(No debería.)"

    if estado_minimo("terror", 60):
        hap "(El telón es demasiado rápido.)"
        hap "(No voy a llegar.)"
        hap "(Lo sé.)"

    n "Tenéis que pasar los dos. A la vez."
    n "Si uno se retrasa, el otro se queda."
    n "El telón va a cerrarse."

    call lanzar_timing(velocidad=1.2, zona_buena=0.15)

    if gtn_minijuego_resultado:
        $ registrar_minijuego(True)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Pulsas en el momento justo."
        n "Los dos cruzáis el telón al mismo tiempo."
        n "La tela cae detrás de vosotros."
        n "Y la puerta se abre."

        $ modificar_metrica("amor", +20)
        $ modificar_metrica("miedo", -5)

        call cap03_eco_3

        menu:
            "¿Qué haces?"

            "Salir juntos, cogidos de la mano.":
                $ registrar_decision()
                $ registrar_peso("cap3_cogio_mano")
                jump cap3_final_bueno

            "Empujar a Kaito primero.":
                $ registrar_decision()
                jump cap3_final_hana_muere

            "Quedarte tú atrás, aguantando el telón.":
                $ registrar_decision()
                jump cap3_final_kaito_muere

            "Decirle lo que sientes antes de cruzar." if estado_minimo("amor", 70) and estado_maximo("miedo", 40):
                $ modificar_metrica("amor", +15)
                $ gtn_flag("hana_confiesa", True)
                $ registrar_decision()
                $ registrar_peso("cap3_confiesa")

                ha "Kaito."
                ka "¿Qué?"
                ha "Yo..."
                n "No terminas la frase."
                n "Pero él te mira. Y por primera vez, ves algo en sus ojos que no es rabia."
                n "Y los dos cruzáis la puerta juntos."
                jump cap3_final_bueno_especial
    else:
        $ registrar_minijuego(False)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Falláis."
        n "El telón cae."
        n "Y con él, el suelo."
        n "Los dos caéis hacia abajo."

        $ musica("final_malo", fade=1.0)
        jump cap3_final_ambos_quedan


# ═══════════════════════════════════════════════════════════════
#  FINALES DEL CAPÍTULO 3
# ═══════════════════════════════════════════════════════════════

label cap3_final_bueno:
    scene bg_piso3_salida
    with fade
    show hana_img at left
    show kaito_img at right
    with dissolve

    ha "Juntos."
    ka "Juntos."
    n "Salís los dos por la puerta."
    n "La escalera sube."
    n "Detrás de vosotros, el teatro queda en silencio."

    $ musica("final_bueno", fade=2.0)
    scene cap3_final_bueno
    with Dissolve(1.5)

    n "La luz os traga."
    n "Y luego, silencio."
    n "Kaito te mira un momento antes de desaparecer."
    n "Y por primera vez, ves algo en sus ojos que no es rabia."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 3 superado."

    $ registrar_final_bueno()
    $ registrar_ruta(3, "bueno")
    $ guardar_estados_capitulo(3, "torre")
    $ unlock_final("torre", 3, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap3)
    $ add_achievement_with_popup(achievement_cap3_completado)
    $ desbloquear_imagen_galeria("cap3_bueno")
    $ capitulos.completar_capitulo("torre", 3)
    call marcar_final_bueno_cap(3, "torre")
    $ desbloquear_invocaciones_hasta(3)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("hana_confia"):
        $ registrar_peso("cap3_confio_kaito")
    if gtn_flag("hana_pregunta"):
        $ registrar_peso("cap3_pregunto_kaito")
    if gtn_flag("hana_respiro"):
        $ registrar_peso("cap3_respiro")

    "Capítulo 3 completado."
    jump volver_al_hub


label cap3_final_bueno_especial:
    scene bg_piso3_salida
    with fade
    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Cruzasteis juntos. Y no dijiste nada."
    n "Pero él te entendió."
    n "Y al otro lado, por primera vez, no había silencio."
    n "Había una puerta abierta. Y detrás, luz."

    $ musica("final_bueno", fade=2.0)
    scene cap3_final_bueno
    with Dissolve(1.5)

    n "Pero no era la salida."
    n "Era otra cosa."
    n "Era el inicio de algo que ninguno de los dos había previsto."
    n "Y en el teatro que quedaba atrás, el público aplaudía."
    n "Pero esta vez, los aplausos eran de verdad."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 3 superado. Pero no del todo."

    $ registrar_final_bueno()
    $ registrar_ruta(3, "bueno_especial")
    $ registrar_peso("cap3_confiesa")
    $ guardar_estados_capitulo(3, "torre")
    $ unlock_final("torre", 3, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap3)
    $ add_achievement_with_popup(achievement_cap3_completado)
    $ add_achievement_with_popup(achievement_final_especial_cap3)
    $ desbloquear_imagen_galeria("cap3_bueno")
    $ capitulos.completar_capitulo("torre", 3)
    call marcar_final_bueno_cap(3, "torre")
    $ desbloquear_invocaciones_hasta(3)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("hana_confia"):
        $ registrar_peso("cap3_confio_kaito")
    if gtn_flag("hana_pregunta"):
        $ registrar_peso("cap3_pregunto_kaito")
    if gtn_flag("hana_respiro"):
        $ registrar_peso("cap3_respiro")

    "Capítulo 3 completado (ruta especial)."
    jump volver_al_hub


label cap3_final_kaito_muere:
    scene bg_piso3_telon
    with fade
    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Empujas a Kaito hacia la puerta."
    ka "¡Hana, no!"
    ha "¡VE!"
    n "Kaito cruza."
    n "Tú te quedas un momento más. Aguantando el telón."
    n "El telón cae."
    n "La puerta se cierra."

    $ musica("final_malo", fade=1.5)
    scene cap3_final_kaito_muere
    with Dissolve(1.0)

    n "Y el teatro se queda en silencio."
    n "Sola."
    n "En el escenario."
    n "Con el telón bajado."
    n "Y con la chaqueta de Kaito. Que se ha quedado aquí."
    n "Como prueba."
    n "Como recuerdo."
    n "Como si ya no la necesitara."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El eco se apaga."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(3, "kaito_muere")
    $ guardar_estados_capitulo(3, "torre")
    $ unlock_final("torre", 3, "kaito_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap3_completado)
    $ desbloquear_imagen_galeria("cap3_kaito_muere")
    $ capitulos.completar_capitulo("torre", 3)
    $ desbloquear_invocaciones_hasta(3)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("hana_confia"):
        $ registrar_peso("cap3_confio_kaito")
    if gtn_flag("hana_pregunta"):
        $ registrar_peso("cap3_pregunto_kaito")
    if gtn_flag("hana_respiro"):
        $ registrar_peso("cap3_respiro")

    "Capítulo 3 completado (final malo)."
    jump volver_al_hub


label cap3_final_hana_muere:
    scene bg_piso3_telon
    with fade
    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Empujas a Kaito hacia la puerta."
    ka "¡Espera, no!"
    ha "¡Ve tú primero!"
    n "Kaito cruza."
    n "Y el telón cae antes de que puedas seguirlo."

    $ musica("final_malo", fade=1.5)
    scene cap3_final_hana_muere
    with fade

    n "Al otro lado, Kaito se queda solo."
    n "En el escenario."
    n "Con la cinta rosa de Hana en la mano."
    n "Y por primera vez en años, llora."
    n "No sabe por qué. No la conocía de nada."
    n "O eso cree."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El telón no se abre."
    n "Y Kaito ya no quiere que se abra."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(3, "hana_muere")
    $ guardar_estados_capitulo(3, "torre")
    $ unlock_final("torre", 3, "hana_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap3_completado)
    $ desbloquear_imagen_galeria("cap3_hana_muere")
    $ capitulos.completar_capitulo("torre", 3)
    $ desbloquear_invocaciones_hasta(3)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("hana_confia"):
        $ registrar_peso("cap3_confio_kaito")
    if gtn_flag("hana_pregunta"):
        $ registrar_peso("cap3_pregunto_kaito")
    if gtn_flag("hana_respiro"):
        $ registrar_peso("cap3_respiro")

    "Capítulo 3 completado (final malo)."
    jump volver_al_hub


label cap3_final_ambos_quedan:
    scene bg_piso3_escenario
    with fade
    show hana_img at left
    show kaito_img at right
    with dissolve

    n "El suelo se abre."
    n "Y caéis al escenario. Pero al escenario de otra cosa."
    n "De otra función."
    n "De la función que nunca se cerró."

    $ musica("final_malo", fade=1.0)
    scene cap3_final_ambos_quedan
    with fade

    n "Ahora estáis en el escenario."
    n "Y el público está lleno."
    n "Cada butaca ocupada. Por vosotros."
    n "Por versiones de vosotros que se quedaron aquí antes."
    n "Y vosotros sois uno más."
    n "Una fila más. Una butaca más."
    n "Y el telón sigue bajando."
    n "Pero esta vez, alguien lo sube."
    n "Y empieza la función."
    n "Otra vez."
    n "Y otra."
    n "Y otra."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "El eco se apaga."
    n "Pero no del todo."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(3, "ambos_quedan")
    $ guardar_estados_capitulo(3, "torre")
    $ unlock_final("torre", 3, "ambos_quedan")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap3_completado)
    $ desbloquear_imagen_galeria("cap3_ambos")
    $ capitulos.completar_capitulo("torre", 3)
    $ desbloquear_invocaciones_hasta(3)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("hana_confia"):
        $ registrar_peso("cap3_confio_kaito")
    if gtn_flag("hana_pregunta"):
        $ registrar_peso("cap3_pregunto_kaito")
    if gtn_flag("hana_respiro"):
        $ registrar_peso("cap3_respiro")

    "Capítulo 3 completado (final malo)."
    jump volver_al_hub


# ═══════════════════════════════════════════════════════════════
#  EXPLORACIÓN CON FLECHAS
# ═══════════════════════════════════════════════════════════════
label cap03_exploracion:

    call screen cap03_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap03_zona1

    call screen cap03_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap03_zona2

    call screen cap03_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap03_zona3

    return


screen cap03_exploracion_screen(zonas):
    modal True
    add "bg_piso3_despertar"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20

        text "EXPLORA EL TEATRO" size 30 color "#FFFFFF" xalign 0.5
        text "Zonas exploradas: [len(zonas)] / 3" size 18 color "#AAAAAA" xalign 0.5
        null height 20

        vbox:
            spacing 30
            xalign 0.5

            if 1 not in zonas:
                textbutton "↑ Subir al ESCENARIO" action Return(1) style "menu_button" xalign 0.5
            else:
                text "✔ Escenario (explorado)" size 16 color "#666" xalign 0.5

            if 2 not in zonas:
                textbutton "→ Ir a los CAMERINOS" action Return(2) style "menu_button" xalign 0.5
            else:
                text "✔ Camerinos (explorado)" size 16 color "#666" xalign 0.5

            if 3 not in zonas:
                textbutton "↓ Bajar al PATIO DE BUTACAS" action Return(3) style "menu_button" xalign 0.5
            else:
                text "✔ Patio de butacas (explorado)" size 16 color "#666" xalign 0.5


label cap03_zona1:
    scene bg_piso3_escenario
    with fade
    show hana_img at left
    with dissolve

    n "Subes al escenario."
    n "Desde aquí, el teatro se ve entero."
    n "Las butacas. Las siluetas. El silencio."
    n "Y detrás de ti, el telón."
    n "Cerrado. Pero no del todo."

    $ aprender_palabra("torre", "telon_no_abre")
    call cap03_nota_telon

    ha "«El telón no se abre»."
    ha "Eso es lo que dicen todos los carteles."
    ha "Pero yo lo he visto subido."

    $ desbloquear_pista("torre", "p3_programa_mano")
    call cap03_eco_2

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    show kaito_img at right
    with dissolve

    ka "¿Qué has encontrado?"
    ha "Nada. Solo... el telón."
    ka "..."
    ka "El telón no es nada."
    ha "¿Por qué lo dices?"
    ka "Porque si fuera algo, ya nos habría hecho algo."
    ha "..."
    ka "¿O no?"
    return


label cap03_zona2:
    scene bg_piso3_camerinos
    with fade
    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Los camerinos están en silencio."
    n "Las puertas entreabiertas. Las fotos arañadas."
    n "Hay algo en el aire. Como si alguien hubiera estado aquí hace poco."

    ka "Aquí ha pasado algo."
    ha "¿Qué te hace pensar eso?"
    ka "Todo."

    n "Kaito abre uno de los camerinos."
    n "Dentro, un espejo roto. Y una silla. Y nada más."

    ka "Aquí tampoco."

    call cap03_nota_camerino
    return


label cap03_zona3:
    scene bg_piso3_despertar
    with fade
    show hana_img at left
    show kaito_img at right
    with dissolve

    n "Bajáis al patio de butacas."
    n "Las siluetas siguen ahí. Sin moverse."
    n "Pero ahora, algunas parecen más cercanas que antes."

    ha "Kaito. Mira."
    ka "Ya lo veo."
    ha "Algunas butacas están vacías."
    ka "Sí."
    ha "¿Y si antes estaban ocupadas?"
    ka "..."
    ka "Prefiero no pensarlo."

    $ desbloquear_pista("torre", "p3_butacas_ocupadas")
    call cap03_nota_butacas

    $ modificar_metrica("miedo", +10)
    $ modificar_metrica("terror", +8)
    return


# ═══════════════════════════════════════════════════════════════
#  SCREENS INTERACTIVOS
# ═══════════════════════════════════════════════════════════════

screen cap03_programa_interactivo():
    modal True
    add "bg_piso3_despertar"
    button:
        xpos 0.4
        ypos 0.75
        xsize 300
        ysize 200
        background None
        hover_background "#FFAA0033"
        action Return()
    text "Pulsa el programa":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


screen cap03_puerta_teatro_interactivo():
    modal True
    add "bg_piso3_telon"
    button:
        xpos 0.4
        ypos 0.3
        xsize 350
        ysize 450
        background None
        hover_background "#FFAA0033"
        action Return()
    text "Pulsa la puerta":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint