# ═══════════════════════════════════════════════════════════════
#  53cap04_notas.rpy — Notas de Mei (Capítulo 4)
#  -----------------------------------------------------------------
#  Apuntes que Mei escribe durante el capítulo.
#  Se añaden al sistema de notas existente (50cap01_notas.rpy).
# ═══════════════════════════════════════════════════════════════

init python:
    # ── Añadir las notas del Cap 4 al catálogo existente ──
    if "torre" not in NOTAS:
        NOTAS["torre"] = {}

    NOTAS["torre"].update({
        "nota4_puertas_nombres": {
            "titulo": "Las puertas tienen nombres",
            "icono": "🚪",
            "capitulo": 4,
            "texto": (
                "Todas las puertas del pasillo tienen un nombre grabado. "
                "Arañado en la madera. Con las uñas, o con algo afilado. "
                "Algunos nombres me suenan. Otros no. Pero todos están ahí. "
                "Como si alguien hubiera querido que no se olvidaran. "
                "O como si alguien hubiera querido que yo no los olvidara. "
                "No sé qué es peor."
            ),
        },
        "nota4_llaves_colgadas": {
            "titulo": "El cuarto de las llaves",
            "icono": "🔑",
            "capitulo": 4,
            "texto": (
                "Hay un cuarto lleno de llaves. Cientos. Miles. "
                "Todas colgadas de la pared. Todas con una etiqueta "
                "con un nombre. Daichi dice que no son nuestras. "
                "Que son de los que ya no están. Pero yo he visto una "
                "que pone «Mei». Y no sé si eso significa que ya no "
                "estoy, o que voy a estar."
            ),
        },
        "nota4_morgue": {
            "titulo": "La morgue de Daichi",
            "icono": "🥶",
            "capitulo": 4,
            "texto": (
                "Daichi trabajó aquí. De noche. Dos años. No me lo ha "
                "contado todo. Pero en la forma en la que mira los "
                "cajones, entiendo que aquí pasó algo. Algo que no "
                "quiere recordar. Algo que esta morgue le está "
                "obligando a recordar. Y yo estoy aquí con él. "
                "Sin poder hacer nada."
            ),
        },
        "nota4_susurro_nombre": {
            "titulo": "El susurro dice mi nombre",
            "icono": "🗣️",
            "capitulo": 4,
            "texto": (
                "El susurro dice mi nombre. «Mei». Lo dice despacio. "
                "Como si me conociera. Como si llevara mucho tiempo "
                "diciéndolo. Pero yo no lo he oído nunca. Y no sé si "
                "quiero oírlo. Daichi también lo ha oído. Pero no ha "
                "querido decirme qué decía el suyo. Y yo no se lo he "
                "preguntado. Porque no quiero saberlo."
            ),
        },
        "nota4_puerta_19": {
            "titulo": "La puerta 19",
            "icono": "🚪",
            "capitulo": 4,
            "texto": (
                "Hay una puerta que no había visto antes. Sin nombre. "
                "Sin símbolos. Al final del pasillo. Y en mi cuaderno, "
                "en la última página, hay un dibujo de esa misma "
                "puerta. Con el número 19 debajo. Yo no la he dibujado. "
                "O no me acuerdo de haberla dibujado. Pero está ahí. "
                "Como si yo la hubiera creado. Y eso, de alguna forma, "
                "es peor que todas las demás."
            ),
        },
    })


# ═══════════════════════════════════════════════════════════════
#  LABELS DE LLAMADA — Notas del Cap 4
# ═══════════════════════════════════════════════════════════════

# ── Nota: los nombres en las puertas ──
label cap04_nota_puertas_nombres:
    n "..."

    mep "(Debería apuntar esto.)"
    mep "(Antes de que se me olvide.)"

    $ desbloquear_nota("torre", "nota4_puertas_nombres")

    n "Sacas un bolígrafo del bolsillo. No recuerdas tenerlo."

    n "Pero lo tienes. Y escribes en la palma de la mano."

    return


# ── Nota: el cuarto de las llaves ──
label cap04_nota_llaves:
    $ desbloquear_nota("torre", "nota4_llaves_colgadas")
    return


# ── Nota: la morgue ──
label cap04_nota_morgue:
    $ desbloquear_nota("torre", "nota4_morgue")
    return


# ── Nota: el susurro con nombre ──
label cap04_nota_susurro:
    $ desbloquear_nota("torre", "nota4_susurro_nombre")
    return


# ── Nota: la puerta 19 ──
label cap04_nota_puerta_19:
    $ desbloquear_nota("torre", "nota4_puerta_19")
    return