# ═══════════════════════════════════════════════════════════════
#  53cap04_flashbacks.rpy — Flashbacks del Capítulo 4
#  -----------------------------------------------------------------
#  2 escenas del pasado de Mei y Daichi.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES PARA FLASHBACKS
# ─────────────────────────────────────────────────────────────

# Mei en flashback (voz más joven, más frágil)
define mep_old = Character(
    "Mei",
    color="#90a4ae",
    what_color="#d0d8e0",
    what_italic=True,
    what_size=28
)

# Daichi en flashback (voz más joven, antes del trabajo en la morgue)
define dap_old = Character(
    "Daichi",
    color="#a1887f",
    what_color="#d8c8b8",
    what_italic=True,
    what_size=28
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES DE FLASHBACK
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT IMAGEN — Cuarto de Mei de niña (flashback)
# Archivo: images/fondos/cap04/flash_mei_cuarto.png
# Prompt: Anime dark psychological horror scene, soft melancholic
#         tone. A small girl's bedroom at night, seen from the
#         doorway. A single bed with white sheets, a small desk
#         covered in sketchbooks and pencils, drawings of doors
#         pinned to the walls (dozens of them, all different, all
#         closed). A night light in the corner casting soft warm
#         light. The window is open a crack. Atmosphere: intimate
#         loneliness, quiet creation, a child drawing to not be
#         afraid. Muted warm palette, sepia undertones. Anime
#         style, 16:9, no text, no watermark.
# image bg_flash_mei_cuarto = "images/fondos/cap04/flash_mei_cuarto.png"
image bg_flash_mei_cuarto = Solid("#3a3028")

# 🎨 PROMPT IMAGEN — Morgue de noche (flashback de Daichi)
# Archivo: images/fondos/cap04/flash_daichi_morgue.png
# Prompt: Anime dark psychological horror scene, melancholic tone.
#         An old hospital morgue at 3 AM. Rows of metal cabinets
#         with sliding drawers on the walls. A single cold
#         fluorescent light flickers overhead. On the central
#         steel table, a white sheet covering a shape that is
#         slightly too small for an adult. A young man in scrubs
#         (Daichi, 18 years old) stands next to the table, looking
#         down. He is holding a clipboard but not writing.
#         Atmosphere: cold, grief, the moment before recognition.
#         Cold blue-grey palette, one flickering light. 16:9, no text.
# image bg_flash_daichi_morgue = "images/fondos/cap04/flash_daichi_morgue.png"
image bg_flash_daichi_morgue = Solid("#1c2028")


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 1 — Mei y su cuaderno
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Mei recuerda por qué empezó a dibujar puertas.
# ═══════════════════════════════════════════════════════════════
label cap04_flashback_mei_cuaderno:

    # ── Transición ──
    n "..."

    n "Y por un momento, dejas de estar aquí."

    scene bg_flash_mei_cuarto
    with Dissolve(1.0)

    # ── Indicador visual de flashback ──
    show screen flashback_overlay

    # ── Música de flashback ──
    $ musica("flashback_suave", fade=2.0)

    # ── Ambientación ──
    n "Tu cuarto. De noche."

    n "Tenías siete años."

    n "Y no podías dormir."

    mep_old "(Hay algo detrás de la puerta.)"
    mep_old "(No sé qué es.)"
    mep_old "(Pero está.)"

    # ── Detalle clave ──
    n "En la mesa, un cuaderno."

    n "Y un lápiz."

    n "Y tú, sentada, dibujando."

    n "Dibujabas puertas."

    n "Muchas puertas."

    mep_old "(Si dibujo una puerta, está cerrada.)"
    mep_old "(Si está cerrada, no puede entrar nada.)"
    mep_old "(Si no puede entrar nada, no hay miedo.)"

    # ── Conexión con el presente ──
    n "Y así, cada noche, dibujabas puertas."

    n "Una tras otra."

    n "Hasta que te quedabas dormida."

    n "Y así llevas desde entonces."

    n "Dibujando puertas para no abrirlas."

    mep_old "(Si dibujo una puerta, alguien la cruzará por mí.)"
    mep_old "(Eso me decía la abuela.)"
    mep_old "(Pero yo no quería que nadie la cruzara.)"
    mep_old "(Quería que se quedara cerrada.)"
    mep_old "(Para siempre.)"

    # ── Métrica ──
    $ modificar_metrica("angustia", +4)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "mei")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso4_pasillo
    with Dissolve(1.0)

    show mei_img at left
    show daichi_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al pasillo. A Daichi."

    n "Daichi te está mirando."

    da "¿Estás bien?"

    me "Sí."

    da "No lo parece."

    me "..."

    me "Es solo que..."

    me "Este sitio me recuerda a algo."

    da "..."

    da "A mí también."

    n "Y por un momento, los dos os quedáis en silencio."

    n "Pero es un silencio distinto. Un silencio compartido."

    # ── Flag ──
    $ gtn_flag("fb_mei_visto", True)

    return


# ═══════════════════════════════════════════════════════════════
#  FLASHBACK 2 — Daichi en la morgue
# ═══════════════════════════════════════════════════════════════
#  Duración: ~25-30 segundos.
#  Contexto: Daichi recuerda la noche en la que llegó alguien
#             que conocía. Y que no debería haber llegado.
# ═══════════════════════════════════════════════════════════════
label cap04_flashback_daichi_morgue:

    # ── Transición ──
    n "..."

    n "Daichi se ha quedado en silencio."

    n "Y por un momento, ves algo distinto en él."

    # ── Flashback ──
    scene bg_flash_daichi_morgue
    with Dissolve(1.0)

    show screen flashback_overlay

    $ musica("flashback_tension", fade=2.0)

    # ── Ambientación ──
    n "Una morgue. De noche."

    n "Las 3:00 de la madrugada."

    n "Daichi tenía 18 años."

    dap_old "(Otro turno más.)"
    dap_old "(Otro cuerpo más.)"
    dap_old "(Ya no me acuerdo ni de sus caras.)"

    # ── Detalle clave ──
    n "En la mesa, un cuerpo."

    n "Cubierto con una sábana blanca."

    n "Demasiado pequeño para ser un adulto."

    n "Daichi levanta la sábana."

    dap_old "(...)"

    dap_old "(No.)"

    # ── El reconocimiento ──
    n "Lo reconoció."

    n "Era un compañero de clase."

    n "Se llamaba Hiroshi."

    n "Y tenía 18 años. Como él."

    dap_old "(No puede ser.)"
    dap_old "(Hiroshi.)"
    dap_old "(Ayer lo vi en el pasillo.)"
    dap_old "(Ayer me dijo hola.)"
    dap_old "(Ayer estaba vivo.)"

    # ── Conexión con el presente ──
    n "Esa fue la última noche que Daichi trabajó en la morgue."

    n "Desde entonces, no ha vuelto a mirar a nadie a los ojos."

    n "Porque cada vez que lo hace..."

    n "Se acuerda de Hiroshi."

    dap_old "(No quiero volver a ver eso.)"
    dap_old "(No quiero volver a reconocer a nadie.)"
    dap_old "(Pero aquí estoy.)"
    dap_old "(En otra morgue.)"
    dap_old "(Y con la misma sensación.)"

    # ── Métrica ──
    $ modificar_metrica("angustia", +5)
    $ modificar_metrica("miedo", +3)

    # ── Trauma desbloqueado ──
    $ desbloquear_trauma("torre", "daichi")

    # ── Salida del flashback ──
    hide screen flashback_overlay
    scene bg_piso4_morgue
    with Dissolve(1.0)

    show mei_img at left
    show daichi_img at right
    with dissolve

    $ musica("torre_ambiente", fade=2.0)

    n "..."

    n "Vuelves al presente. A la morgue."

    n "Daichi está mirando su propio reflejo en uno de los cajones metálicos."

    n "Pero esta vez, su reflejo tarda un poco más en copiarle."

    me "Daichi."

    da "¿Sí?"

    me "Te has quedado en blanco."

    da "Solo estaba... pensando."

    n "Las mismas palabras que le has dicho tú antes."

    mep "(Ha usado mi frase.)"
    mep "(Como el eco.)"

    # ── Flag ──
    $ gtn_flag("fb_daichi_visto", True)

    return