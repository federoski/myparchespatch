# ═══════════════════════════════════════════════════════════════
#  51cap02_yuki_sora.rpy — Capítulo 2: El eco
#  -----------------------------------------------------------------
#  Pareja: Yuki & Sora
#  Posición: Yuki (izq) + Sora (der)
#  Finales: bueno / bueno_especial / yuki_muere / ambos_caen / secreto
#  Minijuego: MEMORIA
#  Exploración: menú con flechas (3 zonas)
#  Diccionario: reflejo_no_miente, eco_verdadero, simbolo_espejo, puerta_espejo
#  Fichas: yuki, sora
#  Bestiario: reflejo
#  Pistas tablón: 6
#  Deducciones: 2
#  Flashbacks: 2
#  Eco El·yon: 3 apariciones
#
#  ⚠️ NOTA: Los labels cap02_nota_*, cap02_flashback_*,
#     cap02_deduccion_*, cap02_eco_*, cap02_pulsar_* están
#     definidos en sus respectivos archivos auxiliares
#     (51cap02_notas.rpy, 51cap02_flashbacks.rpy,
#      51cap02_deducciones.rpy, 51cap02_eco.rpy,
#      51cap02_objetos.rpy). NO se duplican aquí.
# ═══════════════════════════════════════════════════════════════


# ─────────────────────────────────────────────────────────────
#  PERSONAJES ESPECIALES
# ─────────────────────────────────────────────────────────────
define yup = Character(
    "Yuki",
    color="#b39ddb",
    what_color="#d0c8e0",
    what_italic=True,
    what_size=28
)

define sop = Character(
    "Sora",
    color="#64b5f6",
    what_color="#a8c8e8",
    what_italic=True,
    what_size=28
)

define elyon_voz = Character(
    "???",
    color="#8b0000",
    what_color="#CC4444",
    what_italic=True,
    what_size=32
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES (placeholders temporales)
# ─────────────────────────────────────────────────────────────
image bg_piso2_despertar = "images/fondos/cap02/piso2_despertar.png"
image bg_piso2_pasillo = Solid("#1a1c22")
image bg_piso2_espejo_grande = Solid("#22222a")
image bg_piso2_espejo_roto = Solid("#1e1e26")
image bg_piso2_salida = Solid("#3a3528")

image cap02_reflejo = Solid("#1c1c1c")
image cap02_simbolo_espejo = Solid("#1e1a1a")
image cap02_puerta_espejo = Solid("#1a1a20")

image cap2_final_bueno = Solid("#e0c988")
image cap2_final_yuki_muere = Solid("#141821")
image cap2_final_ambos = Solid("#08090c")
image cap2_final_secreto = Solid("#181c22")


# ═══════════════════════════════════════════════════════════════
#  CAPÍTULO 2
# ═══════════════════════════════════════════════════════════════
label capitulo_2:
    # ── Pantalla de carga ──
    $ _cap_data = capitulos.historias["torre"]["actos"].get(2, {})
    $ _nombre_cap = _cap_data.get("nombre", "El eco")
    $ _sub_cap = _cap_data.get("sub", "Yuki & Sora")
    $ _icono_cap = _cap_data.get("icono", "🗪")
    call mostrar_pantalla_carga("torre", 2, _nombre_cap, _sub_cap, _icono_cap)

    $ gtn_reiniciar_metricas()
    $ gtn_capitulo_actual = 2
    $ capitulos.desbloquear_capitulo("torre", 2)
    $ registrar_capitulo_jugado(2)

    scene black
    with fade

    show screen gtn_notif_screen
    $ musica("torre_ambiente", fade=2.0)

    $ add_achievement_with_popup(achievement_segundo_despertar)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 1 — EL DESPERTAR
    # ═══════════════════════════════════════════════════════════

    n "Un chasquido."
    n "Como si algo se rompiera muy despacio."
    n "Y luego, silencio."
    n "Abres los ojos."

    scene bg_piso2_despertar
    with fade

    n "Estás rodeada de espejos."
    n "Paredes enteras cubiertas de ellos. Altos. Algunos rotos. Algunos empañados."
    n "Y en todos, tu reflejo."

    show yuki_img at left
    with dissolve

    yu "...¿Qué...?"
    yu "¿Dónde estoy?"

    n "Te incorporas. El suelo es de piedra negra pulida. Resbala un poco."

    yu "Esto no estaba aquí antes."
    yu "Esto no estaba {i}en ningún sitio{/i} antes."

    yup "(¿Por qué hay tantos espejos?)"
    yup "(¿Por qué me miran todos a la vez?)"

    $ desbloquear_ficha("torre", "yuki")
    $ add_achievement_with_popup(achievement_conoce_yuki)

    n "Te miras en el espejo más cercano. Estás igual. Igual que siempre."
    n "Pero algo en el reflejo está... un poco mal."
    n "Como si tardara medio segundo en copiarte."

    yup "(Se ha movido después que yo.)"
    yup "(Solo un poco. Pero se ha movido después.)"

    $ desbloquear_pista("torre", "p2_reflejo_retrasado")

    # ── Decisión 1 ──
    menu:
        "¿Qué haces?"

        "Acercarte al espejo para mirar mejor.":
            $ modificar_metrica("miedo", +10)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("yuki_espejo_cerca", True)
            $ registrar_decision()

            yu "Vale. Vale, tranquila."
            n "Te acercas al espejo."
            n "Tu reflejo te imita. Con un retraso casi imperceptible."
            n "Y entonces, por un momento, ves algo detrás de ti."
            n "Un pasillo. Que no está."
            yu "...¿Qué ha sido eso?"
            yup "(Había una puerta detrás de mí.)"
            yup "(En el reflejo. Pero no en la realidad.)"

        "Alejarte de los espejos todo lo posible.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +12)
            $ gtn_flag("yuki_espejo_lejos", True)
            $ registrar_decision()

            yu "No. No me gustan los espejos."
            n "Vas al centro de la sala. Es lo más lejos que puedes estar de las paredes."
            n "Pero incluso desde aquí, ves tu reflejo repetido en cada uno."
            n "Cada uno te mira un poco distinto."
            yup "(No puedo escapar de ellos.)"
            yup "(Me ven desde todas partes.)"

        "Gritar pidiendo ayuda.":
            $ modificar_metrica("miedo", +8)
            $ modificar_metrica("angustia", +5)
            $ gtn_flag("yuki_grito", True)
            $ registrar_decision()
            $ gtn_flag("grito_alguna_vez", True)

            yu "¡¿HOLA?! ¡¿HAY ALGUIEN?!"
            n "Tu grito rebota en los espejos."
            n "Y los espejos lo devuelven."
            n "Pero no exactamente igual. Un poco más agudo. Un poco más largo."
            yu "Eso no ha sonado como yo."
            yup "(Ha sonado como una versión de mí.)"
            yup "(Como si los espejos hubieran aprendido mi voz.)"

    if estado_minimo("miedo", 40):
        yup "(Me tiemblan las manos.)"
        yup "(No debería. Son solo espejos.)"
        yup "(Pero se mueven cuando no miro.)"

    if estado_extremo("angustia"):
        n "Sientes que te falta el aire. Y no hay ninguna razón para ello."
        yup "(Respira. Respira. Respira.)"
        yup "(No estás en peligro. Todavía.)"

    call cap02_eco_1
    $ add_achievement_with_popup(achievement_primera_decision)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 2 — LOS ESPEJOS
    # ═══════════════════════════════════════════════════════════

    n "Entonces lo oyes."

    $ sonido("pasos_lejanos")

    n "Pasos. Detrás de uno de los espejos."
    n "No detrás de ti. {i}Dentro{/i} del espejo."

    yu "¿Hola...?"

    n "Una voz. Joven. Calmada. Un poco rara."

    so "Hola."

    n "El reflejo en el espejo más cercano ya no es el tuyo."
    n "Es un chico."

    show sora_img at right
    with dissolve

    so "No te asustes."
    yu "¡¿QUE NO ME ASUSTE?!"
    so "Vale. Justo. Mal empezamos."
    so "Pero estoy en el mismo sitio que tú. Al otro lado."
    yu "¿Al otro lado de qué?"
    so "Del espejo. Creo."

    n "El chico del espejo se aparta un poco. Se ve a sí mismo reflejado en tu lado del cristal."

    so "Sora."
    yu "Yuki."
    so "Vale, Yuki. Vamos a salir de aquí."

    $ desbloquear_ficha("torre", "sora")
    $ add_achievement_with_popup(achievement_conoce_sora)

    n "No sabes por qué, pero le crees."

    if gtn_flag("yuki_espejo_cerca"):
        so "Te he visto acercarte al espejo."
        so "No lo hagas más."
        yu "¿Por qué?"
        so "Porque no sé qué hay detrás de ellos. Y tú tampoco."
        yup "(Sabe lo que he hecho.)"
        yup "(Me ha estado viendo todo el tiempo.)"

    elif gtn_flag("yuki_espejo_lejos"):
        so "Te has alejado."
        so "Buena idea."
        yu "No me gustan los espejos."
        so "A mí tampoco. Pero estamos rodeados."
        yup "(También le dan miedo.)"
        yup "(Pero no lo dice del todo.)"

    elif gtn_flag("yuki_grito"):
        so "Te he oído gritar."
        so "Desde el otro lado sonaba distinto."
        yu "¿Distinto cómo?"
        so "Más grave. Más largo."
        so "Como si no fuera del todo tu voz."
        yup "(Eso mismo pensé yo.)"
        yup "(¿Cómo lo sabe él?)"

    if estado_minimo("angustia", 50):
        n "Sora te mira desde el espejo. Y por un momento, ves algo en sus ojos que no habías visto."
        n "Cansancio. Cansancio de verdad."
        yup "(No es solo la torre.)"
        yup "(Lleva esto dentro desde antes de llegar.)"

    if estado_minimo("amor", 30):
        n "Y sin embargo, sonríe. Como si, a pesar de todo, estuviera bien."
        yup "(¿Por qué sonríe?)"
        yup "(No hay nada que sonreír.)"

    if estado_minimo("miedo", 60):
        n "Tú no sonríes. No puedes."
        yup "(Me tiembla la voz.)"
        yup "(No puedo dejar que lo note.)"

    if peso_tomado("cap1_confio_ren"):
        yup "(En el piso 1 también confié en alguien que no conocía.)"
        yup "(Y salió bien. Creo.)"

    elif peso_tomado("cap1_desconfio_ren"):
        yup "(En el piso 1 mantuve la distancia.)"
        yup "(Quizá deba hacer lo mismo aquí.)"

    # ── Decisión 2 ──
    menu:
        "¿Cómo reaccionas?"

        "Preguntarle cómo sabe tanto.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +8)
            $ gtn_flag("yuki_pregunta", True)
            $ registrar_decision()

            yu "¿Cómo sabes que hay que salir?"
            so "...Porque ya he estado en sitios así."
            yu "¿Qué sitios?"
            so "No quiero hablar de eso."
            n "Su reflejo se queda quieto un momento antes de seguir moviéndose. Un fallo técnico. Como un glitch."
            yup "(Ha hecho un fallo.)"
            yup "(Como el reflejo. Pero él no es un reflejo.)"

        "Contarle que has oído un eco raro.":
            $ modificar_metrica("amor", +10)
            $ modificar_metrica("miedo", +5)
            $ gtn_flag("yuki_cuenta", True)
            $ registrar_decision()

            yu "Yo he oído algo."
            so "¿El qué?"
            yu "Un eco. Pero no repetía lo que decía."
            yu "Decía lo que pensaba."
            so "..."
            so "Yo también."
            so "Pero no quería decirlo."
            yu "Entonces no estamos locos."
            so "O estamos los dos."
            yu "Peor."

        "Confiar en él directamente.":
            $ modificar_metrica("amor", +15)
            $ modificar_metrica("miedo", -5)
            $ gtn_flag("yuki_confia", True)
            $ registrar_decision()

            yu "Vale. Confío en ti."
            so "...¿Así, sin más?"
            yu "No tengo mucho donde elegir."
            n "Sora sonríe de lado. Pero la sonrisa no le llega a los ojos."
            yup "(Sonríe como si supiera algo.)"
            yup "(Pero no lo dice.)"

    if estado_minimo("amor", 40) and estado_minimo("miedo", 40):
        yup "(Le he dicho que confío en él.)"
        yup "(Y es verdad. Pero también me da miedo.)"
        yup "(Me da miedo que confiar en alguien salga mal.)"
        yup "(Como siempre.)"

    if estado_extremo("odio"):
        yup "(No debería odiarlo.)"
        yup "(Ni siquiera lo conozco.)"
        yup "(Pero hay algo en él que me irrita.)"
        yup "(Y no sé qué es.)"

    if gtn_flag("yuki_confia"):
        so "Me alegra que confíes en mí."
        so "Aunque no deberías."
        yu "¿Qué?"
        so "Nada. Olvídalo."
        yup "(Ha dicho algo importante.)"
        yup "(Pero no lo ha dicho.)"

    if estado_minimo("angustia", 60):
        yup "(Me pesa la cabeza.)"
        yup "(Como si tuviera algo dentro que quiere salir.)"
        yup "(Y no puedo dejar que salga.)"

    call cap02_flashback_yuki_hermanos

    # ═══════════════════════════════════════════════════════════
    #  OBJETO 1 — La inscripción del espejo
    # ═══════════════════════════════════════════════════════════

    scene bg_piso2_pasillo
    with fade

    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Seguís avanzando. Los espejos os siguen."
    n "Sora camina al otro lado del cristal. Como si fuera un pasillo paralelo."
    n "Una de las paredes tiene una inscripción grabada en el marco."
    n "La misma caligrafía que las marcas de la torre."

    call screen cap02_marca_interactiva

    $ sonido("marca_raspar")

    show cap02_reflejo at truecenter
    with dissolve

    n "«El reflejo no miente»."
    n "Lo dice tres veces. En tres espejos distintos."
    n "Como si alguien hubiera querido que lo leyera más de una vez."

    if peso_tomado("cap1_leyo_marca"):
        n "Y debajo, más pequeña, casi borrada, hay una segunda frase."
        n "«...pero a veces se calla.»"
        yu "Hay algo más."
        so "¿Qué dice?"
        yu "«Pero a veces se calla.»"
        so "..."

    $ aprender_palabra("torre", "reflejo_no_miente")

    yu "«El reflejo no miente»..."
    so "¿Y eso qué significa?"
    yu "Que lo que vemos en ellos es verdad."
    so "Entonces lo que veo en el tuyo es verdad."
    yu "¿Qué ves?"
    so "..."
    so "Nada. Déjalo."

    hide cap02_reflejo
    with dissolve

    # ── Decisión 3 ──
    menu:
        "¿Qué haces con la inscripción?"

        "Intentar entender qué significa.":
            $ modificar_metrica("miedo", +10)
            $ modificar_metrica("angustia", +10)
            $ gtn_flag("yuki_inscripcion_lee", True)
            $ registrar_decision()

            yu "«El reflejo no miente»."
            yu "Pero tú has visto tu reflejo hacer cosas que no hacías."
            so "..."
            so "Entonces no era mi reflejo."
            yu "¿Qué era?"
            so "No lo sé. Y no quiero saberlo."
            yup "(Ha dicho la verdad.)"
            yup "(Y la verdad da miedo.)"

        "Apartar la mirada y seguir.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("amor", +5)
            $ gtn_flag("yuki_inscripcion_ignora", True)
            $ registrar_decision()

            yu "No quiero saber más."
            so "Bien. Vamos."
            n "Sora no insiste. Y eso, de alguna forma, te tranquiliza."

        "Respirar hondo. Intentar calmarte." if estado_minimo("miedo", 60):
            $ modificar_metrica("miedo", -10)
            $ modificar_metrica("angustia", -5)
            $ gtn_flag("yuki_respiro", True)
            $ registrar_decision()

            yu "..."
            n "Cierras los ojos. Respiras."
            n "Cuando los abres, los espejos siguen ahí. Pero ya no parecen tan grandes."
            so "¿Estás bien?"
            yu "Sí. Ahora sí."
            yup "(Un momento. Solo necesitaba un momento.)"

    $ desbloquear_pista("torre", "p2_inscripcion_espejo")
    call cap02_nota_reflejo

    # ═══════════════════════════════════════════════════════════
    #  ACTO 3 — LA EXPLORACIÓN
    # ═══════════════════════════════════════════════════════════

    n "El pasillo se divide. Podéis ir a varios sitios."
    so "¿Por dónde quieres ir?"

    $ zonas_exploradas = []

    call cap02_exploracion
    jump cap02_tras_exploracion


# ═══════════════════════════════════════════════════════════════
#  TRAS LA EXPLORACIÓN
# ═══════════════════════════════════════════════════════════════
label cap02_tras_exploracion:
    scene bg_piso2_pasillo
    with fade

    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Volvéis al centro del pasillo."
    n "Los espejos han cambiado."
    n "Ahora en todos, aparece la puerta que visteis en el reflejo del espejo grande."
    n "Y en todos, al otro lado de la puerta, se ve una escalera."

    yu "Es la salida."
    so "Sí."
    so "Pero hay algo antes."
    yu "¿Qué?"
    so "Cuando lleguemos a la puerta..."
    so "Uno de nosotros tendrá que quedarse."
    yu "¿Qué? ¿Por qué?"
    so "Porque lo he visto en el reflejo."
    so "Si los dos cruzamos, la puerta se cierra. Y no se vuelve a abrir."
    yu "..."

    call cap02_flashback_sora_hospital
    call cap02_deduccion_1

    # ── OBJETO 2 — Símbolo en el espejo ──
    n "Antes de la puerta, hay un espejo distinto a los demás."
    n "En su superficie hay un símbolo grabado."
    n "El mismo que la torre."

    call screen cap02_simbolo_espejo_interactivo
    call cap02_pulsar_simbolo

    # ── EL ECO VERDADERO ──
    n "Y entonces lo oyes."
    $ sonido("eco_verdadero")
    n "Una voz. Pero no es la tuya. Ni la de Sora."
    n "Es tu voz. Pero un poco más grave. Y un poco más lenta."
    n "Y dice algo que tú no has dicho."

    elyon_voz "{i}No confíes en el eco.{/i}"

    $ aprender_palabra("torre", "eco_verdadero")
    $ desbloquear_bestiario("torre", "reflejo")

    yu "Sora."
    so "¿Sí?"
    yu "¿Tú también lo has oído?"
    so "...Sí."
    so "Pero no ha dicho lo mismo que a ti."
    yu "¿Qué te ha dicho a ti?"
    so "..."
    so "Que no confíe en ti."

    n "Los dos os quedáis en silencio."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +15)

    if estado_extremo("terror"):
        yup "(Lo he oído. Lo he oído de verdad.)"
        yup "(No estoy loca. No estoy loca.)"
        yup "(¿O sí?)"
        n "Te llevas las manos a las orejas. Como si quisieras tapar algo."
        so "Yuki. Yuki, mírame."
        yu "Estoy bien."
        so "No. No lo estás."
        n "Y por primera vez, no sabes qué contestar."

    if estado_minimo("amor", 50):
        so "Sea lo que sea que hayas oído..."
        so "No estás sola."
        yu "..."
        yup "(No estoy sola.)"
        yup "(Nunca había pensado eso.)"
        yup "(Y ahora que lo pienso, no sé qué hacer con ello.)"

    if estado_minimo("odio", 50):
        yup "(No quiero que me vea así.)"
        yup "(No quiero que nadie me vea así.)"
        n "Te apartas un poco del espejo. Sin darte cuenta."
        so "..."
        n "Sora no dice nada. Pero lo nota."

    $ desbloquear_pista("torre", "p2_eco_verdadero")
    call cap02_nota_eco

    if gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido") and gtn_flag("eco_3_oido"):
        n "El eco dice algo más. Muy bajo. Pero lo oyes."
        elyon_voz "{i}Ya me has oído antes. Lo sabes.{/i}"
        yup "(Sí.)"
        yup "(Lo sé.)"

    call cap02_eco_2

    # ═══════════════════════════════════════════════════════════
    #  ACTO 4 — EL ESPEJO ROTO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso2_espejo_roto
    with fade

    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Al final del pasillo, un espejo roto."
    n "Los fragmentos están en el suelo. Cada uno refleja algo distinto."
    n "Algunos os reflejan a los dos."
    n "Uno de ellos, sin embargo, solo refleja a Sora. Sin ti."
    n "Otro solo te refleja a ti. Sin él."

    yu "Sora. Mira esto."
    so "..."
    so "No me gusta."
    yu "¿Qué pasa?"
    so "En uno de los fragmentos, estoy solo."
    yu "Y en otro, estoy sola yo."
    so "Exacto."

    n "En un tercer fragmento, estáis los dos. Pero no aquí. En otro sitio. Con más gente."
    n "En una torre. Con más espejos. Y más puertas."

    yu "¿Qué es eso?"
    so "No lo sé."
    so "Pero no es aquí."

    n "El fragmento se empaña. Y al despejarse, ya no muestra nada."

    $ modificar_metrica("miedo", +12)
    $ modificar_metrica("terror", +8)

    $ desbloquear_pista("torre", "p2_fragmento_18")
    call cap02_deduccion_2

    # ═══════════════════════════════════════════════════════════
    #  ACTO 5 — LA PUERTA-ESPEJO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso2_salida
    with fade

    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Al final del piso, el último espejo es distinto a los demás."
    n "Es más alto. Más ancho. Y no refleja."
    n "Es una puerta disfrazada de espejo."
    n "Está entreabierta. Por la rendija se cuela una luz blanca."

    so "Es la salida."
    yu "¿Y si no lo es?"
    so "Entonces volvemos. Pero contigo."

    call screen cap02_puerta_espejo_interactivo
    call cap02_pulsar_puerta

    call cap02_eco_3

    # ── LOGROS ACUMULATIVOS ──
    if gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido") and gtn_flag("eco_3_oido"):
        $ add_achievement_with_popup(achievement_eco_completo_cap2)

    if gtn_flag("fb_yuki_visto") and gtn_flag("fb_sora_visto"):
        $ add_achievement_with_popup(achievement_recuerdos_cap2)

    if notas_descubiertas_cap("torre", 2) >= 5:
        $ add_achievement_with_popup(achievement_notas_completas_cap2)

    if objeto_visto("simbolo_espejo") and objeto_visto("puerta_espejo"):
        $ add_achievement_with_popup(achievement_objetos_cap2)

    if deduccion_jugador_acertada("cap02_ded1") and deduccion_jugador_acertada("cap02_ded2"):
        $ add_achievement_with_popup(achievement_deducciones_cap2)

    if not gtn_flag("grito_alguna_vez"):
        $ add_achievement_with_popup(achievement_oculto_no_grito)

    if gtn_espejo_pulsado >= 3:
        $ add_achievement_with_popup(achievement_oculto_reflejo)

    if gtn_puertas_pulsadas >= 3:
        $ add_achievement_with_popup(achievement_oculto_puertas)

    # ═══════════════════════════════════════════════════════════
    #  MINIJUEGO — MEMORIA
    # ═══════════════════════════════════════════════════════════

    n "Antes de decidir nada, la puerta empieza a abrirse."
    n "Pero no se abre del todo. Necesita que alguien recuerde la secuencia."
    n "Los símbolos que había en los espejos. En orden."

    so "Yuki."
    so "Tú puedes. Yo confío en ti."

    if estado_extremo("miedo"):
        yup "(No puedo. No puedo recordar nada.)"
        yup "(Voy a fallar. Voy a fallar.)"
        yup "(Como siempre.)"
        n "Te tiemblan las manos."
        so "Yuki. Mírame."
        yu "..."
        so "Vas a recordar la secuencia. Y yo voy a salir contigo. ¿Vale?"
        yup "(¿Por qué confía en mí?)"
        yup "(No debería.)"

    if estado_minimo("terror", 60):
        yup "(Los símbolos son demasiados.)"
        yup "(No voy a recordarlos todos.)"
        yup "(Lo sé.)"

    $ musica("tension_alta", fade=0.5)
    call lanzar_memoria(["←", "↑", "→", "↓", "←"])

    if gtn_minijuego_resultado:
        $ registrar_minijuego(True)
        $ add_achievement_with_popup(achievement_primer_minijuego)

        n "Los símbolos aparecen en orden."
        n "La puerta se abre del todo."
        n "Al otro lado, la escalera."
        n "Pero la puerta empieza a cerrarse."

        $ modificar_metrica("amor", +20)
        $ modificar_metrica("miedo", -5)

        so "¡Vamos!"

        menu:
            "¿Qué haces?"

            "Salir juntos, corriendo.":
                $ registrar_decision()
                $ registrar_peso("cap2_cogio_mano")
                jump cap2_final_bueno

            "Empujar a Sora primero.":
                $ registrar_decision()
                jump cap2_final_yuki_muere

            "Quedarte tú atrás, cerrando la puerta.":
                $ registrar_decision()
                jump cap2_final_secreto

            "Cogerle la mano antes de cruzar." if estado_minimo("amor", 70) and estado_maximo("miedo", 40):
                $ modificar_metrica("amor", +15)
                $ gtn_flag("yuki_cogio_mano", True)
                $ registrar_decision()
                $ registrar_peso("cap2_cogio_mano")

                yu "Sora."
                so "¿Sí?"
                n "No dices nada. Solo le coges la mano."
                n "Sora no se aparta."
                n "Y los dos cruzáis la puerta juntos."
                jump cap2_final_bueno_especial
    else:
        $ registrar_minijuego(False)
        $ add_achievement_with_popup(achievement_primer_minijuego)
        n "Los símbolos no aparecen."
        n "La puerta tiembla."
        n "Y entonces algo tira de vosotros hacia dentro."
        n "Los espejos empiezan a romperse. Todos a la vez."
        so "¡YUKI!"
        n "El suelo se desmorona bajo vuestros pies."
        $ musica("final_malo", fade=1.0)
        jump cap2_final_ambos_caen


# ═══════════════════════════════════════════════════════════════
#  FINALES DEL CAPÍTULO 2
# ═══════════════════════════════════════════════════════════════

label cap2_final_bueno:
    scene bg_piso2_salida
    with fade
    show yuki_img at left
    show sora_img at right
    with dissolve

    yu "¡Juntos!"
    so "¡Juntos!"
    n "Corréis los dos hacia la puerta."
    n "La cruzéis al mismo tiempo."

    $ musica("final_bueno", fade=2.0)
    scene cap2_final_bueno
    with Dissolve(1.5)

    n "La luz os traga."
    n "Y luego, silencio."
    n "En los espejos que quedan atrás, vuestros reflejos se sincronizan por fin."
    n "Ya no hay retraso."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 2 superado."

    $ registrar_final_bueno()
    $ registrar_ruta(2, "bueno")
    $ guardar_estados_capitulo(2, "torre")
    $ unlock_final("torre", 2, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap2)
    $ add_achievement_with_popup(achievement_cap2_completado)
    $ desbloquear_imagen_galeria("cap2_bueno")
    $ capitulos.completar_capitulo("torre", 2)
    call marcar_final_bueno_cap(2, "torre")
    $ desbloquear_invocaciones_hasta(2)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("yuki_confia"):
        $ registrar_peso("cap2_confio_sora")
    if gtn_flag("yuki_pregunta"):
        $ registrar_peso("cap2_pregunto_sora")
    if gtn_flag("yuki_inscripcion_lee"):
        $ registrar_peso("cap2_leyo_inscripcion")
    if gtn_flag("yuki_respiro"):
        $ registrar_peso("cap2_respiro")

    "Capítulo 2 completado."
    jump volver_al_hub


label cap2_final_bueno_especial:
    scene bg_piso2_salida
    with fade
    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Cruzasteis juntos. Con las manos cogidas."
    n "Y al otro lado, por primera vez, no había silencio."
    n "Había una puerta abierta. Y detrás, luz."

    $ musica("final_bueno", fade=2.0)
    scene cap2_final_bueno
    with Dissolve(1.5)

    n "Pero no era la salida."
    n "Era otra cosa."
    n "Era el inicio de algo que ninguno de los dos había previsto."
    n "Y en los espejos que quedaban atrás, vuestros reflejos... sonreían."
    n "Los dos."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Nivel 2 superado. Pero no del todo."

    $ registrar_final_bueno()
    $ registrar_ruta(2, "bueno_especial")
    $ registrar_peso("cap2_cogio_mano")
    $ guardar_estados_capitulo(2, "torre")
    $ unlock_final("torre", 2, "bueno")
    $ add_achievement_with_popup(achievement_final_especial_cap2)
    $ add_achievement_with_popup(achievement_cap2_completado)
    $ desbloquear_imagen_galeria("cap2_bueno")
    $ capitulos.completar_capitulo("torre", 2)
    call marcar_final_bueno_cap(2, "torre")
    $ desbloquear_invocaciones_hasta(2)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("yuki_confia"):
        $ registrar_peso("cap2_confio_sora")
    if gtn_flag("yuki_pregunta"):
        $ registrar_peso("cap2_pregunto_sora")
    if gtn_flag("yuki_inscripcion_lee"):
        $ registrar_peso("cap2_leyo_inscripcion")
    if gtn_flag("yuki_respiro"):
        $ registrar_peso("cap2_respiro")

    "Capítulo 2 completado (ruta especial)."
    jump volver_al_hub


label cap2_final_yuki_muere:
    scene bg_piso2_salida
    with fade
    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Empujas a Sora hacia la puerta."
    so "¡Yuki, no!"
    yu "¡VE!"
    n "Sora cruza."
    n "Tú te quedas un momento más."
    n "Y la puerta se cierra."

    $ musica("final_malo", fade=1.5)
    scene cap2_final_yuki_muere
    with Dissolve(1.0)

    n "Los espejos a tu alrededor empiezan a romperse."
    n "Todos a la vez."
    n "Y en cada fragmento, ves algo distinto."
    n "En uno, Sora gritando."
    n "En otro, la puerta abriéndose de nuevo."
    n "En otro, tú misma, en otro sitio, con otra gente."
    n "En un fragmento muy pequeño, casi invisible, ves la torre entera."
    n "Con más puertas. Más pisos. Más gente."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Y el eco se apaga."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(2, "yuki_muere")
    $ guardar_estados_capitulo(2, "torre")
    $ unlock_final("torre", 2, "yuki_muere")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap2_completado)
    $ desbloquear_imagen_galeria("cap2_yuki_muere")
    $ capitulos.completar_capitulo("torre", 2)
    $ desbloquear_invocaciones_hasta(2)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("yuki_confia"):
        $ registrar_peso("cap2_confio_sora")
    if gtn_flag("yuki_pregunta"):
        $ registrar_peso("cap2_pregunto_sora")
    if gtn_flag("yuki_inscripcion_lee"):
        $ registrar_peso("cap2_leyo_inscripcion")
    if gtn_flag("yuki_respiro"):
        $ registrar_peso("cap2_respiro")

    "Capítulo 2 completado (final malo)."
    jump volver_al_hub


label cap2_final_ambos_caen:
    scene bg_piso2_espejo_roto
    with fade
    show yuki_img at left
    show sora_img at right
    with dissolve

    so "¡YUKI!"
    n "Los espejos estallan."
    n "El suelo se abre."
    n "Caéis."

    $ musica("final_malo", fade=1.0)
    scene cap2_final_ambos
    with fade

    n "Y caéis."
    n "Y caéis."
    n "Y en cada espejo que pasáis, veis una versión distinta de vosotros mismos."
    n "Algunas salen. Algunas no."
    n "En una, estáis con más gente."
    n "En otra, no estáis."
    n "En la última, antes de la oscuridad, veis a todos los demás."
    n "Reunidos. Esperando."
    n "Aún no los conocéis."
    n "Pero ellos ya os conocen."

    scene black
    with fade
    $ parar_todo(fade=2.0)
    n "Y el eco se apaga."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(2, "ambos_caen")
    $ guardar_estados_capitulo(2, "torre")
    $ unlock_final("torre", 2, "ambos_caen")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap2_completado)
    $ desbloquear_imagen_galeria("cap2_ambos")
    $ capitulos.completar_capitulo("torre", 2)
    $ desbloquear_invocaciones_hasta(2)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("yuki_confia"):
        $ registrar_peso("cap2_confio_sora")
    if gtn_flag("yuki_pregunta"):
        $ registrar_peso("cap2_pregunto_sora")
    if gtn_flag("yuki_inscripcion_lee"):
        $ registrar_peso("cap2_leyo_inscripcion")
    if gtn_flag("yuki_respiro"):
        $ registrar_peso("cap2_respiro")

    "Capítulo 2 completado (final malo)."
    jump volver_al_hub


label cap2_final_secreto:
    scene bg_piso2_salida
    with fade
    show yuki_img at left
    show sora_img at right
    with dissolve

    yu "Ve tú. Yo me quedo."
    so "¡No!"
    yu "Confía en mí."
    n "Empujas a Sora hacia la puerta."
    n "Pero no te quedas atrás."
    n "Te quedas de pie, al lado de la puerta, mirando los espejos."
    n "Y los espejos te miran a ti."
    n "Todos a la vez."

    $ musica("final_malo", fade=1.5)
    scene cap2_final_secreto
    with fade

    n "La puerta se cierra detrás de Sora."
    n "Y tú te quedas."
    n "Sola."
    n "En el pasillo."
    n "Pero no estás sola."
    n "Los espejos ya no reflejan lo que hay aquí."
    n "Reflejan lo que {i}hubo{/i} aquí."
    n "Y en todos, en el fondo, aparece la misma cosa."
    n "Una puerta más."
    n "Y detrás de esa puerta, dieciocho figuras."
    n "Todas juntas."
    n "Esperando."
    n "Y en el centro, tú."
    n "Pero no eres tú."
    n "Todavía."

    $ sonido("eco_verdadero")
    elyon_voz "{i}No confíes en el eco.{/i}"
    n "El eco se apaga."

    scene black
    with fade
    $ parar_todo(fade=2.0)

    $ registrar_final_malo()
    $ registrar_ruta(2, "secreto")
    $ guardar_estados_capitulo(2, "torre")
    $ unlock_final("torre", 2, "secreto")
    $ add_achievement_with_popup(achievement_cap2_completado)
    $ add_achievement_with_popup(achievement_primera_ruta)
    $ desbloquear_imagen_galeria("cap2_secreto")
    $ capitulos.completar_capitulo("torre", 2)
    $ desbloquear_invocaciones_hasta(2)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    if gtn_flag("yuki_confia"):
        $ registrar_peso("cap2_confio_sora")
    if gtn_flag("yuki_pregunta"):
        $ registrar_peso("cap2_pregunto_sora")
    if gtn_flag("yuki_inscripcion_lee"):
        $ registrar_peso("cap2_leyo_inscripcion")
    if gtn_flag("yuki_respiro"):
        $ registrar_peso("cap2_respiro")

    "Capítulo 2 completado (ruta secreta)."
    jump volver_al_hub


# ═══════════════════════════════════════════════════════════════
#  EXPLORACIÓN CON FLECHAS
# ═══════════════════════════════════════════════════════════════
label cap02_exploracion:

    call screen cap02_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap02_zona1

    call screen cap02_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap02_zona2

    call screen cap02_exploracion_screen(zonas=zonas_exploradas)
    $ zonas_exploradas.append(_return)
    call cap02_zona3

    return


screen cap02_exploracion_screen(zonas):
    modal True
    add "bg_piso2_despertar"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 20

        text "EXPLORA EL PASILLO" size 30 color "#FFFFFF" xalign 0.5
        text "Zonas exploradas: [len(zonas)] / 3" size 18 color "#AAAAAA" xalign 0.5
        null height 20

        vbox:
            spacing 30
            xalign 0.5

            if 1 not in zonas:
                textbutton "→ Explorar el PASILLO DE ESPEJOS" action Return(1) style "menu_button" xalign 0.5
            else:
                text "✔ Pasillo de espejos (explorado)" size 16 color "#666" xalign 0.5

            if 2 not in zonas:
                textbutton "↑ Explorar la SALA DEL ESPEJO GRANDE" action Return(2) style "menu_button" xalign 0.5
            else:
                text "✔ Sala del espejo grande (explorado)" size 16 color "#666" xalign 0.5

            if 3 not in zonas:
                textbutton "↓ Explorar el ESPEJO ROTO" action Return(3) style "menu_button" xalign 0.5
            else:
                text "✔ Espejo roto (explorado)" size 16 color "#666" xalign 0.5


label cap02_zona1:
    scene bg_piso2_pasillo
    with fade
    show yuki_img at left
    with dissolve

    n "El pasillo está forrado de espejos. Suelo. Paredes. Techo."
    n "Te ves reflejada infinitas veces. Cada reflejo un poco distinto."
    n "Caminas con cuidado. El suelo resbala."

    show cap02_reflejo at truecenter
    with dissolve

    n "Uno de los espejos tiene una inscripción grabada en el marco."
    $ aprender_palabra("torre", "reflejo_no_miente")

    yu "«El reflejo no miente...»"
    yu "¿Y qué se supone que significa eso?"

    hide cap02_reflejo
    with dissolve

    $ modificar_metrica("miedo", +8)
    $ modificar_metrica("angustia", +6)

    show sora_img at right
    with dissolve

    so "¿Qué has encontrado?"
    yu "Una inscripción. Dice «El reflejo no miente»."
    so "..."
    so "Pues yo he visto mi reflejo hacer cosas que yo no hacía."
    yu "Entonces miente."
    so "O nosotros no nos damos cuenta de lo que hacemos."
    yu "Eso es aún peor."
    so "Sí."
    return


label cap02_zona2:
    scene bg_piso2_espejo_grande
    with fade
    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Al fondo del pasillo hay una sala más amplia."
    n "En la pared del fondo, un espejo enorme. Enorme. Más que los demás."
    n "Está enmarcado en oro ennegrecido. Y en él, el reflejo no coincide."
    n "En el reflejo, hay una puerta. Aquí, no."

    if peso_tomado("cap1_cogio_mano"):
        n "Y por un momento, en el reflejo del espejo grande, ves algo más que la puerta."
        n "Dos siluetas. Cruzando juntas. Cogidas de la mano."
        yup "(¿Quiénes son?)"
        yup "(No los conozco.)"
        yup "(Pero... creo que los he visto antes.)"

    yu "Sora... mira."
    so "Ya lo veo."
    yu "¿Por qué hay una puerta en el reflejo?"
    so "Porque la salida está al otro lado. Pero no la vemos desde aquí."
    yu "¿Y cómo llegamos?"
    so "No lo sé. Todavía."

    n "Algo se mueve en el fondo del reflejo. Una sombra. Algo con forma casi humana."
    n "Y entonces lo oyes."

    $ sonido("eco_verdadero")
    n "Una voz. Pero no es la tuya. Ni la de Sora."
    n "Es tu voz. Pero un poco más grave. Y un poco más lenta."
    n "Y dice algo que tú no has dicho."

    elyon_voz "{i}No confíes en el eco.{/i}"

    $ aprender_palabra("torre", "eco_verdadero")

    yu "Sora."
    so "¿Sí?"
    yu "¿Tú también lo has oído?"
    so "...Sí."
    so "Pero no ha dicho lo mismo que a ti."
    yu "¿Qué te ha dicho a ti?"
    so "..."
    so "Que no confíe en ti."

    n "Los dos os quedáis en silencio."

    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ modificar_metrica("angustia", +15)
    return


label cap02_zona3:
    scene bg_piso2_espejo_roto
    with fade
    show yuki_img at left
    show sora_img at right
    with dissolve

    n "Seguís avanzando. Al final del pasillo, un espejo roto."
    n "Los fragmentos están en el suelo. Cada uno refleja algo distinto."
    n "Algunos os reflejan a los dos."
    n "Uno de ellos, sin embargo, solo refleja a Sora. Sin ti."
    n "Otro solo te refleja a ti. Sin él."

    yu "Sora. Mira esto."
    so "..."
    so "No me gusta."
    yu "¿Qué pasa?"
    so "En uno de los fragmentos, estoy solo."
    yu "Y en otro, estoy sola yo."
    so "Exacto."

    n "En un tercer fragmento, estáis los dos. Pero no aquí. En otro sitio. Con más gente."
    n "En una torre. Con más espejos. Y más puertas."

    yu "¿Qué es eso?"
    so "No lo sé."
    so "Pero no es aquí."

    n "El fragmento se empaña. Y al despejarse, ya no muestra nada."
    $ modificar_metrica("miedo", +12)
    $ modificar_metrica("terror", +8)
    return


# ═══════════════════════════════════════════════════════════════
#  SCREENS INTERACTIVOS
# ═══════════════════════════════════════════════════════════════

screen cap02_marca_interactiva():
    modal True
    add "bg_piso2_pasillo"
    button:
        xpos 0.4
        ypos 0.35
        xsize 350
        ysize 350
        background None
        hover_background "#FFAA0033"
        action Return()
    text "Pulsa la inscripción":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


screen cap02_simbolo_espejo_interactivo():
    modal True
    add "bg_piso2_espejo_grande"
    button:
        xpos 0.55
        ypos 0.35
        xsize 200
        ysize 200
        background None
        hover_background "#FFAA0033"
        action Return()
    text "Pulsa el símbolo del espejo":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


screen cap02_puerta_espejo_interactivo():
    modal True
    add "bg_piso2_salida"
    button:
        xpos 0.35
        ypos 0.25
        xsize 400
        ysize 500
        background None
        hover_background "#FFAA0033"
        action Return()
    text "Pulsa la puerta-espejo":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint