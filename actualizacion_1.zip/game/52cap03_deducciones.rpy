# ═══════════════════════════════════════════════════════════════
#  52cap03_deducciones.rpy — Deducciones del Capítulo 3
#  -----------------------------------------------------------------
#  2 momentos donde el jugador debe deducir algo.
#  Acertar → recompensa (pista al tablón). Fallar → nada.
#
#  ⚠️ Reutilizamos el screen `deduccion_interactiva` del Cap 1
#     (definido en 50cap01_deducciones.rpy).
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 1 — ¿Por qué el público aplaude?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 3, después de subir al escenario.
#  Pregunta: ¿Por qué crees que el público aplaude?
#  Respuesta correcta: "Porque recuerda lo que pasó aquí."
# ═══════════════════════════════════════════════════════════════
label cap03_deduccion_1:

    n "..."

    n "Estás en el escenario."

    n "Y desde aquí, se oye todo mejor."

    n "El silencio. Las butacas. Y, de vez en cuando, un aplauso."

    hap "(No hay nadie.)"
    hap "(Pero aplauden.)"
    hap "(¿Por qué?)"

    # ── Deducción interactiva ──
    $ opciones_ded3_1 = [
        ("Es un sonido pregrabado. Una trampa.", False),
        ("Porque recuerda lo que pasó aquí. Y lo repite.", True),
        ("Están aplaudiendo a alguien que no soy yo.", False),
        ("Es el viento. El teatro tiene corrientes de aire.", False),
    ]

    call screen deduccion_interactiva(
        pregunta="¿Por qué crees que el público aplaude?",
        opciones=opciones_ded3_1,
        pista_ok="El público recuerda la última función",
        pista_key="p3_publico_recuerda"
    )

    return


# ═══════════════════════════════════════════════════════════════
#  DEDUCCIÓN 2 — ¿Qué es realmente el telón?
# ═══════════════════════════════════════════════════════════════
#  Momento: Acto 4, cuando el telón está bajando.
#  Pregunta: ¿Qué crees que es realmente el telón?
#  Respuesta correcta: "No es una tela. Es una puerta."
# ═══════════════════════════════════════════════════════════════
label cap03_deduccion_2:

    n "El telón está bajando."

    n "Pero no como una tela."

    n "Baja como si fuera algo sólido."

    n "Y cuando baja, algo detrás se cierra."

    hap "(No es tela.)"
    hap "(Y no se está cerrando. Se está cerrando algo.)"

    # ── Deducción interactiva ──
    $ opciones_ded3_2 = [
        ("Es solo una cortina muy pesada. Hay que empujarla.", False),
        ("No es una tela. Es una puerta. Y se está cerrando.", True),
        ("Es un truco del teatro. Para asustar.", False),
        ("Es el telón de la función. La obra está terminando.", False),
    ]

    call screen deduccion_interactiva(
        pregunta="¿Qué crees que es realmente el telón?",
        opciones=opciones_ded3_2,
        pista_ok="El telón es una puerta",
        pista_key="p3_telon_es_puerta"
    )

    return