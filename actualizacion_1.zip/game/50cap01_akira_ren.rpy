# ═══════════════════════════════════════════════════════════════
#  50cap01_akira_ren.rpy — Capítulo 1: El despertar
#  -----------------------------------------------------------------
#  Pareja: Akira & Ren
#  Finales: bueno / bueno_especial / superviviente / secreto / ambos_cayeron
#  Minijuego: QTE
#  Diccionario: ayudame, elyon, simbolo_suelo, puerta_cerrada
#  Fichas: akira, ren
# ═══════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
#  PERSONAJES
# ─────────────────────────────────────────────────────────────
define ak = Character("Akira", color="#7ec8e3")
define re = Character("Ren", color="#a8e6cf")

# Akira pensando (monólogo interior, cursiva, gris)
define akp = Character(
    "Akira",
    color="#7ec8e3",
    what_color="#a8c8d8",
    what_italic=True,
    what_size=28
)

# La voz de El·yon (sin nombre, letra distorsionada)
define elyon_voz = Character(
    "???",
    color="#8b0000",
    what_color="#CC4444",
    what_italic=True,
    what_size=32
)


# ─────────────────────────────────────────────────────────────
#  IMÁGENES (Placeholders con Prompts para IA)
# ─────────────────────────────────────────────────────────────

# 🎨 PROMPT: Habitación cuadrada de cemento, sin ventanas, bombilla parpadeante, 
# suelo con polvo y marcas, puerta metálica cerrada. Estilo anime oscuro de terror psicológico. 16:9.
image bg_piso1_despertar = "images/fondos/cap01/piso1_despertar.png"

# 🎨 PROMPT: Pasillo estrecho de cemento, puertas metálicas, luces cenitales parpadeantes, 
# suelo húmedo, claustrofobia. Estilo anime oscuro. 16:9.
image bg_piso1_pasillo = "images/fondos/cap01/piso1_pasillo.png"

# 🎨 PROMPT: Sala pequeña de cemento, marca tallada en la pared del fondo, 
# foco cenital sobre la marca. Estilo anime oscuro. 16:9.
image bg_piso1_marca = "images/fondos/cap01/piso1_marca.png"

# 🎨 PROMPT: Borde de hueco profundo, barandilla oxidada, oscuridad absoluta debajo. 
# Estilo anime oscuro. 16:9.
image bg_piso1_hueco = "images/fondos/cap01/piso1_hueco.png"

# 🎨 PROMPT: Puerta metálica entreabierta con luz blanca cegadora, contraste extremo. 
# Estilo anime oscuro. 16:9.
image bg_piso1_salida = "images/fondos/cap01/piso1_salida.png"

# 🎨 PROMPT: Primer plano de marca tallada con uñas en cemento, letras irregulares, 
# restos de sangre seca, luz lateral dramática.
image cap01_marca_pared = "images/objetos/cap01_marca_pared.png"

# 🎨 PROMPT FINALES:
# Bueno: Dos chicos jóvenes caminando juntos hacia luz blanca, vista desde atrás, esperanza ambigua.
image cap1_final_bueno = "images/finales/cap1_final_bueno.png"
# Superviviente: Silueta joven sola en pasillo, puerta cerrada delante, soledad y culpa.
image cap1_final_superviviente = "images/finales/cap1_final_superviviente.png"
# Secreto: Silueta joven sentada sola en habitación de cemento, luz parpadeante, forma oscura detrás.
image cap1_final_secreto = "images/finales/cap1_final_secreto.png"
# Malo: Dos chicos jóvenes cayendo hacia oscuridad absoluta, vista desde arriba, manos sin alcanzarse.
image cap1_final_ambos = "images/finales/cap1_final_ambos.png"


# ═══════════════════════════════════════════════════════════════
#  CAPÍTULO 1: EL DESPERTAR
# ═══════════════════════════════════════════════════════════════
label capitulo_1:

    # ── Inicialización segura ──
    $ gtn_reiniciar_metricas()
    $ gtn_capitulo_actual = 1
    $ capitulos.desbloquear_capitulo("torre", 1)
    $ registrar_capitulo_jugado(1)
    
    # Inicializar variable si no existe (seguridad)
    $ gtn_puertas_pulsadas = getattr(store, 'gtn_puertas_pulsadas', 0)

    scene black
    with fade

    show screen gtn_notif_screen
    $ musica("torre_ambiente", fade=2.0)

    # ── Logro: primer_despertar ──
    $ add_achievement_with_popup(achievement_primer_despertar)
    $ renpy.pause(0.5) # Pausa anti-bug de popup

    # ═══════════════════════════════════════════════════════════
    #  ACTO 1 — EL DESPERTAR
    # ═══════════════════════════════════════════════════════════

    n "Todo está oscuro."
    n "Lo primero que notas es el frío del suelo contra la mejilla."
    n "Lo segundo, un zumbido lejano. Como una bombilla a punto de fundirse."

    $ ambiente("zumbido_bombilla", loop=True, fade=1.0)

    n "Lo tercero, el olor."
    n "Humedad. Óxido. Algo más que prefieres no identificar."
    n "Abres los ojos."

    scene bg_piso1_despertar
    with fade

    n "Una habitación de cemento. Sin ventanas. Una única bombilla parpadea en el techo."
    n "No recuerdas cómo has llegado aquí."
    n "Ni siquiera recuerdas haberte dormido."

    show akira_img at left
    with dissolve

    ak "...¿Dónde...?"
    ak "Esto no es mi habitación."
    ak "¿Dónde {i}mierdas{/i} estoy?"

    n "Te incorporas con esfuerzo. El cuerpo te pesa como si hubieras corrido una maratón."

    akp "(El suelo está frío. Demasiado frío.)"
    akp "(Y huele a algo que no quiero reconocer.)"

    # ── Ficha: Akira ──
    $ desbloquear_ficha("torre", "akira")
    $ add_achievement_with_popup(achievement_conoce_akira)

    ak "Vale. Vale, tranquilo."
    ak "Piensa. ¿Qué es lo último que recuerdas?"
    ak "Nada. Solo recuerdo una puerta cerrándose."

    n "Te miras las manos. Están limpias. Y eso, de alguna forma, te inquieta más."

    akp "(¿Por qué están limpias?)"
    akp "(Deberían tener polvo. O sangre. O algo.)"

    $ desbloquear_pista("torre", "p1_puerta_cerrada")
    call cap01_nota_puerta from _call_cap01_nota_puerta

    # ── Decisión 1 ──
    menu:
        "¿Qué haces?"

        "Gritar pidiendo ayuda.":
            $ modificar_metrica("miedo", +10)
            $ modificar_metrica("angustia", +5)
            $ gtn_flag("grito_inicial", True)
            $ registrar_decision()
            $ gtn_flag("grito_alguna_vez", True)

            ak "¡¿HOLA?! ¡¿HAY ALGUIEN?!"
            n "Tu voz rebota contra las paredes y vuelve a ti, más apagada."
            n "Nadie responde."
            ak "Genial. Perfecto."
            akp "(Vale, gritar no funciona. Ahora ya lo sé. Genial.)"

        "Examinar la habitación en silencio.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +10)
            $ gtn_flag("silencio_inicial", True)
            $ registrar_decision()

            ak "..."
            n "Recorres la habitación con la mirada."
            n "Las paredes están arañadas. Alguien ha estado aquí antes."
            n "Prefieres no pensar en quién."
            akp "(Alguien ha estado aquí. Y no ha salido.)"

        "Intentar abrir la puerta.":
            $ modificar_metrica("miedo", +8)
            $ modificar_metrica("angustia", +3)
            $ gtn_flag("puerta_inicial", True)
            $ registrar_decision()
            $ gtn_puertas_pulsadas += 1

            ak "Vamos a ver..."
            n "La puerta metálica no cede. Ni siquiera se mueve."
            ak "Claro. No va a estar abierta para mí."
            akp "(Está cerrada por fuera. O por algo peor.)"

    if estado_minimo("miedo", 40):
        akp "(Me tiemblan las manos. No deberían. Solo es una habitación.)"
    if estado_extremo("angustia"):
        n "Sientes que te falta el aire. Y no hay ninguna razón para ello."
        akp "(Respira. Respira. No estás en peligro. Todavía.)"

    call cap01_eco_elyon_1 from _call_cap01_eco_elyon_1

    n "Entonces lo oyes."
    $ sonido("pasos_lejanos")
    n "Pasos. Al otro lado de la puerta."
    ak "¿Hola...?"
    n "Los pasos se detienen. Luego, un golpe seco contra la puerta."
    akp "(¿Y si no es alguien? No. No pienses eso.)"

    $ add_achievement_with_popup(achievement_primera_decision)

    # ═══════════════════════════════════════════════════════════
    #  ACTO 2 — EL PASILLO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso1_pasillo
    with fade

    show ren_img at right
    with dissolve

    re "¿Hay alguien ahí dentro?"
    ak "Sí. Sí, hay alguien."
    re "Menos mal. Pensaba que estaba solo."
    n "La voz del otro lado es firme, pero hay un temblor escondido."
    re "Voy a intentar abrir desde aquí. La cerradura está vieja."

    $ sonido("puerta_chasquido")
    n "Un chasquido. La puerta cede."

    scene bg_piso1_pasillo
    with dissolve
    show akira_img at left
    show ren_img at right
    with dissolve

    re "Hola."
    ak "Hola."
    re "Ren."
    ak "Akira."
    re "Vale, Akira. Vamos a salir de aquí."

    $ desbloquear_ficha("torre", "ren")
    $ add_achievement_with_popup(achievement_conoce_ren)
    $ renpy.pause(0.5)

    n "Hay algo en su forma de decirlo que te tranquiliza. Aunque no debería."

    if estado_minimo("angustia", 50):
        n "Ren te mira. Y por un momento, ves algo en sus ojos que no habías visto. Cansancio de verdad."
        akp "(No es solo la torre. Lleva esto dentro desde antes de llegar.)"
    if estado_minimo("amor", 30):
        n "Y sin embargo, sonríe. Como si, a pesar de todo, estuviera bien."
        akp "(¿Por qué sonríe? No hay nada que sonreír.)"
    if estado_minimo("miedo", 60):
        n "Tú no sonríes. No puedes."
        akp "(Me tiembla la voz. No puedo dejar que lo note.)"

    if gtn_flag("grito_inicial"):
        re "Te he oído gritar antes. Desde el otro lado. No te culpo."
        ak "No he gritado."
        re "Sí. Has gritado."
        ak "..."
        akp "(¿He gritado? No me acuerdo.)"
        $ modificar_metrica("angustia", +5)
    elif gtn_flag("silencio_inicial"):
        re "No has dicho nada. Todo este tiempo."
        ak "Estaba... pensando."
        re "Ya. Yo también me quedo callado cuando tengo miedo."
        ak "No tengo miedo."
        re "Vale."
        n "Ren no insiste. Pero te mira un segundo más de lo necesario."
    elif gtn_flag("puerta_inicial"):
        re "Has intentado abrir la puerta."
        ak "¿Cómo lo sabes?"
        re "Porque la has dejado arañada. Con las uñas."
        ak "Yo no he hecho eso."
        re "..."
        akp "(Yo no he hecho eso. ¿Verdad?)"

    # ── Decisión 2 ──
    menu:
        "¿Cómo reaccionas?"

        "Confiar en él directamente.":
            $ modificar_metrica("amor", +15)
            $ modificar_metrica("miedo", -5)
            $ registrar_peso("cap1_confio_ren")
            $ gtn_flag("confia_ren", True)
            $ registrar_decision()
            ak "Vale. Confío en ti."
            re "...¿Así, sin más?"
            ak "No tengo mucho donde elegir."
            n "Ren sonríe de lado. Es la primera sonrisa que ves en este sitio."
            akp "(No debería confiar en él. Pero lo hago. Y no sé por qué.)"
            call cap01_nota_ren_confianza from _call_cap01_nota_ren_confianza

        "Mantener la distancia.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("angustia", +5)
            $ registrar_peso("cap1_desconfio_ren")
            $ gtn_flag("desconfia_ren", True)
            $ registrar_decision()
            ak "Vale. Pero no te voy a seguir a ciegas."
            re "Me parece justo."
            n "Ren asiente. No insiste. Y eso, de alguna forma, te hace confiar un poco más en él."
            akp "(No insiste. Eso es lo que me molesta.)"
            call cap01_nota_ren_distancia from _call_cap01_nota_ren_distancia

    if estado_minimo("amor", 40) and estado_minimo("miedo", 40):
        akp "(Le he dicho que confío en él. Y es verdad. Pero también me da miedo.)"
    if estado_extremo("odio"):
        akp "(No debería odiarlo. Ni siquiera lo conozco. Pero hay algo en él que me irrita.)"

    if gtn_flag("confia_ren"):
        re "Me alegra que confíes en mí. Aunque no deberías."
        ak "¿Qué?"
        re "Nada. Olvídalo."
        akp "(Ha dicho algo importante. Pero no lo ha dicho.)"

    n "Avanzáis juntos por el pasillo. Las paredes están llenas de marcas."
    n "Ren va delante. Tú, detrás."
    re "Esto parece una prisión."
    ak "O un sótano muy mal decorado."
    re "También."
    n "Ren no se gira al hablar. Camina con la espalda recta, como si supiera dónde va."

    if estado_minimo("angustia", 60):
        akp "(Me pesa la cabeza. Como si tuviera algo dentro que quiere salir.)"

    call cap01_flashback_akira_azotea from _call_cap01_flashback_akira_azotea

    # ═══════════════════════════════════════════════════════════
    #  ACTO 3 — LA MARCA Y EL SUSURRO
    # ═══════════════════════════════════════════════════════════

    scene bg_piso1_marca
    with fade
    show akira_img at left
    show ren_img at right
    with dissolve

    n "Una de las paredes tiene una marca tallada. No como las demás. Esta tiene forma de letras."
    ak "Ren. Mira esto."
    re "..."
    n "Te acercas. Los trazos son irregulares. Como si alguien hubiera usado las uñas."

    call screen cap01_marca_interactiva

    $ sonido("marca_raspar")
    show cap01_marca_pared at truecenter
    with dissolve

    n "Las letras están escritas a rayones. Y a sangre seca. Pero se lee."

    $ aprender_palabra("torre", "ayudame")

    ak "«Ayúdame...»"
    re "Alguien escribió esto antes que nosotros."
    ak "Los puntos suspensivos... ¿Por qué los puntos suspensivos?"
    re "Porque quien lo escribió no acabó de decirlo todo."

    hide cap01_marca_pared
    with dissolve

    $ desbloquear_pista("torre", "p1_marca_pared")
    call cap01_nota_marca from _call_cap01_nota_marca

    # ── Decisión 3 ──
    menu:
        "¿Qué haces con la marca?"

        "Intentar leer más allá.":
            $ modificar_metrica("miedo", +10)
            $ modificar_metrica("angustia", +10)
            $ registrar_peso("cap1_leyo_marca")
            $ gtn_flag("leyo_mas", True)
            $ registrar_decision()
            ak "Hay más. Debajo."
            n "Rascas con la uña. La pared está húmeda."
            n "Debajo de la primera frase hay otra, casi borrada."
            n "«{i}No salgas. El·yon te ve.{/i}»"
            ak "¿El·yon...?"
            re "¿Qué?"
            ak "Nada. Vámonos."
            akp "(El·yon. Ese nombre me suena. Y no debería.)"
            $ desbloquear_pista("torre", "p1_susurro_elyon")

        "Apartar la mirada.":
            $ modificar_metrica("miedo", +5)
            $ modificar_metrica("amor", +5)
            $ registrar_peso("cap1_aparto_mirada")
            $ gtn_flag("aparto_mirada", True)
            $ registrar_decision()
            ak "No quiero saber más."
            re "Bien. Vámonos."
            n "Ren te pone una mano en el hombro. No dice nada. No hace falta."
            akp "(Gracias. Aunque no lo diga.)"

        "Respirar hondo. Intentar calmarte." if estado_minimo("miedo", 18):
            $ modificar_metrica("miedo", -15)
            $ modificar_metrica("angustia", -10)
            $ registrar_peso("cap1_cogio_mano")
            $ gtn_flag("respiro", True)
            $ registrar_decision()
            ak "..."
            n "Cierras los ojos. Respiras."
            n "Cuando los abres, la marca sigue ahí. Pero decides que no vale la pena arañarte las uñas por ello."
            re "¿Estás bien?"
            ak "Sí. Ahora sí. Vamos."
            akp "(Un momento. Solo necesitaba un momento.)"

    call screen cap01_simbolo_suelo
    call cap01_pulsar_simbolo from _call_cap01_pulsar_simbolo
    call cap01_nota_simbolo from _call_cap01_nota_simbolo
    call cap01_deduccion_1 from _call_cap01_deduccion_1

    n "Seguís avanzando. El pasillo se estrecha. Y entonces lo oyes."
    play sound "audio/voces/elyon.ogg"
    n "Una voz. No es la de Ren. Viene de todas partes. Y de ninguna."
    n "Susurra una sola palabra."

    elyon_voz "{i}El·yon.{/i}"

    $ aprender_palabra("torre", "elyon")
    $ desbloquear_bestiario("torre", "elyon")
    call cap01_nota_susurro from _call_cap01_nota_susurro

    if estado_extremo("terror"):
        akp "(Lo he oído. Lo he oído de verdad. No estoy loco. ¿O sí?)"
        n "Te llevas las manos a las orejas."
        re "Akira. Akira, mírame."
        ak "Estoy bien."
        re "No. No lo estás."
        n "Y por primera vez, no sabes qué contestar."
    if estado_minimo("amor", 50):
        re "Sea lo que sea que hayas oído... No estás solo."
        ak "..."
        akp "(No estoy solo. Nunca había pensado eso.)"
    if estado_minimo("odio", 50):
        akp "(No quiero que me vea así.)"
        n "Te apartas un poco de Ren. Sin darte cuenta."
        re "..."
        n "Ren no dice nada. Pero lo nota."

    ak "¿Has oído eso?"
    re "¿El qué?"
    ak "...Nada."
    $ gtn_flag("cap1_eco_oculto", True)
    n "Ren no lo ha oído. Solo tú."
    
    $ modificar_metrica("miedo", +15)
    $ modificar_metrica("terror", +10)
    $ musica("tension_baja", fade=2.0)

    call cap01_eco_elyon_2 from _call_cap01_eco_elyon_2

    # ═══════════════════════════════════════════════════════════
    #  ACTO 4 — EL HUECO (QTE)
    # ═══════════════════════════════════════════════════════════

    scene bg_piso1_hueco
    with fade
    show akira_img at left
    show ren_img at right
    with dissolve

    n "Al final del pasillo, el suelo se abre. Un hueco profundo. Oscuro. Sin fondo visible."
    n "Ren se asoma un momento. Se aparta rápido."
    re "Habrá que saltarlo. No es tan grande. Puedo pasar primero y te ayudo."
    ak "Vale."

    call cap01_flashback_ren_noche from _call_cap01_flashback_ren_noche

    n "Ren salta. Aterriza al otro lado. Se gira y te tiende la mano."
    re "¡Vamos!"
    n "Ahora te toca a ti. Tomas carrerilla. Y saltas."

    if estado_extremo("miedo"):
        akp "(No puedo. No puedo saltar. Voy a caer. Como en el flashback.)"
        n "Te tiemblan las piernas."
        re "Akira. Mírame. Vas a saltar. Y yo voy a cogerte. ¿Vale?"
        akp "(¿Por qué confía en mí? No debería.)"
    if estado_minimo("terror", 60):
        akp "(El hueco es demasiado grande. No voy a llegar. Lo sé.)"

    $ musica("tension_alta", fade=0.5)
    call lanzar_qte(["↑", "→", "↓", "←", "↑"]) from _call_lanzar_qte

    if gtn_minijuego_resultado:
        # QTE SUPERADO
        $ registrar_minijuego(True)
        $ add_achievement_with_popup(achievement_primer_minijuego)
        $ renpy.pause(0.5)
        $ add_achievement_with_popup(achievement_minijuego_perfecto)

        n "Tus pies encuentran el borde."
        n "Ren te agarra del brazo antes de que puedas caer."
        re "¡Te tengo!"
        n "Durante un segundo, estáis los dos tumbados en el suelo del otro lado."
        ak "...Gracias."
        re "No las des."
        akp "(Me ha salvado. No tenía por qué. Pero lo ha hecho.)"
        
        $ modificar_metrica("amor", +20)
        $ modificar_metrica("miedo", -10)
        $ musica("torre_ambiente", fade=1.5)
    else:
        # QTE FALLADO
        $ registrar_minijuego(False)
        $ add_achievement_with_popup(achievement_primer_minijuego)
        n "Tus pies no encuentran el borde."
        n "El aire se te escapa del pecho."
        re "¡AKIRA!"
        n "Ren se lanza hacia ti. Te agarra la muñeca. Pero el peso es demasiado."
        $ musica("final_malo", fade=1.0)
        jump cap1_final_malo_por_qte

    # ═══════════════════════════════════════════════════════════
    #  ACTO 5 — LA SALIDA
    # ═══════════════════════════════════════════════════════════

    scene bg_piso1_salida
    with fade
    show akira_img at left
    show ren_img at right
    with dissolve

    n "Al final del piso, hay una puerta entreabierta. Luz blanca. Cegadora."
    re "Es la salida."
    ak "¿Y si no lo es?"
    re "Entonces volvemos. Pero contigo."
    n "Ren te mira. Espera."

    call screen cap01_puerta_grabados
    call cap01_pulsar_puerta from _call_cap01_pulsar_puerta
    call cap01_nota_puerta_grabados from _call_cap01_nota_puerta_grabados
    call cap01_deduccion_2 from _call_cap01_deduccion_2
    call cap01_eco_elyon_3 from _call_cap01_eco_elyon_3

    # ── Comprobación de logros acumulativos ──
    if gtn_flag("eco_1_oido") and gtn_flag("eco_2_oido") and gtn_flag("eco_3_oido"):
        $ add_achievement_with_popup(achievement_eco_completo)
    if gtn_flag("fb_akira_visto") and gtn_flag("fb_ren_visto"):
        $ add_achievement_with_popup(achievement_recuerdos_cap1)
    if notas_descubiertas_cap("torre", 1) >= 6:
        $ add_achievement_with_popup(achievement_notas_completas)
    if objeto_visto("simbolo_suelo") and objeto_visto("puerta_grabados"):
        $ add_achievement_with_popup(achievement_objetos_cap1)

    # ── Decisión final ──
    menu:
        "¿Qué decides?"

        "Salir juntos, sin mirar atrás.":
            $ registrar_decision()
            jump cap1_final_bueno

        "Salir tú primero, para asegurar.":
            $ registrar_decision()
            jump cap1_final_superviviente

        "Quedarte atrás para que él salga.":
            $ registrar_decision()
            jump cap1_final_secreto

        # ── Opción extra (solo si amor >= 70 y miedo < 40) ──
        "Cogerle la mano antes de cruzar." if estado_minimo("amor", 70) and estado_maximo("miedo", 40):
            $ modificar_metrica("amor", +15)
            $ gtn_flag("cogio_mano", True)
            $ registrar_decision()
            
            n "No dices nada. Solo le coges la mano."
            n "Ren no se aparta."
            n "Y los dos cruzáis la puerta juntos."
            
            jump cap1_final_bueno_especial


# ═══════════════════════════════════════════════════════════════
#  FINALES DEL CAPÍTULO 1
# ═══════════════════════════════════════════════════════════════

label cap1_final_bueno:
    scene bg_piso1_salida with fade
    show akira_img at left
    show ren_img at right with dissolve

    ak "Juntos."
    re "Juntos."
    n "Cruzáis la puerta a la vez. La luz os traga."

    $ musica("final_bueno", fade=2.0)
    scene cap1_final_bueno with Dissolve(1.5)

    n "Y luego, silencio. Un silencio distinto. Menos opresivo."
    n "Como si, por un momento, la torre os hubiera dejado descansar."

    scene black with fade
    $ parar_todo(fade=2.0)
    n "Nivel 1 superado."

    $ registrar_final_bueno()
    $ registrar_ruta(1, "bueno")
    $ guardar_estados_capitulo(1, "torre")
    $ unlock_final("torre", 1, "bueno")
    $ add_achievement_with_popup(achievement_final_bueno_cap1)
    $ add_achievement_with_popup(achievement_cap1_completado)
    $ desbloquear_imagen_galeria("cap1_bueno")
    $ capitulos.completar_capitulo("torre", 1)
    call marcar_final_bueno_cap(1, "torre") from _call_marcar_final_bueno_cap
    $ desbloquear_invocaciones_hasta(1)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    "Capítulo 1 completado."
    jump capitulo_2


label cap1_final_bueno_especial:
    scene bg_piso1_salida with fade
    show akira_img at left
    show ren_img at right with dissolve

    n "Cruzasteis juntos. Con las manos cogidas."
    n "Y al otro lado, por primera vez, no había silencio."
    n "Había una puerta abierta. Y detrás, luz."

    $ musica("final_bueno", fade=2.0)
    scene cap1_final_bueno with Dissolve(1.5)

    n "Pero no era la salida. Era otra cosa."
    n "Era el inicio de algo que ninguno de los dos había previsto."

    scene black with fade
    $ parar_todo(fade=2.0)
    n "Nivel 1 superado. Pero no del todo."

    $ registrar_final_bueno()
    $ registrar_ruta(1, "bueno_especial")
    $ guardar_estados_capitulo(1, "torre")
    $ unlock_final("torre", 1, "bueno")
    $ add_achievement_with_popup(achievement_final_especial_cap1)
    $ add_achievement_with_popup(achievement_cap1_completado)
    $ desbloquear_imagen_galeria("cap1_bueno")
    $ capitulos.completar_capitulo("torre", 1)
    call marcar_final_bueno_cap(1, "torre") from _call_marcar_final_bueno_cap_1
    $ desbloquear_invocaciones_hasta(1)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    "Capítulo 1 completado (ruta especial)."
    jump capitulo_2


label cap1_final_superviviente:
    scene bg_piso1_salida with fade
    show akira_img at left
    show ren_img at right with dissolve

    ak "Voy yo primero. Para asegurar."
    re "Akira, espera—"
    n "Cruzas la puerta antes de que pueda terminar la frase. La luz te traga."

    $ musica("final_malo", fade=1.5)
    scene cap1_final_superviviente with Dissolve(1.0)

    n "Al otro lado, hay un pasillo. Y una puerta cerrada."
    n "Detrás de ti, la puerta por la que has salido se cierra. Y no se vuelve a abrir."

    scene black with fade
    $ parar_todo(fade=2.0)
    n "Ren no ha llegado. Y tú no puedes volver."

    $ registrar_final_malo()
    $ registrar_ruta(1, "superviviente")
    $ guardar_estados_capitulo(1, "torre")
    $ unlock_final("torre", 1, "superviviente")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap1_completado)
    $ desbloquear_imagen_galeria("cap1_superviviente")
    $ capitulos.completar_capitulo("torre", 1)
    $ desbloquear_invocaciones_hasta(1)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    "Capítulo 1 completado."
    jump capitulo_2


label cap1_final_secreto:
    scene bg_piso1_salida with fade
    show akira_img at left
    show ren_img at right with dissolve

    ak "Ve tú. Yo me quedo."
    re "¿Qué? No."
    ak "Confía en mí. Por favor."
    n "Ren te mira. Hay algo en tus ojos que le hace obedecer. Cruza la puerta. La luz lo traga."

    $ musica("final_malo", fade=1.5)
    scene cap1_final_secreto with fade

    n "Y tú te quedas. En el piso 1. Solo."
    n "La bombilla sigue parpadeando. Y entonces lo vuelves a oír."
    $ sonido("elyon")
    elyon_voz "{i}El·yon te ve.{/i}"
    n "Ya no estás solo. Nunca lo has estado."

    $ parar_todo(fade=2.0)
    $ registrar_final_malo()
    $ registrar_ruta(1, "secreto")
    $ guardar_estados_capitulo(1, "torre")
    $ unlock_final("torre", 1, "secreto")
    $ add_achievement_with_popup(achievement_cap1_completado)
    $ add_achievement_with_popup(achievement_primera_ruta)
    $ desbloquear_imagen_galeria("cap1_secreto")
    $ capitulos.completar_capitulo("torre", 1)
    $ desbloquear_invocaciones_hasta(1)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    "Capítulo 1 completado (ruta secreta)."
    $ desbloquear_secreto("torre", "akira")
    jump capitulo_2


label cap1_final_malo_por_qte:
    scene bg_piso1_hueco with fade

    n "Ren no puede sujetarte."
    n "Los dos caéis. El hueco os traga."

    scene black with fade
    $ parar_todo(fade=2.0)
    n "Y el silencio."

    $ registrar_muerte()
    $ registrar_final_malo()
    $ registrar_ruta(1, "ambos_cayeron")
    $ guardar_estados_capitulo(1, "torre")
    $ unlock_final("torre", 1, "ambos_cayeron")
    $ add_achievement_with_popup(achievement_final_malo_primero)
    $ add_achievement_with_popup(achievement_cap1_completado)
    $ desbloquear_imagen_galeria("cap1_ambos")
    $ capitulos.completar_capitulo("torre", 1)
    $ desbloquear_invocaciones_hasta(1)
    $ desbloquear_edad_muerte("torre", "akira", 17)
    $ desbloquear_edad_muerte("torre", "ren", 18)
    $ renpy.force_autosave(take_screenshot=True, block=True)

    "Capítulo 1 completado (final malo)."
    jump capitulo_2


# ═══════════════════════════════════════════════════════════════
#  SCREENS Y TRANSFORMACIONES
# ═══════════════════════════════════════════════════════════════

screen cap01_marca_interactiva():
    modal True
    add "bg_piso1_marca"

    button:
        xpos 0.38
        ypos 0.35
        xsize 350
        ysize 350
        background None
        hover_background "#FFAA0033"
        action Return()

    text "Pulsa la marca":
        size 22
        color "#FFFFFF"
        xalign 0.5
        yalign 0.9
        at pulse_hint


# Transformación para el texto pulsante (fuera del screen, a nivel global)
transform pulse_hint:
    alpha 0.5
    linear 1.0 alpha 1.0
    linear 1.0 alpha 0.5
    repeat